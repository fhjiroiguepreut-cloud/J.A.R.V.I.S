package com.jarvis.assistant.tools

import org.json.JSONArray
import org.json.JSONObject

object AutomationSerializer {

    fun toJson(automations: List<Automation>): String {
        val array = JSONArray()
        automations.forEach { automation ->
            val obj = JSONObject()
            obj.put("id", automation.id)
            obj.put("trigger", automation.trigger.name)
            obj.put("actionToolId", automation.actionToolId)
            val params = JSONObject()
            automation.actionParams.forEach { (k, v) -> params.put(k, v) }
            obj.put("actionParams", params)
            obj.put("requiresConfirmation", automation.requiresConfirmation)
            obj.put("securityLevel", automation.securityLevel.name)
            obj.put("status", automation.status.name)
            array.put(obj)
        }
        return array.toString()
    }

    fun fromJson(json: String): List<Automation> {
        if (json.isBlank()) return emptyList()
        return try {
            val array = JSONArray(json)
            (0 until array.length()).mapNotNull { i ->
                val obj = array.getJSONObject(i)
                val trigger = AutomationTrigger.entries.firstOrNull { it.name == obj.getString("trigger") } ?: return@mapNotNull null
                val paramsObj = obj.optJSONObject("actionParams") ?: JSONObject()
                val params = paramsObj.keys().asSequence().associateWith { paramsObj.getString(it) }
                Automation(
                    id = obj.getString("id"),
                    trigger = trigger,
                    actionToolId = obj.getString("actionToolId"),
                    actionParams = params,
                    requiresConfirmation = obj.optBoolean("requiresConfirmation", false),
                    securityLevel = SecurityLevel.valueOf(obj.optString("securityLevel", "NORMAL")),
                    status = CommandStatus.valueOf(obj.optString("status", "ENABLED"))
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
