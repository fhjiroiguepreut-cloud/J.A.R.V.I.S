package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.theme.JarvisTextSecondary

@Composable
fun MemoryScreen(
    summary: String,
    onRefresh: () -> Unit,
    onClearAll: () -> Unit,
    onBack: () -> Unit
) {
    var showClearConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Volver") }
            Text("MEMORY", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = onRefresh) { Text("Actualizar") }
        }

        Text(
            "Todo lo que aparece aquí se guarda solo en este dispositivo. Nada se envía a " +
                "ningún servidor.",
            style = MaterialTheme.typography.bodySmall,
            color = JarvisTextSecondary
        )

        ElevatedCard(modifier = Modifier.fillMaxWidth().weight(1f)) {
            Text(
                summary,
                modifier = Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
                style = MaterialTheme.typography.bodySmall
            )
        }

        Button(onClick = { showClearConfirm = true }) { Text("CLEAR MEMORY") }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Borrar toda la memoria") },
            text = {
                Text(
                    "Esto borrará la palabra de activación, los comandos personalizados, las " +
                        "automatizaciones y el contexto reciente. La Connection Key y la frase del " +
                        "Modo Serio se gestionan aparte, en SETTINGS y DEVICES. Esta acción no se " +
                        "puede deshacer."
                )
            },
            confirmButton = {
                TextButton(onClick = { showClearConfirm = false; onClearAll() }) { Text("Borrar todo") }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) { Text("Cancelar") }
            }
        )
    }
}
