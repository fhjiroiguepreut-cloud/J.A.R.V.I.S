package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.tools.Automation
import com.jarvis.assistant.tools.CommandStatus
import com.jarvis.assistant.ui.theme.JarvisTextSecondary

@Composable
fun AutomationsScreen(
    automations: List<Automation>,
    onAdd: () -> Unit,
    onDelete: (Automation) -> Unit,
    onToggleStatus: (Automation) -> Unit,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Volver") }
            Text("AUTOMATIONS", style = MaterialTheme.typography.titleMedium)
            Button(onClick = onAdd) { Text("+ Añadir") }
        }

        Spacer(Modifier.height(12.dp))

        if (automations.isEmpty()) {
            Text(
                "Todavía no ha creado ninguna automatización. \"Cuando ocurra X, realiza Y.\"",
                color = JarvisTextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(automations) { automation ->
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(automation.trigger.label, style = MaterialTheme.typography.titleSmall)
                            Text(
                                if (automation.status == CommandStatus.ENABLED) "ENABLED" else "DISABLED",
                                style = MaterialTheme.typography.labelSmall,
                                color = JarvisTextSecondary
                            )
                        }
                        Text(
                            "Acción: ${automation.actionToolId}" +
                                if (automation.requiresConfirmation) " (con confirmación)" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = JarvisTextSecondary
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { onToggleStatus(automation) }) {
                                Text(if (automation.status == CommandStatus.ENABLED) "Desactivar" else "Activar")
                            }
                            TextButton(onClick = { onDelete(automation) }) { Text("Eliminar") }
                        }
                    }
                }
            }
        }
    }
}
