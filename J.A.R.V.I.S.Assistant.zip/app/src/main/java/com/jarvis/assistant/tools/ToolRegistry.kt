package com.jarvis.assistant.tools

/**
 * SISTEMA DE HERRAMIENTAS — Fase 2
 *
 * Cada herramienta que J.A.R.V.I.S. puede usar se modela como un [JarvisTool].
 * El [ToolRegistry] es el catálogo central; el [ToolExecutor] es quien
 * realmente las invoca, registrando cada ejecución en el ACTIVITY LOG.
 *
 * IMPORTANTE: en esta fase se registran las herramientas y su contrato,
 * pero solo se implementa de verdad la ejecución de aquellas que ya tienen
 * lógica real (ver [ToolExecutor]). El resto responde NOT_IMPLEMENTED:
 * J.A.R.V.I.S. nunca simula una acción que no puede realizar.
 */

enum class ToolId {
    FILE_SEARCH, FILE_READ, FILE_COPY, FILE_MOVE, FILE_SHARE, FILE_TRANSFER,
    DEVICE_CONNECT, DEVICE_DISCONNECT,
    APP_OPEN, APP_CONTROL,
    VOICE_OUTPUT,
    SYSTEM_INFO,
    WEB_SEARCH,
    LOCAL_MEMORY,
    TASK_MANAGER,
    MESSAGING,
    CALLS
}

enum class ToolSecurityLevel { NORMAL, IMPORTANT, SENSITIVE }

data class ToolParameter(
    val name: String,
    val required: Boolean = true,
    val description: String = ""
)

data class JarvisTool(
    val id: ToolId,
    val displayName: String,
    val description: String,
    val parameters: List<ToolParameter>,
    val requiredPermissions: List<String>,
    val securityLevel: ToolSecurityLevel
)

sealed class ToolResult {
    data class Success(val message: String) : ToolResult()
    data class Failure(val reason: String) : ToolResult()
    data class NotImplemented(val toolId: ToolId) : ToolResult()
    data class PermissionRequired(val permission: String) : ToolResult()
}

/** Catálogo central de herramientas disponibles (contrato, no implementación). */
object ToolRegistry {
    val all: List<JarvisTool> = listOf(
        JarvisTool(
            ToolId.FILE_SEARCH, "Buscar archivo",
            "Busca archivos por nombre en el almacenamiento autorizado.",
            listOf(ToolParameter("query", description = "Nombre o parte del nombre a buscar")),
            listOf("READ_MEDIA_IMAGES", "READ_MEDIA_AUDIO", "READ_MEDIA_VIDEO"),
            ToolSecurityLevel.NORMAL
        ),
        JarvisTool(
            ToolId.FILE_READ, "Leer archivo",
            "Lee el contenido de un archivo compatible ya localizado.",
            listOf(ToolParameter("uri")),
            listOf("READ_MEDIA_IMAGES", "READ_MEDIA_AUDIO", "READ_MEDIA_VIDEO"),
            ToolSecurityLevel.NORMAL
        ),
        JarvisTool(
            ToolId.FILE_COPY, "Copiar archivo",
            "Copia un archivo a otra ubicación autorizada.",
            listOf(ToolParameter("uri"), ToolParameter("destination")),
            listOf("READ_MEDIA_IMAGES"),
            ToolSecurityLevel.NORMAL
        ),
        JarvisTool(
            ToolId.FILE_MOVE, "Mover archivo",
            "Mueve un archivo cuando existe permiso de escritura.",
            listOf(ToolParameter("uri"), ToolParameter("destination")),
            listOf("READ_MEDIA_IMAGES"),
            ToolSecurityLevel.IMPORTANT
        ),
        JarvisTool(
            ToolId.FILE_SHARE, "Compartir archivo",
            "Comparte un archivo mediante el selector de Android.",
            listOf(ToolParameter("uri")),
            emptyList(),
            ToolSecurityLevel.NORMAL
        ),
        JarvisTool(
            ToolId.FILE_TRANSFER, "Transferir archivo",
            "Envía un archivo a un dispositivo J.A.R.V.I.S. autorizado (Fase 5).",
            listOf(ToolParameter("uri"), ToolParameter("deviceId")),
            listOf("NEARBY_WIFI_DEVICES", "BLUETOOTH_CONNECT"),
            ToolSecurityLevel.IMPORTANT
        ),
        JarvisTool(
            ToolId.DEVICE_CONNECT, "Conectar dispositivo",
            "Empareja este dispositivo con otro J.A.R.V.I.S. mediante Connection Key (Fase 4).",
            listOf(ToolParameter("connectionKey")),
            listOf("NEARBY_WIFI_DEVICES", "BLUETOOTH_CONNECT"),
            ToolSecurityLevel.SENSITIVE
        ),
        JarvisTool(
            ToolId.DEVICE_DISCONNECT, "Desconectar dispositivo",
            "Revoca el vínculo con un dispositivo emparejado.",
            listOf(ToolParameter("deviceId")),
            emptyList(),
            ToolSecurityLevel.IMPORTANT
        ),
        JarvisTool(
            ToolId.APP_OPEN, "Abrir aplicación",
            "Abre una app instalada por nombre.",
            listOf(ToolParameter("appName")),
            emptyList(),
            ToolSecurityLevel.NORMAL
        ),
        JarvisTool(
            ToolId.APP_CONTROL, "Controlar aplicación",
            "Envía una acción a una app compatible.",
            listOf(ToolParameter("appName"), ToolParameter("action")),
            emptyList(),
            ToolSecurityLevel.IMPORTANT
        ),
        JarvisTool(
            ToolId.VOICE_OUTPUT, "Salida de voz",
            "Hace que J.A.R.V.I.S. hable un texto concreto.",
            listOf(ToolParameter("text")),
            emptyList(),
            ToolSecurityLevel.NORMAL
        ),
        JarvisTool(
            ToolId.SYSTEM_INFO, "Información del sistema",
            "Reporta batería, almacenamiento y estado de conexión.",
            emptyList(),
            emptyList(),
            ToolSecurityLevel.NORMAL
        ),
        JarvisTool(
            ToolId.WEB_SEARCH, "Búsqueda web",
            "Busca en internet. Requiere conexión (ONLINE MODE).",
            listOf(ToolParameter("query")),
            emptyList(),
            ToolSecurityLevel.NORMAL
        ),
        JarvisTool(
            ToolId.LOCAL_MEMORY, "Memoria local",
            "Lee o escribe en la memoria local de J.A.R.V.I.S.",
            listOf(ToolParameter("key"), ToolParameter("value", required = false)),
            emptyList(),
            ToolSecurityLevel.NORMAL
        ),
        JarvisTool(
            ToolId.TASK_MANAGER, "Gestor de tareas",
            "Crea, lista o completa tareas/recordatorios.",
            listOf(ToolParameter("action"), ToolParameter("task", required = false)),
            emptyList(),
            ToolSecurityLevel.NORMAL
        ),
        JarvisTool(
            ToolId.MESSAGING, "Mensajería",
            "Envía un mensaje mediante servicios autorizados (Fase 6).",
            listOf(ToolParameter("target"), ToolParameter("message")),
            listOf("SEND_SMS"),
            ToolSecurityLevel.SENSITIVE
        ),
        JarvisTool(
            ToolId.CALLS, "Llamadas",
            "Inicia una llamada telefónica (Fase 6).",
            listOf(ToolParameter("contact")),
            listOf("CALL_PHONE"),
            ToolSecurityLevel.SENSITIVE
        )
    )

    fun byId(id: ToolId): JarvisTool = all.first { it.id == id }
}
