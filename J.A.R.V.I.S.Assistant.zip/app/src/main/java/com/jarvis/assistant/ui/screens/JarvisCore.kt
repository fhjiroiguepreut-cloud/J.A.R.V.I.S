package com.jarvis.assistant.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.core.JarvisState
import com.jarvis.assistant.ui.theme.JarvisAmber
import com.jarvis.assistant.ui.theme.JarvisCyan
import com.jarvis.assistant.ui.theme.JarvisCyanDim
import com.jarvis.assistant.ui.theme.JarvisRed

/**
 * Núcleo visual de J.A.R.V.I.S.: anillos concéntricos que pulsan/giran
 * de forma distinta según el estado actual, evitando una interfaz llena
 * de botones tal como se pidió en la especificación.
 */
@Composable
fun JarvisCore(state: JarvisState, modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "core")

    val pulseSpeedMs = when (state) {
        JarvisState.LISTENING -> 700
        JarvisState.THINKING -> 900
        JarvisState.EXECUTING -> 500
        JarvisState.VERIFYING -> 1100
        JarvisState.ERROR, JarvisState.ACTION_BLOCKED -> 400
        else -> 2200
    }

    val coreColor = when (state) {
        JarvisState.ERROR, JarvisState.ACTION_BLOCKED -> JarvisRed
        JarvisState.PERMISSION_REQUIRED -> JarvisAmber
        JarvisState.OFFLINE -> JarvisCyanDim
        else -> JarvisCyan
    }

    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(pulseSpeedMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing)
        ),
        label = "rotation"
    )

    Canvas(modifier = modifier.size(220.dp)) {
        val center = Offset(size.width / 2, size.height / 2)
        val baseRadius = size.minDimension / 2.4f

        // Anillo exterior giratorio
        rotate(rotation) {
            drawCircle(
                color = coreColor.copy(alpha = 0.35f),
                radius = baseRadius,
                center = center,
                style = Stroke(width = 3f)
            )
        }

        // Núcleo pulsante
        drawCircle(
            color = coreColor.copy(alpha = 0.9f),
            radius = baseRadius * 0.55f * pulse,
            center = center,
            style = Stroke(width = 5f)
        )

        drawCircle(
            color = coreColor.copy(alpha = 0.15f),
            radius = baseRadius * 0.55f * pulse,
            center = center
        )
    }
}
