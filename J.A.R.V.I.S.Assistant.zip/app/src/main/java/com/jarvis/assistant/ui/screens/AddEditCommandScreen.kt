package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.tools.*

/**
 * ADD COMMAND / EDIT COMMAND
 *
 * El usuario define TODO: no hay ningún trigger ni acción preprogramada.
 * "actionId" se elige entre las herramientas reales del ToolRegistry para
 * que el comando quede conectado a algo que J.A.R.V.I.S. puede ejecutar.
 */
@Composable
fun AddEditCommandScreen(
    existing: CustomCommand?,
    onSave: (CustomCommand) -> Unit,
    onCancel: () -> Unit
) {
    var trigger by remember { mutableStateOf(existing?.trigger ?: "") }
    var actionId by remember { mutableStateOf(existing?.actionId ?: ToolRegistry.all.first().id.name) }
    var voiceResponse by remember { mutableStateOf(existing?.voiceResponse ?: "") }
    var mode by remember { mutableStateOf(existing?.mode ?: CommandMode.NORMAL) }
    var securityLevel by remember { mutableStateOf(existing?.securityLevel ?: SecurityLevel.NORMAL) }
    var requiresConfirmation by remember { mutableStateOf(existing?.requiresConfirmation ?: false) }
    var status by remember { mutableStateOf(existing?.status ?: CommandStatus.ENABLED) }

    var actionMenuExpanded by remember { mutableStateOf(false) }
    var modeMenuExpanded by remember { mutableStateOf(false) }
    var securityMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            if (existing == null) "ADD COMMAND" else "EDIT COMMAND",
            style = MaterialTheme.typography.titleMedium
        )

        OutlinedTextField(
            value = trigger,
            onValueChange = { trigger = it },
            label = { Text("COMMAND (palabra, número o frase)") },
            modifier = Modifier.fillMaxWidth()
        )

        // ACTION — elegido entre las herramientas reales disponibles
        ExposedDropdownMenuBox(
            expanded = actionMenuExpanded,
            onExpandedChange = { actionMenuExpanded = !actionMenuExpanded }
        ) {
            OutlinedTextField(
                value = actionId,
                onValueChange = {},
                readOnly = true,
                label = { Text("ACTION") },
                modifier = Modifier.fillMaxWidth().menuAnchor()
            )
            ExposedDropdownMenu(
                expanded = actionMenuExpanded,
                onDismissRequest = { actionMenuExpanded = false }
            ) {
                ToolRegistry.all.forEach { tool ->
                    DropdownMenuItem(
                        text = { Text("${tool.id.name} — ${tool.displayName}") },
                        onClick = {
                            actionId = tool.id.name
                            actionMenuExpanded = false
                        }
                    )
                }
            }
        }

        OutlinedTextField(
            value = voiceResponse,
            onValueChange = { voiceResponse = it },
            label = { Text("VOICE RESPONSE") },
            modifier = Modifier.fillMaxWidth()
        )

        // MODE
        ExposedDropdownMenuBox(
            expanded = modeMenuExpanded,
            onExpandedChange = { modeMenuExpanded = !modeMenuExpanded }
        ) {
            OutlinedTextField(
                value = mode.name,
                onValueChange = {},
                readOnly = true,
                label = { Text("MODE") },
                modifier = Modifier.fillMaxWidth().menuAnchor()
            )
            ExposedDropdownMenu(expanded = modeMenuExpanded, onDismissRequest = { modeMenuExpanded = false }) {
                CommandMode.entries.forEach { m ->
                    DropdownMenuItem(text = { Text(m.name) }, onClick = { mode = m; modeMenuExpanded = false })
                }
            }
        }

        // SECURITY LEVEL
        ExposedDropdownMenuBox(
            expanded = securityMenuExpanded,
            onExpandedChange = { securityMenuExpanded = !securityMenuExpanded }
        ) {
            OutlinedTextField(
                value = securityLevel.name,
                onValueChange = {},
                readOnly = true,
                label = { Text("SECURITY LEVEL") },
                modifier = Modifier.fillMaxWidth().menuAnchor()
            )
            ExposedDropdownMenu(expanded = securityMenuExpanded, onDismissRequest = { securityMenuExpanded = false }) {
                SecurityLevel.entries.forEach { s ->
                    DropdownMenuItem(text = { Text(s.name) }, onClick = { securityLevel = s; securityMenuExpanded = false })
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = requiresConfirmation, onCheckedChange = { requiresConfirmation = it })
            Text("CONFIRMATION requerida antes de ejecutar")
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = status == CommandStatus.ENABLED,
                onCheckedChange = { status = if (it) CommandStatus.ENABLED else CommandStatus.DISABLED }
            )
            Text("STATUS: ${status.name}")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                enabled = trigger.isNotBlank() && voiceResponse.isNotBlank(),
                onClick = {
                    onSave(
                        CustomCommand(
                            trigger = trigger.trim(),
                            actionId = actionId,
                            voiceResponse = voiceResponse.trim(),
                            mode = mode,
                            requiresConfirmation = requiresConfirmation,
                            securityLevel = securityLevel,
                            status = status
                        )
                    )
                }
            ) { Text("Guardar") }
            OutlinedButton(onClick = onCancel) { Text("Cancelar") }
        }
    }
}
