package com.jarvis.assistant.tools

/**
 * AUTOMATION ENGINE — Fase 8
 *
 * Recibe eventos reales del resto de la app (ver dónde se llama a [onEvent]
 * en MainActivity: conexión de dispositivo, archivo recibido, etc.) y
 * ejecuta las automatizaciones activas que coincidan con ese disparador.
 *
 * Las automatizaciones SENSITIVE o marcadas con confirmación NO se ejecutan
 * solas: se devuelven en el resultado como pendientes, para que la UI
 * muestre el mismo diálogo de confirmación que ya usan los comandos
 * personalizados (sección 22: "deben respetar... confirmaciones").
 */
class AutomationEngine(
    private val automations: () -> List<Automation>,
    private val toolExecutor: ToolExecutor,
    private val activityLog: ActivityLog
) {
    // Fase 9 (seguridad): evita que un mismo disparador dispare la misma
    // automatización varias veces en una ráfaga corta (p. ej. un callback de
    // conexión que se invoca más de una vez para el mismo evento real).
    private val lastFiredAt = mutableMapOf<String, Long>()
    private val debounceWindowMs = 3000L

    fun onEvent(trigger: AutomationTrigger, contextParams: Map<String, String> = emptyMap()): List<Automation> {
        val matches = automations().filter { it.trigger == trigger && it.status == CommandStatus.ENABLED }
        val pendingConfirmation = mutableListOf<Automation>()

        matches.forEach { automation ->
            val now = System.currentTimeMillis()
            val last = lastFiredAt[automation.id]
            if (last != null && now - last < debounceWindowMs) return@forEach
            lastFiredAt[automation.id] = now

            if (automation.requiresConfirmation || automation.securityLevel == SecurityLevel.SENSITIVE) {
                pendingConfirmation.add(automation)
            } else {
                runAutomation(automation, contextParams)
            }
        }
        return pendingConfirmation
    }

    fun runAutomation(automation: Automation, contextParams: Map<String, String> = emptyMap()) {
        val toolId = ToolId.entries.firstOrNull { it.name == automation.actionToolId } ?: run {
            activityLog.record("AUTOMATION", "${automation.trigger.label} → ${automation.actionToolId}", "NOT_IMPLEMENTED")
            return
        }
        val mergedParams = automation.actionParams + contextParams
        toolExecutor.execute(toolId, mergedParams)
    }
}
