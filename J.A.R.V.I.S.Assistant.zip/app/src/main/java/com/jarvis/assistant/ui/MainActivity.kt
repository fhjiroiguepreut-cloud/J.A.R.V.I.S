package com.jarvis.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.jarvis.assistant.ai.AiBrain
import com.jarvis.assistant.ai.JarvisIntent
import com.jarvis.assistant.ai.JarvisResponse
import com.jarvis.assistant.communication.CommsRepository
import com.jarvis.assistant.core.JarvisState
import com.jarvis.assistant.devices.AuthorizedDevice
import com.jarvis.assistant.devices.ConnectionKeyManager
import com.jarvis.assistant.devices.NearbyPairingManager
import com.jarvis.assistant.files.FilesRepository
import com.jarvis.assistant.memory.MemoryManager
import com.jarvis.assistant.tools.*
import com.jarvis.assistant.ui.screens.*
import com.jarvis.assistant.ui.theme.JarvisBackground
import com.jarvis.assistant.ui.theme.JarvisTextSecondary
import com.jarvis.assistant.ui.theme.JarvisTheme
import com.jarvis.assistant.voice.JarvisListeningService
import com.jarvis.assistant.voice.JarvisVoiceEngine
import com.jarvis.assistant.voice.WakeEvents
import com.jarvis.assistant.voice.WakeKind
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

private enum class Screen { HOME, COMMANDS, ADD_COMMAND, LOG, FILES, DEVICES, COMMS, SETTINGS, AUTOMATIONS, ADD_AUTOMATION, MEMORY }

class MainActivity : ComponentActivity() {

    private lateinit var voiceEngine: JarvisVoiceEngine
    private lateinit var memoryManager: MemoryManager
    private lateinit var activityLog: ActivityLog
    private lateinit var filesRepository: FilesRepository
    private lateinit var connectionKeyManager: ConnectionKeyManager
    private lateinit var commsRepository: CommsRepository

    private val requestMicPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> micPermissionGranted.value = granted }

    private val requestMediaPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results -> mediaPermissionGranted.value = results.values.any { it } }

    private val requestDevicesPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results -> devicesPermissionGranted.value = results.values.all { it } }

    private val requestSmsPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> smsPermissionGranted.value = granted }

    private val requestCallPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> callPermissionGranted.value = granted }

    private val requestNotificationsPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> notificationsPermissionGranted.value = granted }

    private val micPermissionGranted = mutableStateOf(false)
    private val mediaPermissionGranted = mutableStateOf(false)
    private val devicesPermissionGranted = mutableStateOf(false)
    private val smsPermissionGranted = mutableStateOf(false)
    private val callPermissionGranted = mutableStateOf(false)
    private val notificationsPermissionGranted = mutableStateOf(false)
    private val listeningServiceActive = mutableStateOf(false)

    private val mediaPermissions = arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_AUDIO,
        Manifest.permission.READ_MEDIA_VIDEO
    )

    // Nearby Connections necesita permisos distintos según la versión de Android.
    private val devicesPermissions: Array<String>
        get() = if (android.os.Build.VERSION.SDK_INT >= 33) {
            arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.NEARBY_WIFI_DEVICES
            )
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        voiceEngine = JarvisVoiceEngine(applicationContext)
        memoryManager = MemoryManager(applicationContext)
        activityLog = ActivityLog()
        filesRepository = FilesRepository(applicationContext)
        connectionKeyManager = ConnectionKeyManager(applicationContext)
        commsRepository = CommsRepository(applicationContext)

        micPermissionGranted.value = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        mediaPermissionGranted.value = mediaPermissions.any {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

        devicesPermissionGranted.value = devicesPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

        smsPermissionGranted.value = ContextCompat.checkSelfPermission(
            this, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED

        callPermissionGranted.value = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        notificationsPermissionGranted.value = if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else true

        setContent {
            JarvisTheme {
                var screen by remember { mutableStateOf(Screen.HOME) }
                var state by remember { mutableStateOf(JarvisState.STANDING_BY) }
                var transcript by remember { mutableStateOf("") }
                var lastResponse by remember { mutableStateOf("") }
                var commands by remember { mutableStateOf(listOf<CustomCommand>()) }
                var editingCommand by remember { mutableStateOf<CustomCommand?>(null) }
                var pendingConfirmation by remember { mutableStateOf<CustomCommand?>(null) }
                var connectionKey by remember { mutableStateOf<String?>(null) }
                var devices by remember { mutableStateOf(listOf<AuthorizedDevice>()) }
                var deviceMessages by remember { mutableStateOf(listOf<com.jarvis.assistant.ui.screens.DeviceMessage>()) }
                var isSeriousMode by remember { mutableStateOf(false) }
                var activationPhrase by remember { mutableStateOf("jarvis") }
                var seriousModePhrase by remember { mutableStateOf<String?>(null) }
                var automations by remember { mutableStateOf(listOf<Automation>()) }
                var pendingAutomationConfirmation by remember { mutableStateOf<Automation?>(null) }
                val scope = rememberCoroutineScope()

                var deviceEventTrigger by remember { mutableStateOf<Pair<com.jarvis.assistant.tools.AutomationTrigger, Map<String, String>>?>(null) }

                val pairingManager = remember {
                    NearbyPairingManager(
                        context = applicationContext,
                        localConnectionKeyHash = { connectionKey?.let { connectionKeyManager.hashOf(it) } },
                        onDeviceUpdated = { updated ->
                            devices = devices.filterNot { it.endpointId == updated.endpointId } + updated
                            when (updated.status) {
                                com.jarvis.assistant.devices.DeviceConnectionStatus.CONNECTED ->
                                    deviceEventTrigger = com.jarvis.assistant.tools.AutomationTrigger.DEVICE_CONNECTED to mapOf("deviceId" to updated.endpointId)
                                com.jarvis.assistant.devices.DeviceConnectionStatus.DISCONNECTED ->
                                    deviceEventTrigger = com.jarvis.assistant.tools.AutomationTrigger.DEVICE_DISCONNECTED to mapOf("deviceId" to updated.endpointId)
                                else -> {}
                            }
                        },
                        onLog = { message -> activityLog.record("DEVICE_CONNECT", message, "INFO") },
                        onFileReceived = { name, _ ->
                            lastResponse = "Archivo recibido y transferencia completada: $name."
                            voiceEngine.speak(lastResponse)
                            deviceEventTrigger = com.jarvis.assistant.tools.AutomationTrigger.FILE_RECEIVED to mapOf("fileName" to name)
                        },
                        onMessageReceived = { endpointId, text ->
                            deviceMessages = deviceMessages + com.jarvis.assistant.ui.screens.DeviceMessage(fromMe = false, text = text)
                            deviceEventTrigger = com.jarvis.assistant.tools.AutomationTrigger.MESSAGE_RECEIVED to mapOf("text" to text, "deviceId" to endpointId)
                        }
                    )
                }

                val toolExecutor = remember {
                    ToolExecutor(
                        activityLog = activityLog,
                        speak = { voiceEngine.speak(it) },
                        readMemory = { key -> memoryManager.getMemoryValue(key) },
                        writeMemory = { key, value -> scope.launch { memoryManager.setMemoryValue(key, value) } },
                        systemInfoProvider = { systemInfoSummary() },
                        filesRepository = filesRepository,
                        launchIntent = { intent -> startActivity(intent) },
                        pairingManager = pairingManager,
                        connectedDeviceProvider = { devices.firstOrNull { it.status == com.jarvis.assistant.devices.DeviceConnectionStatus.CONNECTED }?.endpointId },
                        commsRepository = commsRepository
                    )
                }

                val automationEngine = remember(automations) {
                    com.jarvis.assistant.tools.AutomationEngine(
                        automations = { automations },
                        toolExecutor = toolExecutor,
                        activityLog = activityLog
                    )
                }

                val brain = remember(commands) {
                    AiBrain(
                        findCommand = { input -> CustomCommandMatcher { commands }.match(input) },
                        executeToolAction = { toolId, params -> toolExecutor.execute(toolId, params) }
                    )
                }

                LaunchedEffect(deviceEventTrigger) {
                    deviceEventTrigger?.let { (trigger, params) ->
                        pendingAutomationConfirmation = automationEngine.onEvent(trigger, params).firstOrNull()
                    }
                }

                LaunchedEffect(Unit) {
                    voiceEngine.init {
                        voiceEngine.speak("J.A.R.V.I.S. en línea.")
                    }
                    memoryManager.loadGenericMemoryIntoCache()
                    commands = CommandSerializer.fromJson(memoryManager.customCommandsJson.first())
                    connectionKey = connectionKeyManager.connectionKey.first()
                    activationPhrase = memoryManager.activationPhrase.first()
                    seriousModePhrase = connectionKeyManager.seriousModePhrase.value
                    automations = AutomationSerializer.fromJson(memoryManager.automationsJson.first())
                    pendingAutomationConfirmation = automationEngine.onEvent(com.jarvis.assistant.tools.AutomationTrigger.APP_STARTED).firstOrNull()
                }

                LaunchedEffect(Unit) {
                    WakeEvents.events.collect { event ->
                        when (event.kind) {
                            WakeKind.NORMAL -> {
                                isSeriousMode = false
                                voiceEngine.applyNormalTone()
                                state = JarvisState.LISTENING
                                lastResponse = "Hola señor, ¿cómo puedo ayudarle hoy?"
                                voiceEngine.speak(lastResponse)
                            }
                            WakeKind.SERIOUS -> {
                                isSeriousMode = true
                                voiceEngine.applySeriousTone()
                                state = JarvisState.LISTENING
                                lastResponse = "Hola señor, ¿cómo puedo ayudarle hoy?"
                                voiceEngine.speak(lastResponse)
                                pendingAutomationConfirmation = automationEngine.onEvent(com.jarvis.assistant.tools.AutomationTrigger.SERIOUS_MODE_ACTIVATED).firstOrNull()
                            }
                        }
                    }
                }

                DisposableEffect(Unit) {
                    onDispose { pairingManager.stopAll() }
                }

                fun persistCommands(updated: List<CustomCommand>) {
                    commands = updated
                    scope.launch { memoryManager.saveCustomCommandsJson(CommandSerializer.toJson(updated)) }
                }

                fun handleFinalText(finalText: String) {
                    transcript = finalText
                    state = JarvisState.THINKING
                    val intent = brain.resolveIntent(finalText)
                    when (val response = brain.respond(intent)) {
                        is JarvisResponse.Speak -> {
                            state = response.newState
                            lastResponse = response.text
                            voiceEngine.speak(response.text)
                            scope.launch { memoryManager.appendRecentContext("USER: $finalText | JARVIS: ${response.text}") }
                        }
                        is JarvisResponse.NeedsConfirmation -> {
                            pendingConfirmation = response.command
                            lastResponse = "¿Confirma la acción \"${response.command.trigger}\", señor?"
                            voiceEngine.speak(lastResponse)
                            state = JarvisState.VERIFYING
                        }
                        is JarvisResponse.NotImplemented -> {
                            lastResponse = "Esta función todavía no está disponible."
                            voiceEngine.speak(lastResponse)
                            state = JarvisState.STANDING_BY
                        }
                    }
                }

                when (screen) {
                    Screen.HOME -> JarvisHomeScreen(
                        state = state,
                        transcript = transcript,
                        lastResponse = lastResponse,
                        micGranted = micPermissionGranted.value,
                        isSeriousMode = isSeriousMode,
                        pendingConfirmation = pendingConfirmation,
                        onRequestMic = { requestMicPermission.launch(Manifest.permission.RECORD_AUDIO) },
                        onActivate = {
                            if (!micPermissionGranted.value) {
                                state = JarvisState.PERMISSION_REQUIRED
                                return@JarvisHomeScreen
                            }
                            state = JarvisState.LISTENING
                            voiceEngine.startListening(
                                onPartial = { transcript = it },
                                onResult = { handleFinalText(it) },
                                onError = {
                                    state = JarvisState.ERROR
                                    lastResponse = "Error de reconocimiento de voz: $it"
                                }
                            )
                        },
                        onConfirm = {
                            pendingConfirmation?.let { command ->
                                val response = brain.runCommand(command)
                                if (response is JarvisResponse.Speak) {
                                    lastResponse = response.text
                                    voiceEngine.speak(response.text)
                                    state = response.newState
                                }
                            }
                            pendingConfirmation = null
                        },
                        onCancelConfirmation = {
                            pendingConfirmation = null
                            lastResponse = "Acción cancelada, señor."
                            voiceEngine.speak(lastResponse)
                            state = JarvisState.STANDING_BY
                        },
                        onOpenCommands = { screen = Screen.COMMANDS },
                        onOpenLog = { screen = Screen.LOG },
                        onOpenFiles = { screen = Screen.FILES },
                        onOpenDevices = { screen = Screen.DEVICES },
                        onOpenComms = { screen = Screen.COMMS },
                        onOpenSettings = { screen = Screen.SETTINGS },
                        onOpenAutomations = { screen = Screen.AUTOMATIONS },
                        onOpenMemory = { screen = Screen.MEMORY },
                        pendingAutomationConfirmation = pendingAutomationConfirmation,
                        onConfirmAutomation = {
                            pendingAutomationConfirmation?.let { automationEngine.runAutomation(it) }
                            pendingAutomationConfirmation = null
                        },
                        onCancelAutomation = { pendingAutomationConfirmation = null }
                    )

                    Screen.COMMANDS -> CustomCommandsScreen(
                        commands = commands,
                        onAdd = { editingCommand = null; screen = Screen.ADD_COMMAND },
                        onEdit = { editingCommand = it; screen = Screen.ADD_COMMAND },
                        onDelete = { toDelete -> persistCommands(commands.filterNot { it == toDelete }) },
                        onToggleStatus = { toToggle ->
                            persistCommands(commands.map {
                                if (it == toToggle) it.copy(
                                    status = if (it.status == CommandStatus.ENABLED) CommandStatus.DISABLED else CommandStatus.ENABLED
                                ) else it
                            })
                        },
                        onTest = { handleFinalText(it.trigger) },
                        onBack = { screen = Screen.HOME }
                    )

                    Screen.ADD_COMMAND -> AddEditCommandScreen(
                        existing = editingCommand,
                        onSave = { newCommand ->
                            val updated = if (editingCommand == null) {
                                commands + newCommand
                            } else {
                                commands.map { if (it == editingCommand) newCommand else it }
                            }
                            persistCommands(updated)
                            screen = Screen.COMMANDS
                        },
                        onCancel = { screen = Screen.COMMANDS }
                    )

                    Screen.LOG -> ActivityLogScreen(
                        entries = activityLog.entries,
                        onBack = { screen = Screen.HOME }
                    )

                    Screen.FILES -> FilesScreen(
                        mediaPermissionGranted = mediaPermissionGranted.value,
                        onRequestMediaPermission = { requestMediaPermissions.launch(mediaPermissions) },
                        filesRepository = filesRepository,
                        toolExecutor = toolExecutor,
                        onBack = { screen = Screen.HOME }
                    )

                    Screen.DEVICES -> DevicesScreen(
                        connectionKey = connectionKey,
                        devicesPermissionGranted = devicesPermissionGranted.value,
                        onRequestDevicesPermission = { requestDevicesPermissions.launch(devicesPermissions) },
                        devices = devices,
                        onGenerateKey = { connectionKey = connectionKeyManager.generateNewKey() },
                        onSetKeyManually = { key -> connectionKeyManager.setKeyManually(key); connectionKey = key.trim().uppercase() },
                        onRevokeKey = { connectionKeyManager.revoke(); connectionKey = null },
                        onStartPairing = { toolExecutor.execute(ToolId.DEVICE_CONNECT, emptyMap()) },
                        onDisconnect = { device -> toolExecutor.execute(ToolId.DEVICE_DISCONNECT, mapOf("deviceId" to device.endpointId)) },
                        onBack = { screen = Screen.HOME }
                    )

                    Screen.COMMS -> CommunicationScreen(
                        deviceConnected = devices.any { it.status == com.jarvis.assistant.devices.DeviceConnectionStatus.CONNECTED },
                        deviceMessages = deviceMessages,
                        onSendDeviceMessage = { text ->
                            val result = toolExecutor.execute(ToolId.MESSAGING, mapOf("target" to "device", "message" to text))
                            if (result is ToolResult.Success) {
                                deviceMessages = deviceMessages + com.jarvis.assistant.ui.screens.DeviceMessage(fromMe = true, text = text)
                            }
                        },
                        smsPermissionGranted = smsPermissionGranted.value,
                        onRequestSmsPermission = { requestSmsPermission.launch(Manifest.permission.SEND_SMS) },
                        onSendSms = { number, text -> toolExecutor.execute(ToolId.MESSAGING, mapOf("target" to number, "message" to text)) },
                        callPermissionGranted = callPermissionGranted.value,
                        onRequestCallPermission = { requestCallPermission.launch(Manifest.permission.CALL_PHONE) },
                        onCall = { number -> toolExecutor.execute(ToolId.CALLS, mapOf("contact" to number)) },
                        onBack = { screen = Screen.HOME }
                    )

                    Screen.SETTINGS -> VoiceSecuritySettingsScreen(
                        activationPhrase = activationPhrase,
                        seriousModePhrase = seriousModePhrase,
                        listeningServiceActive = listeningServiceActive.value,
                        micPermissionGranted = micPermissionGranted.value,
                        notificationsPermissionGranted = notificationsPermissionGranted.value,
                        onRequestPermissions = {
                            if (!micPermissionGranted.value) requestMicPermission.launch(Manifest.permission.RECORD_AUDIO)
                            if (Build.VERSION.SDK_INT >= 33 && !notificationsPermissionGranted.value) {
                                requestNotificationsPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        },
                        onSaveActivationPhrase = { phrase ->
                            activationPhrase = phrase
                            scope.launch { memoryManager.setActivationPhrase(phrase) }
                        },
                        onSaveSeriousModePhrase = { phrase ->
                            seriousModePhrase = phrase
                            connectionKeyManager.setSeriousModePhrase(phrase)
                        },
                        onToggleListeningService = { active ->
                            listeningServiceActive.value = active
                            if (active) JarvisListeningService.start(applicationContext)
                            else JarvisListeningService.stop(applicationContext)
                        },
                        onBack = { screen = Screen.HOME }
                    )

                    Screen.AUTOMATIONS -> AutomationsScreen(
                        automations = automations,
                        onAdd = { screen = Screen.ADD_AUTOMATION },
                        onDelete = { toDelete ->
                            val updated = automations.filterNot { it == toDelete }
                            automations = updated
                            scope.launch { memoryManager.saveAutomationsJson(AutomationSerializer.toJson(updated)) }
                        },
                        onToggleStatus = { toToggle ->
                            val updated = automations.map {
                                if (it == toToggle) it.copy(
                                    status = if (it.status == CommandStatus.ENABLED) CommandStatus.DISABLED else CommandStatus.ENABLED
                                ) else it
                            }
                            automations = updated
                            scope.launch { memoryManager.saveAutomationsJson(AutomationSerializer.toJson(updated)) }
                        },
                        onBack = { screen = Screen.HOME }
                    )

                    Screen.ADD_AUTOMATION -> AddAutomationScreen(
                        onSave = { newAutomation ->
                            val updated = automations + newAutomation
                            automations = updated
                            scope.launch { memoryManager.saveAutomationsJson(AutomationSerializer.toJson(updated)) }
                            screen = Screen.AUTOMATIONS
                        },
                        onCancel = { screen = Screen.AUTOMATIONS }
                    )

                    Screen.MEMORY -> {
                        var memorySummary by remember { mutableStateOf("Cargando...") }
                        LaunchedEffect(Unit) { memorySummary = memoryManager.viewMemorySummary() }
                        MemoryScreen(
                            summary = memorySummary,
                            onRefresh = { scope.launch { memorySummary = memoryManager.viewMemorySummary() } },
                            onClearAll = {
                                scope.launch {
                                    memoryManager.clearAll()
                                    commands = emptyList()
                                    automations = emptyList()
                                    activationPhrase = "jarvis"
                                    memorySummary = memoryManager.viewMemorySummary()
                                }
                            },
                            onBack = { screen = Screen.HOME }
                        )
                    }
                }
            }
        }
    }

    private fun systemInfoSummary(): String {
        val batteryManager = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Batería al $level por ciento. Modo local activo."
    }

    override fun onDestroy() {
        voiceEngine.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisHomeScreen(
    state: JarvisState,
    transcript: String,
    lastResponse: String,
    micGranted: Boolean,
    isSeriousMode: Boolean,
    pendingConfirmation: CustomCommand?,
    onRequestMic: () -> Unit,
    onActivate: () -> Unit,
    onConfirm: () -> Unit,
    onCancelConfirmation: () -> Unit,
    onOpenCommands: () -> Unit,
    onOpenLog: () -> Unit,
    onOpenFiles: () -> Unit,
    onOpenDevices: () -> Unit,
    onOpenComms: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAutomations: () -> Unit,
    onOpenMemory: () -> Unit,
    pendingAutomationConfirmation: Automation?,
    onConfirmAutomation: () -> Unit,
    onCancelAutomation: () -> Unit
) {
    Surface(color = JarvisBackground, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("J.A.R.V.I.S.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "JUST A RATHER VERY INTELLIGENT SYSTEM",
                    style = MaterialTheme.typography.labelSmall,
                    color = JarvisTextSecondary
                )
                if (isSeriousMode) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "SERIOUS MODE\nACTIVE",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                JarvisCore(state = state)
                Text(state.label, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                if (transcript.isNotBlank()) {
                    Text("\"$transcript\"", style = MaterialTheme.typography.bodyMedium, color = JarvisTextSecondary)
                }
                if (lastResponse.isNotBlank()) {
                    Text(lastResponse, style = MaterialTheme.typography.bodyLarge)
                }
                if (pendingConfirmation != null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(onClick = onConfirm) { Text("Confirmar") }
                        OutlinedButton(onClick = onCancelConfirmation) { Text("Cancelar") }
                    }
                }
                if (pendingAutomationConfirmation != null) {
                    Text(
                        "Automatización pendiente: \"${pendingAutomationConfirmation.trigger.label}\" → ${pendingAutomationConfirmation.actionToolId}",
                        style = MaterialTheme.typography.bodySmall,
                        color = JarvisTextSecondary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(onClick = onConfirmAutomation) { Text("Confirmar") }
                        OutlinedButton(onClick = onCancelAutomation) { Text("Cancelar") }
                    }
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (!micGranted) {
                    Text(
                        "Se necesita permiso de micrófono para escuchar comandos por voz.",
                        style = MaterialTheme.typography.bodySmall,
                        color = JarvisTextSecondary
                    )
                    Button(onClick = onRequestMic) { Text("Conceder permiso") }
                } else {
                    Button(onClick = onActivate) { Text("Activar J.A.R.V.I.S.") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    TextButton(onClick = onOpenCommands) { Text("CUSTOM COMMANDS") }
                    TextButton(onClick = onOpenLog) { Text("ACTIVITY LOG") }
                    TextButton(onClick = onOpenFiles) { Text("FILES") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    TextButton(onClick = onOpenDevices) { Text("DEVICES") }
                    TextButton(onClick = onOpenComms) { Text("COMMUNICATION") }
                    TextButton(onClick = onOpenSettings) { Text("SETTINGS") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    TextButton(onClick = onOpenAutomations) { Text("AUTOMATIONS") }
                    TextButton(onClick = onOpenMemory) { Text("MEMORY") }
                }
                Text("LOCAL MODE", style = MaterialTheme.typography.labelSmall, color = JarvisTextSecondary)
            }
        }
    }
}
