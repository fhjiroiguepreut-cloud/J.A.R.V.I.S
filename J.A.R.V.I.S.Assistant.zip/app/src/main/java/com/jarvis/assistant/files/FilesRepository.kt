package com.jarvis.assistant.files

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore

data class JarvisFile(
    val uri: Uri,
    val displayName: String,
    val mimeType: String?,
    val sizeBytes: Long
)

/**
 * FILES — Fase 3
 *
 * Trabaja con archivos usando los mecanismos normales y autorizados de
 * Android (MediaStore + Storage Access Framework), respetando el
 * almacenamiento con ámbito (scoped storage). No se accede a ningún archivo
 * fuera de lo que MediaStore expone con los permisos ya concedidos por el
 * usuario (READ_MEDIA_IMAGES / AUDIO / VIDEO).
 *
 * Requiere minSdk 29+ por el uso de MediaStore.Downloads (ver README:
 * el minSdk del proyecto se subió de 26 a 29 en esta fase).
 */
class FilesRepository(private val context: Context) {

    /** FILE_SEARCH — busca por nombre entre los archivos indexados por MediaStore. */
    fun search(query: String, limit: Int = 10): List<JarvisFile> {
        val results = mutableListOf<JarvisFile>()
        val collection = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.SIZE
        )
        val selection = "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$query%")
        val sortOrder = "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"

        try {
            context.contentResolver.query(collection, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                while (cursor.moveToNext() && results.size < limit) {
                    val id = cursor.getLong(idCol)
                    results.add(
                        JarvisFile(
                            uri = ContentUris.withAppendedId(collection, id),
                            displayName = cursor.getString(nameCol) ?: "(sin nombre)",
                            mimeType = cursor.getString(mimeCol),
                            sizeBytes = cursor.getLong(sizeCol)
                        )
                    )
                }
            }
        } catch (e: SecurityException) {
            // Falta permiso: se comunica hacia arriba como lista vacía;
            // el llamador decide si pedir el permiso.
        }
        return results
    }

    /** FILE_READ — solo para archivos de texto plano compatibles; nunca finge leer binarios. */
    fun readAsText(file: JarvisFile, maxChars: Int = 3000): String? {
        val isTextLike = file.mimeType?.startsWith("text/") == true ||
            file.displayName.substringAfterLast('.', "").lowercase() in setOf("txt", "md", "json", "csv", "log")
        if (!isTextLike) return null
        return try {
            context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use {
                it.readText().take(maxChars)
            }
        } catch (e: Exception) {
            null
        }
    }

    /** FILE_COPY — copia el archivo a Download/JARVIS usando MediaStore (sin picker adicional). */
    fun copyToJarvisFolder(file: JarvisFile): Uri? {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, file.displayName)
                put(MediaStore.Downloads.MIME_TYPE, file.mimeType ?: "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/JARVIS")
            }
            val destUri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            context.contentResolver.openInputStream(file.uri)?.use { input ->
                context.contentResolver.openOutputStream(destUri)?.use { output ->
                    input.copyTo(output)
                }
            }
            destUri
        } catch (e: Exception) {
            null
        }
    }

    /** FILE_SHARE — construye el intent de compartir; quien lo ejecute (UI) debe iniciar la actividad. */
    fun buildShareIntent(file: JarvisFile): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = file.mimeType ?: "*/*"
            putExtra(Intent.EXTRA_STREAM, file.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
