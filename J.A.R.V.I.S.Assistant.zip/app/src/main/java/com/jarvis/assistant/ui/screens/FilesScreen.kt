package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.files.FilesRepository
import com.jarvis.assistant.files.JarvisFile
import com.jarvis.assistant.tools.ToolExecutor
import com.jarvis.assistant.tools.ToolId
import com.jarvis.assistant.tools.ToolResult
import com.jarvis.assistant.ui.theme.JarvisTextSecondary

@Composable
fun FilesScreen(
    mediaPermissionGranted: Boolean,
    onRequestMediaPermission: () -> Unit,
    filesRepository: FilesRepository,
    toolExecutor: ToolExecutor,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(listOf<JarvisFile>()) }
    var statusMessage by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Volver") }
            Text("FILES", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.width(64.dp))
        }

        if (!mediaPermissionGranted) {
            Text(
                "J.A.R.V.I.S. necesita permiso para ver tus imágenes, audio o vídeo antes de poder buscarlos.",
                color = JarvisTextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
            Button(onClick = onRequestMediaPermission) { Text("Conceder permiso") }
            return@Column
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Buscar archivo") },
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                results = filesRepository.search(query)
                statusMessage = if (results.isEmpty()) "Sin coincidencias." else "${results.size} resultado(s)."
            }) { Text("Buscar") }
        }

        if (statusMessage.isNotBlank()) {
            Text(statusMessage, style = MaterialTheme.typography.bodySmall, color = JarvisTextSecondary)
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(results) { file ->
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(file.displayName, style = MaterialTheme.typography.titleSmall)
                        Text(
                            "${file.mimeType ?: "tipo desconocido"} · ${file.sizeBytes / 1024} KB",
                            style = MaterialTheme.typography.bodySmall,
                            color = JarvisTextSecondary
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = {
                                statusMessage = when (val r = toolExecutor.execute(ToolId.FILE_READ, mapOf("query" to file.displayName))) {
                                    is ToolResult.Success -> r.message
                                    is ToolResult.Failure -> r.reason
                                    else -> "No disponible."
                                }
                            }) { Text("Leer") }

                            TextButton(onClick = {
                                statusMessage = when (val r = toolExecutor.execute(ToolId.FILE_COPY, mapOf("query" to file.displayName))) {
                                    is ToolResult.Success -> r.message
                                    is ToolResult.Failure -> r.reason
                                    else -> "No disponible."
                                }
                            }) { Text("Copiar") }

                            TextButton(onClick = {
                                toolExecutor.execute(ToolId.FILE_SHARE, mapOf("query" to file.displayName))
                            }) { Text("Compartir") }

                            TextButton(onClick = {
                                statusMessage = when (val r = toolExecutor.execute(ToolId.FILE_TRANSFER, mapOf("query" to file.displayName))) {
                                    is ToolResult.Success -> r.message
                                    is ToolResult.Failure -> r.reason
                                    else -> "No disponible."
                                }
                            }) { Text("Enviar") }
                        }
                    }
                }
            }
        }
    }
}
