package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * VOICE ENGINE
 *
 * Encapsula reconocimiento de voz (STT) y síntesis (TTS).
 *
 * NOTA IMPORTANTE SOBRE LA VOZ:
 * Android no permite "crear" una voz sintética original desde cero sin un motor
 * de terceros (ej. un modelo neuronal de voz). Este motor usa TextToSpeech nativo
 * de Android, configurado para acercarse a la identidad descrita (grave, calmada,
 * profesional): pitch bajo + velocidad moderada + intento de seleccionar una voz
 * masculina disponible en el dispositivo.
 *
 * Si más adelante se integra un motor de voz de terceros (ej. un modelo TTS
 * neuronal), solo hay que reemplazar la implementación de [speak] sin tocar
 * el resto de la app, gracias a esta interfaz.
 */
interface VoiceIdentity {
    var pitch: Float          // 0.1 - 2.0, por defecto grave (~0.75)
    var speechRate: Float     // 0.1 - 2.0
    var volume: Float         // 0.0 - 1.0
    var language: Locale
}

class JarvisVoiceEngine(private val context: Context) : VoiceIdentity {

    override var pitch: Float = 0.78f
    override var speechRate: Float = 0.95f
    override var volume: Float = 1.0f
    override var language: Locale = Locale("es", "ES")

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRecognizer: SpeechRecognizer? = null

    fun init(onReady: () -> Unit = {}) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = language
                tts?.setPitch(pitch)
                tts?.setSpeechRate(speechRate)
                selectDeepestMaleVoiceAvailable()
                ttsReady = true
                onReady()
            }
        }
    }

    private fun selectDeepestMaleVoiceAvailable() {
        val voices = tts?.voices ?: return
        val candidate = voices.firstOrNull {
            it.locale.language == language.language && !it.isNetworkConnectionRequired
        }
        candidate?.let { tts?.voice = it }
    }

    /** Habla con la identidad vocal configurada. Esta es la respuesta PRINCIPAL de J.A.R.V.I.S. */
    fun speak(text: String) {
        if (!ttsReady) return
        tts?.setPitch(pitch)
        tts?.setSpeechRate(speechRate)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utterance")
    }

    /** Sección 7: al activar el Modo Serio, la voz debe sonar más firme y profesional. */
    fun applySeriousTone() {
        pitch = 0.68f
        speechRate = 0.88f
    }

    fun applyNormalTone() {
        pitch = 0.78f
        speechRate = 0.95f
    }

    fun startListening(
        onPartial: (String) -> Unit = {},
        onResult: (String) -> Unit,
        onError: (String) -> Unit = {}
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("SPEECH_RECOGNITION_NOT_AVAILABLE")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: android.os.Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    onResult(text)
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {
                    val text = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) onPartial(text)
                }
                override fun onError(error: Int) = onError("STT_ERROR_$error")
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language.toString())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        speechRecognizer?.destroy()
    }
}
