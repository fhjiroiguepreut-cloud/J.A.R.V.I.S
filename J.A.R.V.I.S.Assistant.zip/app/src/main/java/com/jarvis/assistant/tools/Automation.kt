package com.jarvis.assistant.tools

/**
 * AUTOMATION — Fase 8
 *
 * "Cuando ocurra X, realiza Y." X es un [AutomationTrigger] disparado por
 * algún evento real ya implementado en fases anteriores (conexión de
 * dispositivo, archivo recibido, mensaje recibido, Modo Serio activado,
 * inicio de la app). Y es una acción de [ToolRegistry], igual que en los
 * comandos personalizados de la Fase 2 — reutilizando el mismo
 * [ToolExecutor] y respetando permisos, seguridad y confirmaciones
 * (sección 22: "las automatizaciones deben respetar permisos, restricciones
 * de Android, seguridad y confirmaciones").
 */
enum class AutomationTrigger(val label: String) {
    APP_STARTED("Al iniciar J.A.R.V.I.S."),
    DEVICE_CONNECTED("Al conectarse un dispositivo"),
    DEVICE_DISCONNECTED("Al desconectarse un dispositivo"),
    FILE_RECEIVED("Al recibir un archivo"),
    MESSAGE_RECEIVED("Al recibir un mensaje del dispositivo"),
    SERIOUS_MODE_ACTIVATED("Al activarse el Modo Serio")
}

data class Automation(
    val id: String,
    val trigger: AutomationTrigger,
    val actionToolId: String,       // nombre de un ToolId real del ToolRegistry
    val actionParams: Map<String, String> = emptyMap(),
    val requiresConfirmation: Boolean = false,
    val securityLevel: SecurityLevel = SecurityLevel.NORMAL,
    val status: CommandStatus = CommandStatus.ENABLED
)
