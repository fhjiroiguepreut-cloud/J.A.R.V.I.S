package com.jarvis.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val JarvisBackground = Color(0xFF05070A)
val JarvisCyan = Color(0xFF4FD8E8)
val JarvisCyanDim = Color(0xFF1E5C66)
val JarvisAmber = Color(0xFFE0A458)
val JarvisRed = Color(0xFFE05C5C)
val JarvisTextSecondary = Color(0xFF7C8B92)

private val JarvisColorScheme = darkColorScheme(
    primary = JarvisCyan,
    secondary = JarvisAmber,
    background = JarvisBackground,
    surface = JarvisBackground,
    error = JarvisRed
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        content = content
    )
}
