package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.devices.AuthorizedDevice
import com.jarvis.assistant.devices.DeviceConnectionStatus
import com.jarvis.assistant.ui.theme.JarvisTextSecondary

@Composable
fun DevicesScreen(
    connectionKey: String?,
    devicesPermissionGranted: Boolean,
    onRequestDevicesPermission: () -> Unit,
    devices: List<AuthorizedDevice>,
    onGenerateKey: () -> Unit,
    onSetKeyManually: (String) -> Unit,
    onRevokeKey: () -> Unit,
    onStartPairing: () -> Unit,
    onDisconnect: (AuthorizedDevice) -> Unit,
    onBack: () -> Unit
) {
    var manualKeyInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Volver") }
            Text("DEVICES", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.width(64.dp))
        }

        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("CONNECTION KEY", style = MaterialTheme.typography.titleSmall)
                Text(
                    connectionKey ?: "Sin configurar",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "Genere una clave en este dispositivo y copie el mismo valor en el otro, " +
                        "o introdúzcala aquí si ya la generó allí.",
                    style = MaterialTheme.typography.bodySmall,
                    color = JarvisTextSecondary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onGenerateKey) { Text("Generar nueva") }
                    OutlinedButton(onClick = onRevokeKey) { Text("Revocar") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = manualKeyInput,
                        onValueChange = { manualKeyInput = it },
                        label = { Text("Introducir clave del otro dispositivo") },
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        enabled = manualKeyInput.isNotBlank(),
                        onClick = { onSetKeyManually(manualKeyInput); manualKeyInput = "" }
                    ) { Text("Usar") }
                }
            }
        }

        if (!devicesPermissionGranted) {
            Text(
                "Se necesitan permisos de Bluetooth/red cercana para buscar otros dispositivos J.A.R.V.I.S.",
                color = JarvisTextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
            Button(onClick = onRequestDevicesPermission) { Text("Conceder permisos") }
        } else {
            Button(onClick = onStartPairing, enabled = connectionKey != null) {
                Text("Buscar y conectar dispositivo")
            }
        }

        Text("DISPOSITIVOS", style = MaterialTheme.typography.titleSmall)
        if (devices.isEmpty()) {
            Text("Ningún dispositivo detectado todavía.", color = JarvisTextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(devices) { device ->
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(device.displayName, style = MaterialTheme.typography.bodyMedium)
                            Text(device.status.name, style = MaterialTheme.typography.labelSmall, color = JarvisTextSecondary)
                        }
                        if (device.status == DeviceConnectionStatus.CONNECTED || device.status == DeviceConnectionStatus.PAIRING) {
                            TextButton(onClick = { onDisconnect(device) }) { Text("Desconectar") }
                        }
                    }
                }
            }
        }
    }
}
