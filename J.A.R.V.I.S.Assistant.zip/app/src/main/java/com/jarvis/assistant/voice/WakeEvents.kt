package com.jarvis.assistant.voice

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

enum class WakeKind { NORMAL, SERIOUS }
data class WakeEvent(val kind: WakeKind)

/**
 * Puente en memoria entre JarvisListeningService (que corre en segundo plano
 * detectando la palabra de activación) y la UI (MainActivity), sin necesidad
 * de bind/unbind de servicio ni broadcasts explícitos.
 */
object WakeEvents {
    private val _events = MutableSharedFlow<WakeEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<WakeEvent> = _events.asSharedFlow()

    fun emit(kind: WakeKind) {
        _events.tryEmit(WakeEvent(kind))
    }
}
