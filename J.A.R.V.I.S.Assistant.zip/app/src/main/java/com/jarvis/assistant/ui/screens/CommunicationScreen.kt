package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.theme.JarvisTextSecondary

data class DeviceMessage(val fromMe: Boolean, val text: String)

@Composable
fun CommunicationScreen(
    deviceConnected: Boolean,
    deviceMessages: List<DeviceMessage>,
    onSendDeviceMessage: (String) -> Unit,
    smsPermissionGranted: Boolean,
    onRequestSmsPermission: () -> Unit,
    onSendSms: (String, String) -> Unit,
    callPermissionGranted: Boolean,
    onRequestCallPermission: () -> Unit,
    onCall: (String) -> Unit,
    onBack: () -> Unit
) {
    var deviceMessageInput by remember { mutableStateOf("") }
    var smsNumber by remember { mutableStateOf("") }
    var smsMessage by remember { mutableStateOf("") }
    var callNumber by remember { mutableStateOf("") }
    var showCallConfirm by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Volver") }
            Text("COMMUNICATION", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.width(64.dp))
        }

        // --- Mensajería dispositivo ↔ dispositivo ---
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("MENSAJE AL DISPOSITIVO CONECTADO", style = MaterialTheme.typography.titleSmall)
                if (!deviceConnected) {
                    Text("Ningún dispositivo conectado todavía.", color = JarvisTextSecondary, style = MaterialTheme.typography.bodySmall)
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 160.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(deviceMessages) { msg ->
                            Text(
                                (if (msg.fromMe) "Yo: " else "Dispositivo: ") + msg.text,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (msg.fromMe) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = deviceMessageInput,
                            onValueChange = { deviceMessageInput = it },
                            label = { Text("Mensaje") },
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            enabled = deviceMessageInput.isNotBlank(),
                            onClick = { onSendDeviceMessage(deviceMessageInput); deviceMessageInput = "" }
                        ) { Text("Enviar") }
                    }
                }
            }
        }

        // --- SMS ---
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("MESSAGING (SMS)", style = MaterialTheme.typography.titleSmall)
                if (!smsPermissionGranted) {
                    Text("Se necesita permiso para enviar SMS.", color = JarvisTextSecondary, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = onRequestSmsPermission) { Text("Conceder permiso") }
                } else {
                    OutlinedTextField(value = smsNumber, onValueChange = { smsNumber = it }, label = { Text("Número") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = smsMessage, onValueChange = { smsMessage = it }, label = { Text("Mensaje") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        enabled = smsNumber.isNotBlank() && smsMessage.isNotBlank(),
                        onClick = { onSendSms(smsNumber, smsMessage); smsMessage = "" }
                    ) { Text("Enviar SMS") }
                }
            }
        }

        // --- Llamadas ---
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CALLS", style = MaterialTheme.typography.titleSmall)
                if (!callPermissionGranted) {
                    Text("Se necesita permiso para realizar llamadas.", color = JarvisTextSecondary, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = onRequestCallPermission) { Text("Conceder permiso") }
                } else {
                    OutlinedTextField(value = callNumber, onValueChange = { callNumber = it }, label = { Text("Número") }, modifier = Modifier.fillMaxWidth())
                    Button(enabled = callNumber.isNotBlank(), onClick = { showCallConfirm = true }) { Text("Llamar") }
                    Text(
                        "J.A.R.V.I.S. nunca llama automáticamente: siempre pedirá confirmación antes.",
                        style = MaterialTheme.typography.labelSmall,
                        color = JarvisTextSecondary
                    )
                }
            }
        }
    }

    if (showCallConfirm) {
        AlertDialog(
            onDismissRequest = { showCallConfirm = false },
            title = { Text("Confirmar llamada") },
            text = { Text("¿Confirma que desea llamar a \"$callNumber\", señor?") },
            confirmButton = {
                TextButton(onClick = { showCallConfirm = false; onCall(callNumber) }) { Text("Llamar") }
            },
            dismissButton = {
                TextButton(onClick = { showCallConfirm = false }) { Text("Cancelar") }
            }
        )
    }
}
