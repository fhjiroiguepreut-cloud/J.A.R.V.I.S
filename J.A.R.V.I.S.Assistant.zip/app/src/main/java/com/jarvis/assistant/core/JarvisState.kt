package com.jarvis.assistant.core

/**
 * Estados visuales y funcionales de J.A.R.V.I.S., tal como se definieron
 * en la especificación: el núcleo reacciona visualmente a cada uno.
 */
enum class JarvisState(val label: String) {
    STANDING_BY("STANDING BY"),
    LISTENING("LISTENING..."),
    THINKING("THINKING..."),
    EXECUTING("EXECUTING..."),
    VERIFYING("VERIFYING..."),
    COMPLETE("COMPLETE"),
    OFFLINE("OFFLINE"),
    PERMISSION_REQUIRED("PERMISSION REQUIRED"),
    ACTION_BLOCKED("ACTION BLOCKED"),
    ERROR("ERROR")
}
