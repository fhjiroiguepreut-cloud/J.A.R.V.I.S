package com.jarvis.assistant.ai

import com.jarvis.assistant.core.JarvisState
import com.jarvis.assistant.tools.CustomCommand
import com.jarvis.assistant.tools.SecurityLevel
import com.jarvis.assistant.tools.ToolId
import com.jarvis.assistant.tools.ToolResult

/**
 * LOCAL AI BRAIN — Fase 1-2
 *
 * En esta fase, el "cerebro" es un enrutador de intenciones basado en reglas y
 * comandos personalizados (100% local, sin red). Es intencionalmente simple:
 * la arquitectura está pensada para que en una fase posterior se pueda
 * reemplazar `resolveIntent` por una llamada a un modelo local real
 * (por ejemplo, un modelo GGUF vía llama.cpp o un modelo de MediaPipe/LiteRT
 * corriendo on-device), sin cambiar el resto de la app.
 *
 * NO se simulan acciones: si una intención no tiene una herramienta
 * implementada, se devuelve NotImplemented explícitamente.
 */

sealed class JarvisIntent {
    data class MatchedCommand(val command: CustomCommand) : JarvisIntent()
    data class ActivateAssistant(val raw: String) : JarvisIntent()
    data class Unknown(val raw: String) : JarvisIntent()
}

sealed class JarvisResponse {
    data class Speak(val text: String, val newState: JarvisState = JarvisState.COMPLETE) : JarvisResponse()
    data class NeedsConfirmation(val command: CustomCommand) : JarvisResponse()
    data class NotImplemented(val feature: String) : JarvisResponse()
}

class AiBrain(
    private val findCommand: (String) -> CustomCommand?,
    private val executeToolAction: (ToolId, Map<String, String>) -> ToolResult
) {

    /** Determina la intención a partir del texto reconocido por voz. */
    fun resolveIntent(rawText: String): JarvisIntent {
        val normalized = rawText.trim().lowercase()
        if (normalized.isBlank()) return JarvisIntent.Unknown(rawText)

        findCommand(normalized)?.let { command ->
            return JarvisIntent.MatchedCommand(command)
        }

        return JarvisIntent.Unknown(rawText)
    }

    /** Genera la respuesta para una intención ya resuelta. */
    fun respond(intent: JarvisIntent): JarvisResponse {
        return when (intent) {
            is JarvisIntent.ActivateAssistant ->
                JarvisResponse.Speak("Hola señor, ¿cómo puedo ayudarle hoy?", JarvisState.LISTENING)

            is JarvisIntent.MatchedCommand -> {
                val command = intent.command
                if (command.requiresConfirmation || command.securityLevel == SecurityLevel.SENSITIVE) {
                    JarvisResponse.NeedsConfirmation(command)
                } else {
                    runCommand(command)
                }
            }

            is JarvisIntent.Unknown ->
                JarvisResponse.NotImplemented(intent.raw)
        }
    }

    /** Ejecuta de verdad la acción de un comando ya confirmado (o que no requería confirmación). */
    fun runCommand(command: CustomCommand): JarvisResponse {
        val toolId = ToolId.entries.firstOrNull { it.name == command.actionId }
            ?: return JarvisResponse.NotImplemented(command.actionId)

        return when (val result = executeToolAction(toolId, emptyMap())) {
            is ToolResult.Success -> JarvisResponse.Speak(command.voiceResponse, JarvisState.COMPLETE)
            is ToolResult.Failure -> JarvisResponse.Speak("No he podido completarlo, señor: ${result.reason}", JarvisState.ERROR)
            is ToolResult.NotImplemented -> JarvisResponse.NotImplemented(command.actionId)
            is ToolResult.PermissionRequired -> JarvisResponse.Speak("Necesito el permiso: ${result.permission}", JarvisState.PERMISSION_REQUIRED)
        }
    }
}
