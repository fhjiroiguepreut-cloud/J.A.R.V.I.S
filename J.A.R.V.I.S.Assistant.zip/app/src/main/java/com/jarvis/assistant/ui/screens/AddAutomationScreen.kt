package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.tools.*

@Composable
fun AddAutomationScreen(
    onSave: (Automation) -> Unit,
    onCancel: () -> Unit
) {
    var trigger by remember { mutableStateOf(AutomationTrigger.APP_STARTED) }
    var actionToolId by remember { mutableStateOf(ToolRegistry.all.first().id.name) }
    var requiresConfirmation by remember { mutableStateOf(false) }
    var securityLevel by remember { mutableStateOf(SecurityLevel.NORMAL) }

    var triggerMenuExpanded by remember { mutableStateOf(false) }
    var actionMenuExpanded by remember { mutableStateOf(false) }
    var securityMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("ADD AUTOMATION", style = MaterialTheme.typography.titleMedium)
        Text("\"Cuando ocurra X, realiza Y.\"", style = MaterialTheme.typography.bodySmall)

        // TRIGGER (X)
        ExposedDropdownMenuBox(expanded = triggerMenuExpanded, onExpandedChange = { triggerMenuExpanded = !triggerMenuExpanded }) {
            OutlinedTextField(
                value = trigger.label,
                onValueChange = {},
                readOnly = true,
                label = { Text("CUANDO (X)") },
                modifier = Modifier.fillMaxWidth().menuAnchor()
            )
            ExposedDropdownMenu(expanded = triggerMenuExpanded, onDismissRequest = { triggerMenuExpanded = false }) {
                AutomationTrigger.entries.forEach { t ->
                    DropdownMenuItem(text = { Text(t.label) }, onClick = { trigger = t; triggerMenuExpanded = false })
                }
            }
        }

        // ACTION (Y)
        ExposedDropdownMenuBox(expanded = actionMenuExpanded, onExpandedChange = { actionMenuExpanded = !actionMenuExpanded }) {
            OutlinedTextField(
                value = actionToolId,
                onValueChange = {},
                readOnly = true,
                label = { Text("REALIZA (Y)") },
                modifier = Modifier.fillMaxWidth().menuAnchor()
            )
            ExposedDropdownMenu(expanded = actionMenuExpanded, onDismissRequest = { actionMenuExpanded = false }) {
                ToolRegistry.all.forEach { tool ->
                    DropdownMenuItem(
                        text = { Text("${tool.id.name} — ${tool.displayName}") },
                        onClick = { actionToolId = tool.id.name; actionMenuExpanded = false }
                    )
                }
            }
        }

        ExposedDropdownMenuBox(expanded = securityMenuExpanded, onExpandedChange = { securityMenuExpanded = !securityMenuExpanded }) {
            OutlinedTextField(
                value = securityLevel.name,
                onValueChange = {},
                readOnly = true,
                label = { Text("SECURITY LEVEL") },
                modifier = Modifier.fillMaxWidth().menuAnchor()
            )
            ExposedDropdownMenu(expanded = securityMenuExpanded, onDismissRequest = { securityMenuExpanded = false }) {
                SecurityLevel.entries.forEach { s ->
                    DropdownMenuItem(text = { Text(s.name) }, onClick = { securityLevel = s; securityMenuExpanded = false })
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = requiresConfirmation, onCheckedChange = { requiresConfirmation = it })
            Text("Pedir confirmación antes de ejecutar")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                onSave(
                    Automation(
                        id = System.currentTimeMillis().toString(),
                        trigger = trigger,
                        actionToolId = actionToolId,
                        requiresConfirmation = requiresConfirmation,
                        securityLevel = securityLevel
                    )
                )
            }) { Text("Guardar") }
            OutlinedButton(onClick = onCancel) { Text("Cancelar") }
        }
    }
}
