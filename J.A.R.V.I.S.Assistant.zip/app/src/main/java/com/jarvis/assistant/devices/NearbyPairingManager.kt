package com.jarvis.assistant.devices

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import java.io.File

/**
 * DEVICE PAIRING + FILE TRANSFER — Fase 4-5
 *
 * Usa Nearby Connections (Google Play Services) con estrategia
 * P2P_POINT_TO_POINT. Nearby cifra automáticamente el canal una vez
 * establecida la conexión (sección 17: "la comunicación debe estar cifrada").
 *
 * VERIFICACIÓN DE LA CONNECTION KEY:
 * Cada dispositivo anuncia su nombre junto al HASH de su Connection Key
 * (separados por "|"). Al recibir una solicitud de conexión, se compara ese
 * hash contra el propio: solo se acepta si coinciden.
 *
 * TRANSFERENCIA DE ARCHIVOS (Fase 5):
 * Nearby no conserva el nombre original de un Payload de tipo FILE, así que
 * antes de enviar el archivo se manda un pequeño Payload de tipo BYTES con
 * "payloadId:nombreOriginal". El receptor lo guarda en un mapa y, cuando
 * llega el FILE payload correspondiente y termina con éxito, usa ese nombre
 * al copiar el archivo a Download/JARVIS mediante MediaStore.
 */
private const val SERVICE_ID = "com.jarvis.assistant.SERVICE_ID"
private const val TAG = "JarvisPairing"

class NearbyPairingManager(
    private val context: Context,
    private val localConnectionKeyHash: () -> String?,
    private val onDeviceUpdated: (AuthorizedDevice) -> Unit,
    private val onLog: (String) -> Unit,
    private val onFileReceived: (String, Uri?) -> Unit = { _, _ -> },
    private val onMessageReceived: (String, String) -> Unit = { _, _ -> }
) {
    private val client by lazy { Nearby.getConnectionsClient(context) }
    private val localDeviceName = android.os.Build.MODEL ?: "JARVIS Device"

    // payloadId del archivo -> nombre original (recibido antes por el payload de metadatos)
    private val incomingFileNames = mutableMapOf<Long, String>()
    // payloadId entrante -> Payload de tipo FILE, hasta que la transferencia termine
    private val incomingFilePayloads = mutableMapOf<Long, Payload>()
    // payloadId enviado -> nombre original (para el ACTIVITY LOG al confirmar éxito)
    private val outgoingFileNames = mutableMapOf<Long, String>()

    private fun encodedEndpointName(): String {
        val hash = localConnectionKeyHash() ?: "NOKEY"
        return "$localDeviceName|$hash"
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            val parts = info.endpointName.split("|")
            val remoteHash = parts.getOrNull(1)
            val myHash = localConnectionKeyHash()

            if (myHash != null && remoteHash == myHash) {
                onLog("Connection Key verificada con ${parts.getOrElse(0) { endpointId }}.")
                client.acceptConnection(endpointId, payloadCallback)
                onDeviceUpdated(AuthorizedDevice(endpointId, parts.getOrElse(0) { endpointId }, DeviceConnectionStatus.PAIRING))
            } else {
                onLog("Conexión rechazada: Connection Key no coincide.")
                client.rejectConnection(endpointId)
            }
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            val status = if (result.status.isSuccess) DeviceConnectionStatus.CONNECTED else DeviceConnectionStatus.ERROR
            onDeviceUpdated(AuthorizedDevice(endpointId, endpointId, status))
            onLog("Conexión con $endpointId: ${status.name}")
        }

        override fun onDisconnected(endpointId: String) {
            onDeviceUpdated(AuthorizedDevice(endpointId, endpointId, DeviceConnectionStatus.DISCONNECTED))
            onLog("$endpointId desconectado.")
        }
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            client.requestConnection(encodedEndpointName(), endpointId, connectionLifecycleCallback)
                .addOnFailureListener { Log.w(TAG, "requestConnection falló", it) }
        }

        override fun onEndpointLost(endpointId: String) {
            onLog("Dispositivo $endpointId fuera de rango.")
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> {
                    val text = payload.asBytes()?.toString(Charsets.UTF_8).orEmpty()
                    when {
                        text.startsWith("FILENAME:") -> {
                            // Formato: "FILENAME:<payloadId>:<nombre>"
                            val parts = text.split(":", limit = 3)
                            val filePayloadId = parts.getOrNull(1)?.toLongOrNull()
                            if (parts.size == 3 && filePayloadId != null) {
                                incomingFileNames[filePayloadId] = parts[2]
                            }
                        }
                        text.startsWith("MSG:") -> {
                            onMessageReceived(endpointId, text.removePrefix("MSG:"))
                        }
                    }
                }
                Payload.Type.FILE -> {
                    incomingFilePayloads[payload.id] = payload
                    onLog("Recibiendo archivo de $endpointId...")
                }
                else -> {}
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            if (update.status == PayloadTransferUpdate.Status.SUCCESS) {
                outgoingFileNames.remove(update.payloadId)?.let { name ->
                    onLog("Transferencia completada: $name enviado a $endpointId.")
                }
                incomingFilePayloads.remove(update.payloadId)?.let { payload ->
                    finalizeReceivedFile(payload)
                }
            } else if (update.status == PayloadTransferUpdate.Status.FAILURE) {
                onLog("Transferencia fallida con $endpointId.")
            }
        }
    }

    /** DEVICE_CONNECT — publica este dispositivo y busca otros simultáneamente. */
    fun startPairing() {
        if (localConnectionKeyHash() == null) {
            onLog("No hay ninguna Connection Key configurada. Genere o introduzca una primero.")
            return
        }

        val advertisingOptions = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_POINT_TO_POINT).build()
        client.startAdvertising(
            encodedEndpointName(), SERVICE_ID, connectionLifecycleCallback, advertisingOptions
        ).addOnFailureListener { Log.w(TAG, "startAdvertising falló", it) }

        val discoveryOptions = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_POINT_TO_POINT).build()
        client.startDiscovery(
            SERVICE_ID, endpointDiscoveryCallback, discoveryOptions
        ).addOnFailureListener { Log.w(TAG, "startDiscovery falló", it) }

        onLog("Buscando dispositivos J.A.R.V.I.S. autorizados...")
    }

    /** FILE_TRANSFER — envía un archivo ya localizado a un dispositivo ya conectado. */
    fun sendFile(endpointId: String, uri: Uri, displayName: String): Boolean {
        return try {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return false
            val filePayload = Payload.fromFile(pfd)
            outgoingFileNames[filePayload.id] = displayName

            // Metadatos del nombre, enviados justo antes que el archivo.
            val metadata = "FILENAME:${filePayload.id}:$displayName".toByteArray(Charsets.UTF_8)
            client.sendPayload(endpointId, Payload.fromBytes(metadata))
            client.sendPayload(endpointId, filePayload)
            onLog("Transferencia iniciada: $displayName → $endpointId.")
            true
        } catch (e: Exception) {
            Log.w(TAG, "sendFile falló", e)
            false
        }
    }

    /** Se invoca automáticamente cuando un Payload de tipo FILE entrante termina con éxito. */
    private fun finalizeReceivedFile(payload: Payload) {
        val javaFile: File = payload.asFile()?.asJavaFile() ?: return
        val originalName = incomingFileNames.remove(payload.id) ?: javaFile.name
        val savedUri = saveToDownloads(javaFile, originalName)
        onFileReceived(originalName, savedUri)
        onLog(if (savedUri != null) "Archivo recibido y guardado: $originalName." else "No se pudo guardar el archivo recibido.")
    }

    private fun saveToDownloads(source: File, displayName: String): Uri? {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/JARVIS")
            }
            val destUri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            source.inputStream().use { input ->
                context.contentResolver.openOutputStream(destUri)?.use { output -> input.copyTo(output) }
            }
            destUri
        } catch (e: Exception) {
            Log.w(TAG, "saveToDownloads falló", e)
            null
        }
    }

    /** MESSAGING (dispositivo↔dispositivo) — sección 18: "Envía un mensaje al dispositivo conectado...". */
    fun sendMessage(endpointId: String, text: String): Boolean {
        return try {
            client.sendPayload(endpointId, Payload.fromBytes("MSG:$text".toByteArray(Charsets.UTF_8)))
            onLog("Mensaje enviado a $endpointId: \"$text\".")
            true
        } catch (e: Exception) {
            Log.w(TAG, "sendMessage falló", e)
            false
        }
    }

    /** DEVICE_DISCONNECT */
    fun disconnect(endpointId: String) {
        client.disconnectFromEndpoint(endpointId)
        onDeviceUpdated(AuthorizedDevice(endpointId, endpointId, DeviceConnectionStatus.DISCONNECTED))
    }

    fun stopAll() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
    }
}

