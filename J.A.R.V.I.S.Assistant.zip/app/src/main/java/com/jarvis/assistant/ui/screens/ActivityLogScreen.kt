package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.tools.ActivityLogEntry
import com.jarvis.assistant.ui.theme.JarvisTextSecondary

@Composable
fun ActivityLogScreen(entries: List<ActivityLogEntry>, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Volver") }
            Text("ACTIVITY LOG", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.width(64.dp))
        }
        Spacer(Modifier.height(12.dp))

        if (entries.isEmpty()) {
            Text("Todavía no hay actividad registrada.", color = JarvisTextSecondary)
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries) { entry ->
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(entry.time, style = MaterialTheme.typography.labelSmall, color = JarvisTextSecondary)
                            Text(entry.result, style = MaterialTheme.typography.labelSmall)
                        }
                        Text(entry.toolName, style = MaterialTheme.typography.bodyMedium)
                        if (entry.detail.isNotBlank()) {
                            Text(entry.detail, style = MaterialTheme.typography.bodySmall, color = JarvisTextSecondary)
                        }
                        Text(entry.device, style = MaterialTheme.typography.labelSmall, color = JarvisTextSecondary)
                    }
                }
            }
        }
    }
}
