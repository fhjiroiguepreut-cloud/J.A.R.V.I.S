package com.jarvis.assistant.tools

import android.content.Intent
import com.jarvis.assistant.communication.CommsRepository
import com.jarvis.assistant.devices.NearbyPairingManager
import com.jarvis.assistant.files.FilesRepository
import com.jarvis.assistant.files.JarvisFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ACTIVITY LOG — registro de cada ejecución de herramienta:
 * hora, acción, resultado, dispositivo, herramienta utilizada.
 */
data class ActivityLogEntry(
    val time: String,
    val toolName: String,
    val detail: String,
    val result: String,
    val device: String = "DEVICE 01"
)

class ActivityLog {
    private val _entries = mutableListOf<ActivityLogEntry>()
    val entries: List<ActivityLogEntry> get() = _entries.toList()

    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun record(toolName: String, detail: String, result: String) {
        _entries.add(0, ActivityLogEntry(timeFormat.format(Date()), toolName, detail, result))
    }
}

/**
 * TOOL EXECUTOR
 *
 * Ejecuta herramientas del [ToolRegistry]. Solo SYSTEM_INFO, VOICE_OUTPUT y
 * LOCAL_MEMORY tienen lógica real en esta fase (son las únicas que no
 * dependen de permisos avanzados ni de fases futuras: archivos reales,
 * emparejamiento de dispositivos, SMS, llamadas). El resto devuelve
 * explícitamente NotImplemented — nunca se simula un resultado falso.
 */
class ToolExecutor(
    private val activityLog: ActivityLog,
    private val speak: (String) -> Unit,
    private val readMemory: (String) -> String?,
    private val writeMemory: (String, String) -> Unit,
    private val systemInfoProvider: () -> String,
    private val filesRepository: FilesRepository? = null,
    private val launchIntent: (Intent) -> Unit = {},
    private val pairingManager: NearbyPairingManager? = null,
    private val connectedDeviceProvider: () -> String? = { null },
    private val commsRepository: CommsRepository? = null
) {
    // Última búsqueda de archivos, para poder resolver "el segundo" o
    // reintentar READ/COPY/SHARE sobre el mismo resultado sin buscar de nuevo.
    private var lastSearchResults: List<JarvisFile> = emptyList()

    fun execute(toolId: ToolId, params: Map<String, String>): ToolResult {
        val tool = ToolRegistry.byId(toolId)

        val result: ToolResult = when (toolId) {
            ToolId.VOICE_OUTPUT -> {
                val text = params["text"].orEmpty()
                speak(text)
                ToolResult.Success("Texto reproducido por voz.")
            }
            ToolId.SYSTEM_INFO -> {
                ToolResult.Success(systemInfoProvider())
            }
            ToolId.LOCAL_MEMORY -> {
                val key = params["key"]
                val value = params["value"]
                if (key == null) {
                    ToolResult.Failure("Falta el parámetro 'key'.")
                } else if (value != null) {
                    writeMemory(key, value)
                    ToolResult.Success("Memoria actualizada.")
                } else {
                    val stored = readMemory(key)
                    if (stored != null) ToolResult.Success(stored)
                    else ToolResult.Failure("No hay nada guardado bajo '$key'.")
                }
            }
            ToolId.FILE_SEARCH -> {
                val repo = filesRepository ?: return notImplemented(toolId)
                val query = params["query"].orEmpty()
                val matches = repo.search(query)
                lastSearchResults = matches
                when {
                    matches.isEmpty() -> ToolResult.Failure("No he encontrado ningún archivo que coincida con \"$query\".")
                    matches.size == 1 -> ToolResult.Success("Archivo encontrado: ${matches[0].displayName}.")
                    else -> ToolResult.Success(
                        "He encontrado varios archivos que coinciden: " +
                            matches.joinToString { it.displayName } + ". ¿Cuál desea?"
                    )
                }
            }
            ToolId.FILE_READ -> {
                val repo = filesRepository ?: return notImplemented(toolId)
                val target = resolveTarget(params, repo) ?: return ToolResult.Failure("No hay ningún archivo localizado todavía. Búsquelo primero.")
                val content = repo.readAsText(target)
                if (content != null) ToolResult.Success(content)
                else ToolResult.Failure("\"${target.displayName}\" no es un archivo de texto legible.")
            }
            ToolId.FILE_COPY -> {
                val repo = filesRepository ?: return notImplemented(toolId)
                val target = resolveTarget(params, repo) ?: return ToolResult.Failure("No hay ningún archivo localizado todavía. Búsquelo primero.")
                val destUri = repo.copyToJarvisFolder(target)
                if (destUri != null) ToolResult.Success("Copiado a Download/JARVIS/${target.displayName}.")
                else ToolResult.Failure("No he podido copiar \"${target.displayName}\".")
            }
            ToolId.FILE_SHARE -> {
                val repo = filesRepository ?: return notImplemented(toolId)
                val target = resolveTarget(params, repo) ?: return ToolResult.Failure("No hay ningún archivo localizado todavía. Búsquelo primero.")
                launchIntent(Intent.createChooser(repo.buildShareIntent(target), "Compartir ${target.displayName}"))
                ToolResult.Success("Abriendo opciones para compartir \"${target.displayName}\".")
            }
            ToolId.DEVICE_CONNECT -> {
                val manager = pairingManager ?: return notImplemented(toolId)
                manager.startPairing()
                ToolResult.Success("Buscando dispositivos J.A.R.V.I.S. autorizados.")
            }
            ToolId.DEVICE_DISCONNECT -> {
                val manager = pairingManager ?: return notImplemented(toolId)
                val endpointId = params["deviceId"]
                if (endpointId == null) ToolResult.Failure("Falta el parámetro 'deviceId'.")
                else {
                    manager.disconnect(endpointId)
                    ToolResult.Success("Dispositivo desconectado.")
                }
            }
            ToolId.FILE_TRANSFER -> {
                val repo = filesRepository ?: return notImplemented(toolId)
                val manager = pairingManager ?: return notImplemented(toolId)
                val target = resolveTarget(params, repo)
                    ?: return ToolResult.Failure("No hay ningún archivo localizado todavía. Búsquelo primero.")
                val endpointId = params["deviceId"] ?: connectedDeviceProvider()
                    ?: return ToolResult.Failure("No hay ningún dispositivo conectado. Empareje uno primero.")
                val started = manager.sendFile(endpointId, target.uri, target.displayName)
                if (started) ToolResult.Success("Archivo encontrado y transferencia iniciada.")
                else ToolResult.Failure("No he podido iniciar la transferencia de \"${target.displayName}\".")
            }
            ToolId.MESSAGING -> {
                val message = params["message"]
                    ?: return ToolResult.Failure("Falta el parámetro 'message'.")
                val target = params["target"].orEmpty()

                if (target.isBlank() || target.equals("device", ignoreCase = true) || target.equals("dispositivo", ignoreCase = true)) {
                    val manager = pairingManager ?: return notImplemented(toolId)
                    val endpointId = connectedDeviceProvider()
                        ?: return ToolResult.Failure("No hay ningún dispositivo conectado.")
                    if (manager.sendMessage(endpointId, message)) ToolResult.Success("Mensaje enviado al dispositivo conectado.")
                    else ToolResult.Failure("No he podido enviar el mensaje.")
                } else {
                    val comms = commsRepository ?: return notImplemented(toolId)
                    if (comms.sendSms(target, message)) ToolResult.Success("SMS enviado a $target.")
                    else ToolResult.Failure("No he podido enviar el SMS a $target.")
                }
            }
            ToolId.CALLS -> {
                val comms = commsRepository ?: return notImplemented(toolId)
                val contact = params["contact"]
                    ?: return ToolResult.Failure("Falta el parámetro 'contact'.")
                // Sección 19: nunca se llama automáticamente. Este resultado se
                // devuelve solo cuando la UI ya obtuvo confirmación explícita
                // del usuario (ver CommunicationScreen / flujo de confirmación
                // de comandos SENSITIVE en AiBrain).
                launchIntent(comms.buildCallIntent(contact))
                ToolResult.Success("Iniciando llamada a $contact.")
            }
            else -> notImplemented(toolId)
        }

        activityLog.record(
            toolName = tool.displayName,
            detail = params.entries.joinToString { "${it.key}=${it.value}" },
            result = when (result) {
                is ToolResult.Success -> "COMPLETE"
                is ToolResult.Failure -> "FAILED: ${result.reason}"
                is ToolResult.NotImplemented -> "NOT_IMPLEMENTED"
                is ToolResult.PermissionRequired -> "PERMISSION_REQUIRED"
            }
        )

        return result
    }

    /** Resuelve sobre qué archivo actuar: por índice de la última búsqueda, por query nueva, o el único resultado previo. */
    private fun resolveTarget(params: Map<String, String>, repo: FilesRepository): JarvisFile? {
        params["query"]?.let { query ->
            val matches = repo.search(query)
            lastSearchResults = matches
            if (matches.size == 1) return matches[0]
        }
        params["index"]?.toIntOrNull()?.let { index ->
            lastSearchResults.getOrNull(index - 1)?.let { return it }
        }
        if (lastSearchResults.size == 1) return lastSearchResults[0]
        return null
    }

    private fun notImplemented(toolId: ToolId): ToolResult = ToolResult.NotImplemented(toolId)
}
