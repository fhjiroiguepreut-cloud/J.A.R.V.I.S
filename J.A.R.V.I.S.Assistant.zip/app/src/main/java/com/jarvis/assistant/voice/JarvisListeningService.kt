package com.jarvis.assistant.voice

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.devices.ConnectionKeyManager
import com.jarvis.assistant.memory.MemoryManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * ACTIVACIÓN POR VOZ EN SEGUNDO PLANO — Fase 7
 *
 * IMPORTANTE (honestidad sobre el enfoque): Android no ofrece un motor de
 * "wake word" nativo de bajo consumo. Este servicio reinicia continuamente
 * `SpeechRecognizer` en primer plano y compara cada resultado contra la
 * palabra de activación y la frase del Modo Serio guardadas en memoria.
 * Funciona, pero consume más batería que un motor dedicado (ej. Porcupine).
 * Si el consumo es un problema en el futuro, sustituir este servicio por uno
 * basado en un SDK de wake-word es la mejora natural, y no requiere tocar
 * el resto de la app (ver WakeEvents como punto de integración).
 */
class JarvisListeningService : Service() {

    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var memoryManager: MemoryManager
    private lateinit var secureKeys: ConnectionKeyManager
    private val scope = CoroutineScope(Dispatchers.Main)
    private var listening = false

    override fun onCreate() {
        super.onCreate()
        memoryManager = MemoryManager(applicationContext)
        secureKeys = ConnectionKeyManager(applicationContext)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }
        listening = true
        listenOnce()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    private fun listenOnce() {
        if (!listening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf()
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: android.os.Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                        .trim().lowercase()

                    scope.launch {
                        val activationPhrase = memoryManager.activationPhrase.first().lowercase()
                        val seriousPhrase = secureKeys.currentSeriousModePhrase()?.lowercase()

                        when {
                            seriousPhrase != null && text.contains(seriousPhrase) ->
                                WakeEvents.emit(WakeKind.SERIOUS)
                            activationPhrase.isNotBlank() && text.contains(activationPhrase) ->
                                WakeEvents.emit(WakeKind.NORMAL)
                        }
                        listenOnce() // vuelve a escuchar inmediatamente
                    }
                }
                override fun onError(error: Int) {
                    // Reintenta tras un error (silencio, timeout, etc.) — es esperable
                    // en un bucle de escucha continua. Se añade una pequeña pausa para
                    // no reiniciar el reconocedor en un bucle agresivo (Fase 9: optimización).
                    scope.launch {
                        kotlinx.coroutines.delay(400)
                        listenOnce()
                    }
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
        }
        speechRecognizer?.startListening(intent)
    }

    private fun buildNotification(): Notification {
        val channelId = "jarvis_listening_channel"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "J.A.R.V.I.S. escuchando", NotificationManager.IMPORTANCE_LOW)
            manager.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("J.A.R.V.I.S.")
            .setContentText("Escuchando la palabra de activación...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        listening = false
        speechRecognizer?.destroy()
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 4201

        fun start(context: android.content.Context) {
            val intent = Intent(context, JarvisListeningService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: android.content.Context) {
            context.stopService(Intent(context, JarvisListeningService::class.java))
        }
    }
}
