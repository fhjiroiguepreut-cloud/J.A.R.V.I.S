package com.jarvis.assistant.devices

import android.content.Context
import com.jarvis.assistant.security.SecureStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.MessageDigest
import kotlin.random.Random

/**
 * CONNECTION KEY (sección 15) + FRASE DEL MODO SERIO (sección 7).
 *
 * Desde la Fase 9, ambos secretos se guardan en [SecureStore]
 * (EncryptedSharedPreferences, cifradas con el Android Keystore) en vez de
 * en DataStore en texto plano — cumple literalmente "guardarse de forma
 * segura" (sección 15) y "la frase secreta debe almacenarse de forma
 * segura" (sección 7). SharedPreferences es de lectura/escritura síncrona,
 * así que estas operaciones ya no son `suspend`.
 *
 * - La Connection Key puede regenerarse (invalida la anterior) o revocarse.
 * - La frase del Modo Serio la define el usuario libremente; nunca está
 *   fija en el código.
 */
class ConnectionKeyManager(context: Context) {

    private val secureStore = SecureStore(context)
    private val connectionKeyName = "connection_key"
    private val seriousModePhraseName = "serious_mode_phrase"

    private val _connectionKey = MutableStateFlow(secureStore.get(connectionKeyName))
    val connectionKey: StateFlow<String?> = _connectionKey

    private val _seriousModePhrase = MutableStateFlow(secureStore.get(seriousModePhraseName))
    val seriousModePhrase: StateFlow<String?> = _seriousModePhrase

    fun generateNewKey(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // sin caracteres ambiguos
        val key = (1..8).map { alphabet[Random.nextInt(alphabet.length)] }.joinToString("")
        secureStore.set(connectionKeyName, key)
        _connectionKey.value = key
        return key
    }

    fun setKeyManually(key: String) {
        val normalized = key.trim().uppercase()
        secureStore.set(connectionKeyName, normalized)
        _connectionKey.value = normalized
    }

    fun revoke() {
        secureStore.remove(connectionKeyName)
        _connectionKey.value = null
    }

    fun setSeriousModePhrase(phrase: String) {
        secureStore.set(seriousModePhraseName, phrase)
        _seriousModePhrase.value = phrase
    }

    /** Lectura síncrona para el bucle de escucha en segundo plano (JarvisListeningService). */
    fun currentSeriousModePhrase(): String? = _seriousModePhrase.value

    fun hashOf(key: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(key.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }.take(16)
    }
}
