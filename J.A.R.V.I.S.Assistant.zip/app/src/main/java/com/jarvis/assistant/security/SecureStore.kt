package com.jarvis.assistant.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * SECURITY — Fase 9
 *
 * Envuelve EncryptedSharedPreferences (Jetpack Security) para guardar los
 * dos secretos reales de la app: la Connection Key (sección 15: "guardarse
 * de forma segura") y la frase del Modo Serio (sección 7: "debe
 * almacenarse de forma segura"). Antes vivían en DataStore normal
 * (texto plano en disco); a partir de esta fase se cifran con una clave
 * maestra gestionada por el Android Keystore del dispositivo.
 *
 * El resto de la memoria (preferencias no sensibles, comandos, automatizaciones)
 * sigue en DataStore normal: cifrar TODO no aporta nada si el propio proceso
 * de la app puede leerlo igualmente, y complicaría innecesariamente la
 * exportación/depuración de datos que no son secretos.
 */
class SecureStore(context: Context) {

    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            "jarvis_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun get(key: String): String? = prefs.getString(key, null)

    fun set(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    fun remove(key: String) {
        prefs.edit().remove(key).apply()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
