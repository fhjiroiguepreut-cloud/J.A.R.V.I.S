package com.jarvis.assistant.memory

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.jarvis.assistant.tools.CommandSerializer
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.jarvisDataStore by preferencesDataStore(name = "jarvis_memory")

/**
 * MEMORY — almacenamiento 100% local (no se envía a ningún servidor).
 *
 * Guarda: preferencias de voz, comandos personalizados (como JSON simple),
 * dispositivos autorizados y contexto reciente.
 *
 * VIEW MEMORY / EDIT MEMORY / CLEAR MEMORY se apoyan directamente en esta clase.
 */
class MemoryManager(private val context: Context) {

    private object Keys {
        val ACTIVATION_PHRASE = stringPreferencesKey("activation_phrase")
        val CUSTOM_COMMANDS_JSON = stringPreferencesKey("custom_commands_json")
        val AUTOMATIONS_JSON = stringPreferencesKey("automations_json")
        val RECENT_CONTEXT = stringPreferencesKey("recent_context")
    }

    val activationPhrase: Flow<String> = context.jarvisDataStore.data
        .map { it[Keys.ACTIVATION_PHRASE] ?: "jarvis" }

    val customCommandsJson: Flow<String> = context.jarvisDataStore.data
        .map { it[Keys.CUSTOM_COMMANDS_JSON] ?: "[]" }

    val automationsJson: Flow<String> = context.jarvisDataStore.data
        .map { it[Keys.AUTOMATIONS_JSON] ?: "[]" }

    suspend fun saveAutomationsJson(json: String) {
        context.jarvisDataStore.edit { it[Keys.AUTOMATIONS_JSON] = json }
    }

    suspend fun setActivationPhrase(phrase: String) {
        context.jarvisDataStore.edit { it[Keys.ACTIVATION_PHRASE] = phrase }
    }

    // La frase del Modo Serio se movió a SecureKeyStore (almacenamiento
    // cifrado) en la Fase 9 — ver ConnectionKeyManager.setSeriousModePhrase.

    suspend fun saveCustomCommandsJson(json: String) {
        context.jarvisDataStore.edit { it[Keys.CUSTOM_COMMANDS_JSON] = json }
    }

    suspend fun appendRecentContext(entry: String) {
        context.jarvisDataStore.edit { prefs ->
            val current = prefs[Keys.RECENT_CONTEXT] ?: ""
            prefs[Keys.RECENT_CONTEXT] = (current + "\n" + entry).takeLast(4000)
        }
    }

    suspend fun clearAll() {
        context.jarvisDataStore.edit { it.clear() }
        genericCache.clear()
    }

    /** VIEW MEMORY — resumen legible de lo que J.A.R.V.I.S. recuerda localmente. */
    suspend fun viewMemorySummary(): String {
        val activation = activationPhrase.first()
        val commandsCount = CommandSerializer.fromJson(customCommandsJson.first()).size
        val automationsCount = com.jarvis.assistant.tools.AutomationSerializer.fromJson(automationsJson.first()).size
        val recent = context.jarvisDataStore.data.map { it[Keys.RECENT_CONTEXT] ?: "" }.first()
        return buildString {
            appendLine("Palabra de activación: $activation")
            appendLine("Comandos personalizados guardados: $commandsCount")
            appendLine("Automatizaciones guardadas: $automationsCount")
            appendLine("Claves en memoria genérica (LOCAL_MEMORY): ${genericCache.size}")
            if (recent.isNotBlank()) {
                appendLine()
                appendLine("Contexto reciente:")
                append(recent.takeLast(1000))
            }
        }
    }

    // --- Almacén genérico clave-valor para la herramienta LOCAL_MEMORY ---
    // Se mantiene una caché en memoria para poder leer de forma síncrona desde
    // ToolExecutor, y se persiste en DataStore en segundo plano. Es una
    // simplificación de esta fase; una versión posterior podría exponerlo
    // completamente como Flow/suspend si se requiere estrictamente async.
    private val genericCache = mutableMapOf<String, String>()
    private val genericMapKey = stringPreferencesKey("generic_memory_map_json")

    suspend fun loadGenericMemoryIntoCache() {
        val jsonString = context.jarvisDataStore.data
            .map { it[genericMapKey] ?: "{}" }
            .first()
        val raw = try {
            org.json.JSONObject(jsonString)
        } catch (e: Exception) {
            org.json.JSONObject()
        }
        raw.keys().forEach { key -> genericCache[key] = raw.getString(key) }
    }

    fun getMemoryValue(key: String): String? = genericCache[key]

    suspend fun setMemoryValue(key: String, value: String) {
        genericCache[key] = value
        val obj = org.json.JSONObject()
        genericCache.forEach { (k, v) -> obj.put(k, v) }
        context.jarvisDataStore.edit { it[genericMapKey] = obj.toString() }
    }
}
