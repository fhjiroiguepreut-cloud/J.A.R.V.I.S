package com.jarvis.assistant.tools

/**
 * Comando personalizado definido enteramente por el usuario.
 * Nada aquí viene preprogramado: el editor de comandos (Fase 2) escribe
 * y lee instancias de esta clase desde MemoryManager.
 */
enum class CommandMode { NORMAL, SERIOUS, BOTH }
enum class SecurityLevel { NORMAL, IMPORTANT, SENSITIVE }
enum class CommandStatus { ENABLED, DISABLED }

data class CustomCommand(
    val trigger: String,              // palabra / número / frase elegida por el usuario
    val actionId: String,             // acción a ejecutar (definida por el usuario entre las disponibles)
    val voiceResponse: String,        // lo que J.A.R.V.I.S. dirá
    val mode: CommandMode = CommandMode.NORMAL,
    val requiresConfirmation: Boolean = false,
    val securityLevel: SecurityLevel = SecurityLevel.NORMAL,
    val status: CommandStatus = CommandStatus.ENABLED
)

/**
 * Compara la entrada de voz contra la lista de comandos personalizados.
 * Nunca ejecuta un comando SENSITIVE por coincidencia parcial: exige
 * coincidencia exacta del trigger normalizado.
 */
class CustomCommandMatcher(private val commands: () -> List<CustomCommand>) {
    fun match(normalizedInput: String): CustomCommand? {
        return commands().firstOrNull { command ->
            command.status == CommandStatus.ENABLED &&
                command.trigger.trim().lowercase() == normalizedInput
        }
    }
}
