package com.jarvis.assistant.devices

enum class DeviceConnectionStatus { CONNECTED, DISCONNECTED, PAIRING, TRANSFER, ERROR }

data class AuthorizedDevice(
    val endpointId: String,
    val displayName: String,
    val status: DeviceConnectionStatus
)
