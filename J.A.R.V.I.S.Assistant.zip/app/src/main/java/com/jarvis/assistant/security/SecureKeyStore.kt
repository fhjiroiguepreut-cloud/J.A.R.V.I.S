package com.jarvis.assistant.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * SECURITY — Fase 9
 *
 * Antes, la Connection Key (Fase 4) y la frase secreta del Modo Serio
 * (Fase 7) se guardaban en DataStore de preferencias, en texto plano dentro
 * del contenedor privado de la app. En esta fase de seguridad se migran a
 * `EncryptedSharedPreferences`, cifradas con AES-256 y respaldadas por el
 * Android Keystore (la clave de cifrado nunca sale del hardware seguro del
 * dispositivo). Son, con diferencia, los dos secretos más sensibles de toda
 * la app: la Connection Key protege el emparejamiento entre dispositivos, y
 * la frase del Modo Serio es, por diseño, un secreto que solo el usuario
 * debe conocer.
 */
class SecureKeyStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "jarvis_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getConnectionKey(): String? = prefs.getString(KEY_CONNECTION, null)
    fun setConnectionKey(value: String?) { prefs.edit().putString(KEY_CONNECTION, value).apply() }

    fun getSeriousModePhrase(): String? = prefs.getString(KEY_SERIOUS_MODE, null)
    fun setSeriousModePhrase(value: String?) { prefs.edit().putString(KEY_SERIOUS_MODE, value).apply() }

    private companion object {
        const val KEY_CONNECTION = "connection_key"
        const val KEY_SERIOUS_MODE = "serious_mode_phrase"
    }
}
