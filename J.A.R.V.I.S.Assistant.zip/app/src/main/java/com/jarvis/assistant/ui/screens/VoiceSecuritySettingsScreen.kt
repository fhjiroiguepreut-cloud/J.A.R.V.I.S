package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.theme.JarvisTextSecondary

@Composable
fun VoiceSecuritySettingsScreen(
    activationPhrase: String,
    seriousModePhrase: String?,
    listeningServiceActive: Boolean,
    micPermissionGranted: Boolean,
    notificationsPermissionGranted: Boolean,
    onRequestPermissions: () -> Unit,
    onSaveActivationPhrase: (String) -> Unit,
    onSaveSeriousModePhrase: (String) -> Unit,
    onToggleListeningService: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    var activationInput by remember(activationPhrase) { mutableStateOf(activationPhrase) }
    var seriousInput by remember(seriousModePhrase) { mutableStateOf(seriousModePhrase ?: "") }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Volver") }
            Text("VOICE & SECURITY", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.width(64.dp))
        }

        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ACTIVATION", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(
                    value = activationInput,
                    onValueChange = { activationInput = it },
                    label = { Text("Palabra o frase de activación") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = { onSaveActivationPhrase(activationInput.trim()) }, enabled = activationInput.isNotBlank()) {
                    Text("Guardar")
                }
            }
        }

        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("SERIOUS MODE", style = MaterialTheme.typography.titleSmall)
                Text(
                    "Defina una frase secreta propia. No está fija en el código: solo usted la conoce.",
                    style = MaterialTheme.typography.bodySmall,
                    color = JarvisTextSecondary
                )
                OutlinedTextField(
                    value = seriousInput,
                    onValueChange = { seriousInput = it },
                    label = { Text("Frase secreta del Modo Serio") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = { onSaveSeriousModePhrase(seriousInput.trim()) }, enabled = seriousInput.isNotBlank()) {
                    Text("Guardar")
                }
            }
        }

        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ESCUCHA EN SEGUNDO PLANO", style = MaterialTheme.typography.titleSmall)
                Text(
                    "Mantiene J.A.R.V.I.S. escuchando su palabra de activación y su frase del " +
                        "Modo Serio incluso con la pantalla apagada. Consume más batería que el " +
                        "modo manual (ver README).",
                    style = MaterialTheme.typography.bodySmall,
                    color = JarvisTextSecondary
                )
                if (!micPermissionGranted || !notificationsPermissionGranted) {
                    Button(onClick = onRequestPermissions) { Text("Conceder permisos necesarios") }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Switch(checked = listeningServiceActive, onCheckedChange = onToggleListeningService)
                        Text(if (listeningServiceActive) "Activa" else "Inactiva")
                    }
                }
            }
        }
    }
}
