package com.jarvis.assistant.communication

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.telephony.SmsManager
import android.util.Log

/**
 * MESSAGING (SMS) + CALLS — Fase 6
 *
 * Usa los mecanismos normales de Android:
 * - SmsManager para SMS reales (requiere permiso SEND_SMS).
 * - Intent.ACTION_CALL para llamadas (requiere permiso CALL_PHONE).
 *
 * Sección 19 de la spec: "No realizar llamadas automáticamente sin
 * autorización". Por eso este repositorio NUNCA llama por su cuenta: solo
 * construye el Intent; quien lo use (ToolExecutor + UI) debe pasar primero
 * por una confirmación explícita del usuario.
 */
class CommsRepository(private val context: Context) {

    fun sendSms(phoneNumber: String, message: String): Boolean {
        return try {
            val smsManager = context.getSystemService(SmsManager::class.java)
            val parts = smsManager.divideMessage(message)
            smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null)
            true
        } catch (e: Exception) {
            Log.w("JarvisComms", "sendSms falló", e)
            false
        }
    }

    fun buildCallIntent(phoneNumber: String): Intent {
        return Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber"))
    }
}
