package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.tools.CommandStatus
import com.jarvis.assistant.tools.CustomCommand
import com.jarvis.assistant.ui.theme.JarvisTextSecondary

@Composable
fun CustomCommandsScreen(
    commands: List<CustomCommand>,
    onAdd: () -> Unit,
    onEdit: (CustomCommand) -> Unit,
    onDelete: (CustomCommand) -> Unit,
    onToggleStatus: (CustomCommand) -> Unit,
    onTest: (CustomCommand) -> Unit,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Volver") }
            Text("CUSTOM COMMANDS", style = MaterialTheme.typography.titleMedium)
            Button(onClick = onAdd) { Text("+ Añadir") }
        }

        Spacer(Modifier.height(12.dp))

        if (commands.isEmpty()) {
            Text(
                "Todavía no has creado ningún comando. Pulsa \"+ Añadir\" para crear el primero.",
                color = JarvisTextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(commands) { command ->
                CommandCard(
                    command = command,
                    onEdit = { onEdit(command) },
                    onDelete = { onDelete(command) },
                    onToggleStatus = { onToggleStatus(command) },
                    onTest = { onTest(command) }
                )
            }
        }
    }
}

@Composable
private fun CommandCard(
    command: CustomCommand,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleStatus: () -> Unit,
    onTest: () -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("\"${command.trigger}\"", style = MaterialTheme.typography.titleSmall)
                Text(
                    if (command.status == CommandStatus.ENABLED) "ENABLED" else "DISABLED",
                    color = JarvisTextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            Text(
                "Acción: ${command.actionId} · Modo: ${command.mode} · Seguridad: ${command.securityLevel}",
                style = MaterialTheme.typography.bodySmall,
                color = JarvisTextSecondary
            )
            Text(
                "Respuesta: \"${command.voiceResponse}\"",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onTest) { Text("Probar") }
                TextButton(onClick = onEdit) { Text("Editar") }
                TextButton(onClick = onToggleStatus) {
                    Text(if (command.status == CommandStatus.ENABLED) "Desactivar" else "Activar")
                }
                TextButton(onClick = onDelete) { Text("Eliminar") }
            }
        }
    }
}
