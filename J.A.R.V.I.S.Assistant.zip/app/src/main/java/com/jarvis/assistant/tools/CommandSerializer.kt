package com.jarvis.assistant.tools

import org.json.JSONArray
import org.json.JSONObject

/**
 * Convierte la lista de [CustomCommand] a JSON y viceversa, para guardarla
 * en MemoryManager (VIEW MEMORY / EDIT MEMORY se apoyan en este formato).
 */
object CommandSerializer {

    fun toJson(commands: List<CustomCommand>): String {
        val array = JSONArray()
        commands.forEach { command ->
            val obj = JSONObject()
            obj.put("trigger", command.trigger)
            obj.put("actionId", command.actionId)
            obj.put("voiceResponse", command.voiceResponse)
            obj.put("mode", command.mode.name)
            obj.put("requiresConfirmation", command.requiresConfirmation)
            obj.put("securityLevel", command.securityLevel.name)
            obj.put("status", command.status.name)
            array.put(obj)
        }
        return array.toString()
    }

    fun fromJson(json: String): List<CustomCommand> {
        if (json.isBlank()) return emptyList()
        return try {
            val array = JSONArray(json)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                CustomCommand(
                    trigger = obj.getString("trigger"),
                    actionId = obj.getString("actionId"),
                    voiceResponse = obj.getString("voiceResponse"),
                    mode = CommandMode.valueOf(obj.optString("mode", "NORMAL")),
                    requiresConfirmation = obj.optBoolean("requiresConfirmation", false),
                    securityLevel = SecurityLevel.valueOf(obj.optString("securityLevel", "NORMAL")),
                    status = CommandStatus.valueOf(obj.optString("status", "ENABLED"))
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
