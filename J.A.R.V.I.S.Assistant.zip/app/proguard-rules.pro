# J.A.R.V.I.S. — reglas de ProGuard/R8 para el build de release.
#
# La mayoría del comportamiento de la app es Kotlin puro sin reflexión, así
# que R8 puede optimizar con bastante libertad. Las reglas de abajo solo
# cubren las librerías que sí dependen de reflexión o de generación de
# clases en tiempo de ejecución.

# Nearby Connections / Google Play Services usan (de)serialización interna
# con reflexión en algunos modelos de datos.
-keep class com.google.android.gms.nearby.** { *; }

# EncryptedSharedPreferences / Tink (androidx.security.crypto) registran
# primitivas criptográficas por reflexión.
-keep class com.google.crypto.tink.** { *; }
-dontwarn com.google.crypto.tink.**

# Los enums de la app se comparan por nombre (ToolId.entries.firstOrNull
# { it.name == ... }) al deserializar comandos y automatizaciones desde
# JSON — conservamos sus nombres para que esa comparación no se rompa tras
# ofuscar.
-keepclassmembers enum com.jarvis.assistant.tools.** { *; }
-keepclassmembers enum com.jarvis.assistant.devices.** { *; }
