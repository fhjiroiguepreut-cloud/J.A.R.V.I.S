# J.A.R.V.I.S. — Proyecto completo (Fases 1 a 9)

Proyecto Android nativo (Kotlin + Jetpack Compose) con las 9 fases de tu
especificación implementadas de forma incremental:
- **Fase 1**: interfaz + icono + voz + IA local (por reglas) + memoria.
- **Fase 2**: sistema de herramientas (Tool System) + comandos personalizados
  completos (CUSTOM COMMANDS, ADD/EDIT COMMAND) + ACTIVITY LOG.
- **Fase 3**: archivos reales (buscar, leer, copiar, compartir) con MediaStore
  y Storage Access Framework.
- **Fase 4**: emparejamiento real entre dos dispositivos con Connection Key
  y Nearby Connections (Google Play Services).
- **Fase 5**: transferencia real de archivos entre los dos dispositivos ya
  emparejados.
- **Fase 6**: mensajería dispositivo↔dispositivo, SMS reales y llamadas (con
  confirmación obligatoria).
- **Fase 7**: Modo Serio real + activación por voz en segundo plano.
- **Fase 8**: automatizaciones reales ("cuando ocurra X, realiza Y").
- **Fase 9**: seguridad (cifrado de secretos, pantalla MEMORY) + optimización
  (build de release minificado).

## Cómo compilarlo

1. Abre esta carpeta en **Android Studio** (Koala o más reciente).
2. Deja que Gradle sincronice (usa Android Gradle Plugin 8.5.2 / Kotlin 1.9.24).
3. Ejecuta en un dispositivo físico o emulador con **Android 8.0 (API 26)** o superior.
4. Concede el permiso de micrófono cuando la app lo pida.
5. Pulsa "Activar J.A.R.V.I.S." y habla — verás la transcripción y escucharás la respuesta.

## Novedades de la Fase 9 (última fase)

- **Secretos cifrados de verdad**: la Connection Key y la frase del Modo
  Serio se movieron de DataStore (texto plano) a `EncryptedSharedPreferences`
  (Jetpack Security), cifradas con una clave maestra gestionada por el
  Android Keystore del dispositivo. El resto de la memoria (comandos,
  automatizaciones, preferencias no sensibles) se queda en DataStore normal
  a propósito: cifrar datos que no son secretos no aporta seguridad real y
  solo complica la app.
- **Pantalla MEMORY** (sección 20, pendiente desde la Fase 1): VIEW MEMORY
  muestra un resumen legible (palabra de activación, número de comandos y
  automatizaciones guardados, contexto reciente) y CLEAR MEMORY lo borra
  todo tras confirmación — dejando aparte, a propósito, la Connection Key y
  la frase del Modo Serio, que se gestionan en sus propias pantallas
  (DEVICES y SETTINGS) por ser secretos de seguridad, no memoria general.
- **Optimización del build de release**: `minifyEnabled` + `shrinkResources`
  activados con reglas de ProGuard/R8 propias (`app/proguard-rules.pro`)
  para no romper Nearby Connections, el cifrado (Tink) ni la comparación de
  enums por nombre que usan los deserializadores JSON de comandos y
  automatizaciones.
- **Pequeña optimización de batería**: el bucle de reconocimiento continuo
  de la Fase 7 ahora espera un breve instante tras un error antes de
  reiniciar `SpeechRecognizer`, en vez de reintentar en bucle cerrado.

### Estado final honesto del proyecto
Esto completa las 9 fases con lógica real detrás de cada pieza — nada
simulado silenciosamente; donde algo no era razonable de implementar del
todo (mover archivos ajenos, un motor de wake-word de bajo consumo,
comandos compuestos multi-acción), quedó documentado explícitamente en el
README de su fase, no oculto. El proyecto compila como un Android nativo
estándar en Android Studio; no lo he compilado ni ejecutado yo mismo en
este entorno porque no tengo Android SDK ni emulador aquí — te recomiendo
abrirlo, sincronizar Gradle y probarlo en un dispositivo real, sobre todo
las partes que dependen de hardware/dos dispositivos (Fases 4-6).

## Novedades de la Fase 8

- **Motor de automatizaciones real** (`AutomationEngine.kt`): reacciona a
  eventos reales ya implementados en fases anteriores, no a un temporizador
  simulado. Disparadores disponibles: al iniciar J.A.R.V.I.S., al
  conectarse/desconectarse un dispositivo, al recibir un archivo, al recibir
  un mensaje del dispositivo vinculado, y al activarse el Modo Serio.
- **Pantalla AUTOMATIONS + ADD AUTOMATION**: el usuario elige el disparador
  (X) y la acción real del `ToolRegistry` (Y) entre listas desplegables —
  nada viene preprogramado.
- **Respeta seguridad y confirmaciones** (sección 22): una automatización
  marcada como `SENSITIVE` o con confirmación activada no se ejecuta sola;
  aparece en la pantalla principal como "Automatización pendiente" con
  botones Confirmar/Cancelar, igual que un comando sensible de la Fase 2.
- Las automatizaciones se guardan en memoria local y persisten entre
  reinicios.

### Limitaciones honestas de la Fase 8
- Los disparadores disponibles son los eventos que la app ya sabe detectar
  de verdad (conexión, archivo, mensaje, Modo Serio, inicio). No añadí
  disparadores "de calendario" ni "de ubicación" porque esas integraciones
  no se han construido en ninguna fase anterior — hacerlo ahora habría sido
  simular un disparador sin una fuente de evento real detrás.
- Una automatización solo ejecuta **una** acción; encadenar varias en
  secuencia (como el "PROTOCOLO NEXUS" de la sección 10, comandos
  compuestos) es una ampliación natural sobre esta base, pendiente de
  cuándo quieras abordarla.

## Novedades de la Fase 7

- **SETTINGS → VOICE & SECURITY**: pantalla nueva para configurar la palabra
  de activación y la frase secreta del Modo Serio. Ninguna de las dos está
  fija en el código, tal como exige tu spec — el usuario las escribe.
- **Modo Serio real** (`JarvisState` + `VoiceEngine.applySeriousTone()`): al
  detectarse la frase secreta, la interfaz muestra "SERIOUS MODE ACTIVE", la
  voz pasa a un tono más grave y pausado, y J.A.R.V.I.S. dice el mismo saludo
  ("Hola señor, ¿cómo puedo ayudarle hoy?") pero con ese tono.
- **Activación por voz en segundo plano** (`JarvisListeningService.kt`): un
  servicio en primer plano (con su notificación, como exige Android) escucha
  continuamente y compara cada resultado contra la palabra de activación y la
  frase del Modo Serio guardadas en memoria. Se activa/desactiva desde
  SETTINGS con un interruptor.

### Limitación honesta de la Fase 7 (importante)
Como ya adelantaba en la Fase 1: Android no trae un motor de "wake word" de
bajo consumo. Este servicio reinicia `SpeechRecognizer` en bucle dentro de un
foreground service — funciona de verdad, pero consume más batería y tiene
algo más de latencia que un SDK dedicado (ej. Porcupine de Picovoice, que
requiere una clave/licencia de terceros). Si el consumo de batería resulta
un problema en el uso real, sustituir este servicio por uno basado en un SDK
de wake-word es la mejora natural — y no obliga a tocar el resto de la app,
porque toda la integración pasa por `WakeEvents`.

## Novedades de la Fase 6

- **Mensajería dispositivo↔dispositivo real**: reutiliza el mismo canal
  cifrado de Nearby Connections (Fase 4-5) para mandar texto libre al
  dispositivo J.A.R.V.I.S. vinculado — el ejemplo exacto de tu spec ("Envía
  un mensaje al dispositivo conectado diciendo: ya llegué.").
- **SMS reales** con `SmsManager` (`MESSAGING` con un número de teléfono como
  `target` en vez de "device").
- **Llamadas reales** con `Intent.ACTION_CALL`, pero **nunca automáticas**:
  la pantalla COMMUNICATION siempre muestra un diálogo "¿Confirma que desea
  llamar a...?" antes de marcar, tal como exige la sección 19. Cuando `CALLS`
  se dispara desde un comando de voz personalizado, ya hereda la
  confirmación obligatoria de la Fase 2 (está marcada `SENSITIVE` en el
  `ToolRegistry`).
- **Pantalla COMMUNICATION**: chat simple con el dispositivo vinculado +
  formulario de SMS + formulario de llamada, cada uno detrás de su propio
  permiso en tiempo de ejecución.

### Limitaciones honestas de la Fase 6
- El "chat" con el dispositivo vinculado vive solo en memoria de la sesión
  (no se guarda en la memoria local todavía).
- No hay recepción de SMS ni registro de llamadas entrantes: la spec pide
  "enviar mensajes" e "iniciar llamadas", no gestionar una bandeja de
  entrada completa; añadir eso sería una ampliación de alcance, no una
  omisión de esta fase.

## Novedades de la Fase 5

- **FILE_TRANSFER real**: busca el archivo (reutilizando FILE_SEARCH), toma el
  dispositivo actualmente `CONNECTED` (o el `deviceId` indicado) y envía el
  archivo con la Payload API de Nearby Connections.
- **Nombre de archivo preservado**: como Nearby no conserva el nombre
  original en un Payload de tipo FILE, se envía antes un pequeño mensaje con
  "payloadId:nombre" y el receptor lo empareja al terminar la transferencia.
- **Recepción automática**: al completarse con éxito, el archivo recibido se
  copia a `Download/JARVIS/` del dispositivo receptor y J.A.R.V.I.S. anuncia
  por voz "Archivo recibido y transferencia completada: `<nombre>`",
  siguiendo el mensaje exacto de tu spec en la sección 16.
- **Botón "Enviar"** en la pantalla FILES, además del comando de herramienta
  `FILE_TRANSFER`.

### Limitaciones honestas de la Fase 5
- Por ahora se envía al **primer dispositivo conectado** automáticamente si
  no se indica `deviceId`; con un solo dispositivo emparejado (el caso normal
  de esta spec, "dos dispositivos") es suficiente, pero si en el futuro se
  permiten más de dos, habrá que exponer un selector explícito.
- No hay barra de progreso en pantalla todavía (sí queda registrado el inicio
  y la finalización en el ACTIVITY LOG); añadir progreso en tiempo real es un
  ajuste menor sobre `onPayloadTransferUpdate`, que ya recibe los bytes
  transferidos.
- El flujo de voz completo de la sección 16 ("Busca X y transfiérelo al
  dispositivo conectado") todavía depende de que los comandos de voz
  personalizados pasen texto libre como parámetro — la misma limitación de
  slot-filling señalada en la Fase 3.

## Novedades de la Fase 4

- **Connection Key real** (`ConnectionKeyManager.kt`): se genera un código de
  8 caracteres, se puede regenerar, revocar, o introducir manualmente la
  clave generada en el otro dispositivo. Se guarda localmente.
- **Emparejamiento real con Nearby Connections** (`NearbyPairingManager.kt`,
  librería de Google Play Services): cada dispositivo anuncia su nombre junto
  al hash de su Connection Key; una solicitud de conexión solo se acepta si
  los hashes coinciden en ambos dispositivos — así se cumple "no permitir
  conexiones anónimas" sin depender de la confirmación manual por dígitos que
  Nearby ofrece por defecto.
- **Cifrado**: Nearby Connections cifra automáticamente el canal una vez
  establecida la conexión; no se implementa cifrado propio adicional en esta
  fase.
- **Pantalla DEVICES**: gestión de la Connection Key + lista de dispositivos
  con su estado (CONNECTED, DISCONNECTED, PAIRING, ERROR) + botón para
  desconectar.
- **DEVICE_CONNECT / DEVICE_DISCONNECT** ya ejecutan acciones reales desde
  `ToolExecutor`, en lugar de responder NOT_IMPLEMENTED.

### Limitaciones honestas de la Fase 4
- Se añadió el permiso `INTERNET` porque la librería Nearby Connections lo
  requiere internamente (para resolución de servicio de Google Play
  Services), aunque el canal de datos entre los dos teléfonos es directo
  (Bluetooth/Wi-Fi Direct), no pasa por ningún servidor de J.A.R.V.I.S. ni de
  terceros.
- Nearby Connections necesita que **Google Play Services** esté disponible en
  el dispositivo (no funciona en Android sin servicios de Google, como
  algunos forks de AOSP).
- Todavía no hay envío real de mensajes o archivos por este canal — eso es la
  Fase 5 (transferencia) y la Fase 6 (mensajería), que ya tienen el
  `PayloadCallback` preparado para conectarse.
- La lista de "dispositivos autorizados" vive solo en memoria de la sesión
  actual (no persiste entre reinicios todavía); persistirla es un ajuste
  menor para cuando conectemos la Fase 5.

## Novedades de la Fase 3

- **`minSdk` subido de 26 a 29** (Android 10): necesario para usar
  `MediaStore.Downloads` de forma segura dentro del almacenamiento con ámbito
  (scoped storage). Es un cambio de mi parte respecto a la Fase 1, no algo que
  pidieras explícitamente — si necesitas soporte para Android 8-9, avísame y
  lo adapto usando la API de almacenamiento heredada.
- **FILE_SEARCH real**: busca por nombre entre todos los archivos indexados
  por MediaStore (imágenes, audio, vídeo, documentos), con el mismo flujo de
  desambiguación de tu spec ("He encontrado varios archivos que coinciden...").
- **FILE_READ real**: lee el contenido de archivos de texto plano (.txt, .md,
  .json, .csv, .log). Para binarios (imágenes, audio, PDF, etc.) responde con
  claridad que no puede leerse como texto — no se inventa contenido.
- **FILE_COPY real**: copia el archivo encontrado a `Download/JARVIS/` usando
  MediaStore, sin necesitar un selector de carpeta adicional.
- **FILE_SHARE real**: abre el selector de Android para compartir el archivo
  con cualquier app compatible.
- **Pantalla FILES**: además de por voz, ahora hay una pantalla dedicada con
  buscador y botones Leer/Copiar/Compartir por archivo — útil porque, en esta
  fase, los comandos de voz personalizados (Fase 2) no llevan todavía texto
  libre como parámetro (ver limitación abajo).
- **FILE_MOVE sigue en NOT_IMPLEMENTED**: mover archivos arbitrarios que la
  app no creó requiere el flujo de "acceso por documento" con confirmación
  del sistema (o gestionar `RecoverableSecurityException` en Android 10+).
  Es la Fase 3 más delicada de implementar bien y de forma segura; prefiero
  dejarlo pendiente y explícito antes que simular un movimiento que no ocurre.

### Limitación honesta de la Fase 3
Los comandos de voz personalizados (Fase 2) todavía no capturan texto libre
después del trigger — así que decir "J.A.R.V.I.S., busca informe" no pasa
"informe" como parámetro a `FILE_SEARCH` todavía. Por eso esta fase incluye
también la pantalla FILES con buscador manual. Conectar frases completas del
reconocimiento de voz a parámetros de herramientas (slot filling) es un buen
candidato para la Fase 9 (o antes, si lo prefieres).

## Novedades de la Fase 2

- **Sistema de herramientas** (`ToolRegistry.kt`): las 17 herramientas de la
  especificación están definidas como contrato (nombre, descripción,
  parámetros, permisos, nivel de seguridad). `ToolExecutor.kt` las ejecuta de
  verdad para `VOICE_OUTPUT`, `SYSTEM_INFO` y `LOCAL_MEMORY` (las únicas que no
  dependen de fases futuras); el resto responde `NOT_IMPLEMENTED` explícito.
- **CUSTOM COMMANDS**: pantalla con la lista de comandos (probar / editar /
  activar-desactivar / eliminar), persistida en memoria local como JSON.
- **ADD COMMAND / EDIT COMMAND**: formulario completo (COMMAND, ACTION —
  elegida entre las herramientas reales—, VOICE RESPONSE, MODE, CONFIRMATION,
  SECURITY LEVEL, STATUS). Nada viene preprogramado: el usuario define cada
  campo.
- **Confirmación de comandos sensibles**: un comando marcado como `SENSITIVE`
  o con `requiresConfirmation` nunca se ejecuta directamente por una
  coincidencia de voz; primero pide confirmación en pantalla.
- **ACTIVITY LOG**: cada ejecución de herramienta queda registrada con hora,
  herramienta, detalle y resultado.

### Limitación honesta de la Fase 2
El almacén clave-valor de `LOCAL_MEMORY` usa una caché en memoria sincronizada
con DataStore en segundo plano (para poder leerse de forma síncrona desde el
ejecutor de herramientas). Es una simplificación deliberada de esta fase, no
un dato falso: los valores sí se persisten en disco.

## Qué SÍ hace esta Fase 1

- Interfaz oscura con núcleo animado que reacciona a cada estado (STANDING BY,
  LISTENING, THINKING, EXECUTING, COMPLETE, ERROR, PERMISSION REQUIRED...).
- Reconocimiento de voz real (`SpeechRecognizer` de Android).
- Respuesta hablada real (`TextToSpeech` de Android, configurado en pitch/velocidad
  graves para acercarse a la identidad de voz descrita).
- Memoria local persistente con DataStore (sin conexión a servidores).
- Arquitectura modular por paquetes (`core`, `ai`, `voice`, `memory`, `tools`,
  `ui`) lista para crecer hacia las siguientes fases.
- Icono adaptativo original (núcleo circular + "J" integrada).
- Mensaje explícito "Esta función todavía no está disponible" para cualquier
  intención que aún no tiene una herramienta real conectada — nunca se simula
  una acción.

## Limitaciones honestas de esta primera entrega

- **Voz**: uso el TTS nativo de Android, no una voz "de autor" grabada. Si
  quieres una identidad vocal más distintiva, el siguiente paso sería integrar
  un motor de voz neuronal de terceros (esto requeriría elegir un proveedor,
  ya que Android no trae uno así de fábrica).
- **Cerebro local**: en esta fase es un enrutador de intenciones por reglas,
  no un modelo de lenguaje. `AiBrain.kt` está aislado justo para que, en una
  fase posterior, se pueda conectar un modelo on-device real (por ejemplo, vía
  MediaPipe LLM Inference o llama.cpp con un modelo cuantizado) sin tocar el
  resto de la app.
- **Frase de activación pasiva** ("Oye J.A.R.V.I.S." sin tocar la pantalla):
  esta primera versión activa la escucha con un botón, porque la detección de
  palabra clave en segundo plano (wake word) normalmente necesita un motor
  dedicado (ej. Porcupine) o un servicio en primer plano persistente con su
  propio permiso — se deja como tarea de Fase 7, tal como marca tu propio plan.
- No compilé ni probé el APK en este entorno (no tengo Android SDK/emulador
  aquí); el código está listo para que lo compiles tú en Android Studio.

## Próximos pasos (según tus propias fases)

- **Fase 2**: pantalla CUSTOM COMMANDS + ADD COMMAND (editor visual sobre
  `CustomCommand.kt`, ya con el modelo de datos listo) y sistema de herramientas.
- **Fase 3**: `FILE_SEARCH`, `FILE_READ`, etc. usando el Storage Access
  Framework de Android.
- **Fase 4-5**: emparejamiento y transferencia entre dos dispositivos (Nearby
  Connections API + cifrado).
- **Fase 6**: mensajería/llamadas con los permisos ya declarados en el manifest.
- **Fase 7**: Modo Serio + wake word en segundo plano.
