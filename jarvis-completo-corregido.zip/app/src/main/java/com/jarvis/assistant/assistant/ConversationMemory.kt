package com.jarvis.assistant.assistant

import com.jarvis.assistant.security.Security

enum class Speaker { USER, JARVIS }

data class Turn(val speaker: Speaker, val text: String)

/**
 * Mantiene aproximadamente los últimos [Security.MAX_CONVERSATION_TURNS] turnos
 * de la sesión (sección 9), para poder resolver referencias como "¿por qué?"
 * o "¿y el segundo?" sin pedir que el usuario repita.
 */
class ConversationMemory {

    private val turns = ArrayDeque<Turn>()

    fun addUserTurn(text: String) = add(Turn(Speaker.USER, text))
    fun addJarvisTurn(text: String) = add(Turn(Speaker.JARVIS, text))

    private fun add(turn: Turn) {
        turns.addLast(turn)
        while (turns.size > Security.MAX_CONVERSATION_TURNS) {
            turns.removeFirst()
        }
    }

    fun recentTurns(): List<Turn> = turns.toList()

    /** Representación compacta para inyectar como contexto en el prompt del modelo. */
    fun asPromptContext(): String =
        turns.joinToString("\n") { "${if (it.speaker == Speaker.USER) "Usuario" else "JARVIS"}: ${it.text}" }

    fun clear() = turns.clear()
}
