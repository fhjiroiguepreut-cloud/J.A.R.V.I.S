package com.jarvis.assistant.voice

import com.jarvis.assistant.security.SecureCredentialStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

sealed class VoiceError(val message: String) {
    object NoApiKey : VoiceError("No hay clave de ElevenLabs configurada.")
    object NetworkFailure : VoiceError("Fallo de conexión con ElevenLabs.")
    data class Api(val code: Int, val body: String) : VoiceError("Error de ElevenLabs ($code): $body")
}

sealed class VoiceResult<out T> {
    data class Success<T>(val value: T) : VoiceResult<T>()
    data class Failure(val error: VoiceError) : VoiceResult<Nothing>()
}

/**
 * Cliente de ElevenLabs (sección 5).
 * La clave nunca se registra ni se pasa por ningún lugar visible en la UI;
 * se lee del [SecureCredentialStore] justo antes de la llamada de red.
 */
class ElevenLabsClient(private val credentialStore: SecureCredentialStore) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /** ENTRADA: transcribe audio con ElevenLabs Scribe (/v1/speech-to-text, modelo scribe_v1). */
    suspend fun transcribe(audioFile: File): VoiceResult<String> = withContext(Dispatchers.IO) {
        val apiKey = credentialStore.getElevenLabsKey() ?: return@withContext VoiceResult.Failure(VoiceError.NoApiKey)

        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("model_id", "scribe_v1")
            .addFormDataPart(
                "file", audioFile.name,
                audioFile.asRequestBody("audio/mp4".toMediaType())
            )
            .build()

        val request = Request.Builder()
            .url("https://api.elevenlabs.io/v1/speech-to-text")
            .addHeader("xi-api-key", apiKey)
            .post(body)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext VoiceResult.Failure(VoiceError.Api(response.code, text))
                }
                val transcript = JSONObject(text).optString("text", "")
                VoiceResult.Success(transcript)
            }
        } catch (e: Exception) {
            VoiceResult.Failure(VoiceError.NetworkFailure)
        }
    }

    /** SALIDA: sintetiza voz con ElevenLabs TTS. Devuelve los bytes de audio (mp3). */
    suspend fun synthesizeSpeech(text: String, voiceId: String): VoiceResult<ByteArray> =
        withContext(Dispatchers.IO) {
            val apiKey = credentialStore.getElevenLabsKey() ?: return@withContext VoiceResult.Failure(VoiceError.NoApiKey)

            val json = JSONObject().apply {
                put("text", text)
                put("model_id", "eleven_multilingual_v2")
            }

            val request = Request.Builder()
                .url("https://api.elevenlabs.io/v1/text-to-speech/$voiceId")
                .addHeader("xi-api-key", apiKey)
                .addHeader("Content-Type", "application/json")
                .post(json.toString().toRequestBody("application/json".toMediaType()))
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        val err = response.body?.string().orEmpty()
                        return@withContext VoiceResult.Failure(VoiceError.Api(response.code, err))
                    }
                    val bytes = response.body?.bytes()
                        ?: return@withContext VoiceResult.Failure(VoiceError.NetworkFailure)
                    VoiceResult.Success(bytes)
                }
            } catch (e: Exception) {
                VoiceResult.Failure(VoiceError.NetworkFailure)
            }
        }
}

private fun File.asRequestBody(mediaType: okhttp3.MediaType) =
    this.readBytes().toRequestBody(mediaType)
