package com.jarvis.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.voice.ReactorState

private val AccentCyan = Color(0xFF4FD7E8)
private val ButtonSurface = Color(0xFF10141A)

/**
 * Controles grandes y fáciles de tocar (sección 13): micrófono, detener,
 * modo breve (brief), plan, memoria.
 */
@Composable
fun BottomControls(
    reactorState: ReactorState,
    onMicPressed: () -> Unit,
    onStopPressed: () -> Unit,
    onBriefPressed: () -> Unit,
    onPlanPressed: () -> Unit,
    onMemoryPressed: () -> Unit,
    onGraphPressed: () -> Unit,
    onSettingsPressed: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF07090C))
            .padding(vertical = 12.dp, horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        ControlButton(Icons.Filled.MenuBook, "Resumen", onBriefPressed)
        ControlButton(Icons.Filled.Checklist, "Plan", onPlanPressed)

        // Botón principal de micrófono, más grande.
        FloatingActionButton(
            onClick = { if (reactorState == ReactorState.LISTENING) onStopPressed() else onMicPressed() },
            containerColor = if (reactorState == ReactorState.LISTENING) Color(0xFFFF5C5C) else AccentCyan,
            modifier = Modifier.size(72.dp)
        ) {
            Icon(
                imageVector = if (reactorState == ReactorState.LISTENING) Icons.Filled.Stop else Icons.Filled.Mic,
                contentDescription = "Micrófono",
                tint = Color.Black
            )
        }

        ControlButton(Icons.Filled.Bookmark, "Memoria", onMemoryPressed)
        ControlButton(Icons.Filled.Hub, "Grafo", onGraphPressed)
        ControlButton(Icons.Filled.Settings, "Ajustes", onSettingsPressed)
    }
}

@Composable
private fun ControlButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .size(52.dp)
                .background(ButtonSurface, CircleShape)
        ) {
            Icon(icon, contentDescription = label, tint = AccentCyan)
        }
        Text(label, color = Color(0xFF8A93A0), style = MaterialTheme.typography.labelSmall)
    }
}
