package com.jarvis.assistant.assistant

sealed class JarvisTool {
    data class SearchBrain(val query: String) : JarvisTool()
    data class ResearchWeb(val query: String) : JarvisTool()
    object ReadInbox : JarvisTool()
    object BriefMe : JarvisTool()
    data class Remember(val fact: String) : JarvisTool()
    object PlanDay : JarvisTool()
}

sealed class ToolOutcome {
    data class Success(val message: String, val sourceNote: String? = null) : ToolOutcome()
    data class PendingAuthorization(val explanation: String) : ToolOutcome()
    data class Error(val message: String) : ToolOutcome()
}
