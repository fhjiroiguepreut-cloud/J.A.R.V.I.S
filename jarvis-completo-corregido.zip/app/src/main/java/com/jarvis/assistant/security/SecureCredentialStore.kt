package com.jarvis.assistant.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Almacén de credenciales cifrado (sección 5 y 18).
 *
 * Reglas que se cumplen aquí:
 *  - La clave se escribe UNA vez desde una pantalla de configuración dedicada
 *    (nunca se muestra de vuelta en texto plano una vez guardada).
 *  - No se registra en logs (no hay ningún Log.d/println con el valor).
 *  - No se expone en la interfaz conversacional de JARVIS bajo ninguna
 *    circunstancia: el ToolExecutor y los clientes de red la leen, pero
 *    nunca la devuelven como parte de una respuesta.
 */
class SecureCredentialStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "jarvis_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveElevenLabsKey(key: String) {
        prefs.edit().putString(KEY_ELEVENLABS, key).apply()
    }

    fun getElevenLabsKey(): String? = prefs.getString(KEY_ELEVENLABS, null)

    fun hasElevenLabsKey(): Boolean = !getElevenLabsKey().isNullOrBlank()

    fun clearElevenLabsKey() {
        prefs.edit().remove(KEY_ELEVENLABS).apply()
    }

    companion object {
        private const val KEY_ELEVENLABS = "elevenlabs_api_key"
    }
}
