package com.jarvis.assistant.profile

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "jarvis_profile")

/**
 * Contexto personal/profesional del usuario (sección 16).
 * Nada de esto se inventa: solo se guarda lo que el usuario respondió.
 * Todos los campos son nullable/opcionales hasta que el usuario los responda.
 */
data class UserProfile(
    val preferredAddressName: String? = null,
    val occupation: String? = null,
    val businessOrProject: String? = null,
    val whatTheySell: String? = null,
    val pricing: String? = null,
    val clients: String? = null,
    val toolsUsed: String? = null,
    val professionalContext: String? = null,
    val personalContext: String? = null,
    val speakingStyle: String? = null,
    val onboardingCompleted: Boolean = false,
    val demoMode: Boolean = true
) {
    /** Contexto compacto para inyectar en el prompt del modelo de IA. */
    fun asPromptContext(): String {
        if (!onboardingCompleted) return "(El usuario todavía no completó la configuración inicial.)"
        return buildString {
            preferredAddressName?.let { append("Nombre/forma de dirigirse al usuario: $it. ") }
            occupation?.let { append("Ocupación: $it. ") }
            businessOrProject?.let { append("Negocio/proyecto: $it. ") }
            whatTheySell?.let { append("Qué vende: $it. ") }
            pricing?.let { append("Precios: $it. ") }
            clients?.let { append("Clientes: $it. ") }
            toolsUsed?.let { append("Herramientas que usa: $it. ") }
            professionalContext?.let { append("Contexto profesional adicional: $it. ") }
            personalContext?.let { append("Contexto personal: $it. ") }
            speakingStyle?.let { append("Estilo de habla preferido: $it. ") }
        }
    }
}

private object Keys {
    val NAME = stringPreferencesKey("preferred_address_name")
    val OCCUPATION = stringPreferencesKey("occupation")
    val BUSINESS = stringPreferencesKey("business_or_project")
    val SELLS = stringPreferencesKey("what_they_sell")
    val PRICING = stringPreferencesKey("pricing")
    val CLIENTS = stringPreferencesKey("clients")
    val TOOLS = stringPreferencesKey("tools_used")
    val PROF_CONTEXT = stringPreferencesKey("professional_context")
    val PERSONAL_CONTEXT = stringPreferencesKey("personal_context")
    val SPEAKING_STYLE = stringPreferencesKey("speaking_style")
    val ONBOARDING_DONE = booleanPreferencesKey("onboarding_completed")
    val DEMO_MODE = booleanPreferencesKey("demo_mode")
}

class ProfileRepository(private val context: Context) {

    val profileFlow: Flow<UserProfile> = context.dataStore.data.map { prefs ->
        UserProfile(
            preferredAddressName = prefs[Keys.NAME],
            occupation = prefs[Keys.OCCUPATION],
            businessOrProject = prefs[Keys.BUSINESS],
            whatTheySell = prefs[Keys.SELLS],
            pricing = prefs[Keys.PRICING],
            clients = prefs[Keys.CLIENTS],
            toolsUsed = prefs[Keys.TOOLS],
            professionalContext = prefs[Keys.PROF_CONTEXT],
            personalContext = prefs[Keys.PERSONAL_CONTEXT],
            speakingStyle = prefs[Keys.SPEAKING_STYLE],
            onboardingCompleted = prefs[Keys.ONBOARDING_DONE] ?: false,
            // Por seguridad, el modo demo empieza activado (sección 14) si no hay valor guardado.
            demoMode = prefs[Keys.DEMO_MODE] ?: true
        )
    }

    suspend fun save(profile: UserProfile) {
        context.dataStore.edit { prefs ->
            profile.preferredAddressName?.let { prefs[Keys.NAME] = it }
            profile.occupation?.let { prefs[Keys.OCCUPATION] = it }
            profile.businessOrProject?.let { prefs[Keys.BUSINESS] = it }
            profile.whatTheySell?.let { prefs[Keys.SELLS] = it }
            profile.pricing?.let { prefs[Keys.PRICING] = it }
            profile.clients?.let { prefs[Keys.CLIENTS] = it }
            profile.toolsUsed?.let { prefs[Keys.TOOLS] = it }
            profile.professionalContext?.let { prefs[Keys.PROF_CONTEXT] = it }
            profile.personalContext?.let { prefs[Keys.PERSONAL_CONTEXT] = it }
            profile.speakingStyle?.let { prefs[Keys.SPEAKING_STYLE] = it }
            prefs[Keys.ONBOARDING_DONE] = profile.onboardingCompleted
            prefs[Keys.DEMO_MODE] = profile.demoMode
        }
    }

    suspend fun setDemoMode(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[Keys.DEMO_MODE] = enabled }
    }
}
