package com.jarvis.assistant.assistant

import com.jarvis.assistant.demo.DemoDataGenerator
import com.jarvis.assistant.index.IndexResult
import com.jarvis.assistant.memory.MemoryStore

/**
 * Ejecuta las herramientas de JARVIS (sección 10), respetando las reglas
 * absolutas de la sección 18:
 *  - read_inbox es SOLO LECTURA: nunca puede enviar nada.
 *  - remember solo escribe en el espacio de memoria privado.
 *  - Nada aquí inventa nombres, precios, fechas, clientes ni fuentes: si no
 *    hay datos (índice vacío, sin conexión, modo demo desactivado sin datos
 *    reales todavía indexados), se dice explícitamente que no hay información,
 *    en vez de rellenar con una respuesta plausible.
 */
class ToolExecutor(
    private val memoryStore: MemoryStore,
    private val demoModeProvider: () -> Boolean,
    private val currentIndexProvider: () -> IndexResult?
) {

    fun execute(tool: JarvisTool): ToolOutcome = when (tool) {
        is JarvisTool.SearchBrain -> searchBrain(tool.query)
        is JarvisTool.ResearchWeb -> researchWeb(tool.query)
        is JarvisTool.ReadInbox -> readInbox()
        is JarvisTool.BriefMe -> briefMe()
        is JarvisTool.Remember -> remember(tool.fact)
        is JarvisTool.PlanDay -> planDay()
    }

    private fun searchBrain(query: String): ToolOutcome {
        val index = currentIndexProvider()
        if (index == null || index.documents.isEmpty()) {
            return ToolOutcome.Error("No hay ningún índice de archivos cargado todavía. Selecciona una carpeta primero.")
        }
        val matches = index.documents.filter {
            it.displayName.contains(query, ignoreCase = true) || it.excerpt.contains(query, ignoreCase = true)
        }
        if (matches.isEmpty()) {
            return ToolOutcome.Success("No encontré nada relacionado con \"$query\" en los archivos indexados.")
        }
        val names = matches.take(5).joinToString(", ") { it.displayName }
        return ToolOutcome.Success(
            message = "Encontré referencias a \"$query\" en: $names.",
            sourceNote = "Fuente: archivos indexados desde ${index.folderDisplayName}."
        )
    }

    private fun researchWeb(query: String): ToolOutcome {
        // La integración real de búsqueda web se conecta aquí (cliente HTTP a un
        // proveedor de búsqueda). Sin una clave/proveedor configurado, JARVIS debe
        // decirlo explícitamente en vez de inventar resultados (sección 18/19).
        return ToolOutcome.Error(
            "La investigación web todavía no tiene un proveedor de búsqueda configurado, así que no puedo research_web \"$query\" con datos reales todavía."
        )
    }

    private fun readInbox(): ToolOutcome {
        if (demoModeProvider()) {
            val summary = DemoDataGenerator.demoInboxSummary().joinToString("\n")
            return ToolOutcome.Success("(Modo demostración) Resumen de bandeja:\n$summary")
        }
        return ToolOutcome.Error(
            "read_inbox real todavía no está conectado a una cuenta de correo. Nunca voy a enviar nada de todas formas: esta herramienta es solo lectura."
        )
    }

    private fun briefMe(): ToolOutcome {
        if (demoModeProvider()) {
            val brief = DemoDataGenerator.demoBrief().joinToString("\n")
            return ToolOutcome.Success("(Modo demostración) Resumen del día:\n$brief")
        }
        return ToolOutcome.Error("brief_me real todavía no está conectado a un calendario.")
    }

    private fun remember(fact: String): ToolOutcome {
        val saved = memoryStore.remember(fact)
        // JARVIS debe decir exactamente qué guardó (sección 10).
        return ToolOutcome.Success("Guardé esto en tu memoria (${saved.id}): \"${saved.content}\".")
    }

    private fun planDay(): ToolOutcome {
        val memories = memoryStore.listAll()
        if (memories.isEmpty()) {
            return ToolOutcome.Success("Todavía no tengo suficiente contexto guardado para generar un plan con prioridades reales. Puedo generar uno de ejemplo si activas el modo demostración.")
        }
        val top5 = memories.takeLast(5).map { it.content }
        return ToolOutcome.Success(
            "Prioridades sugeridas a partir de lo que recuerdo:\n" +
                top5.mapIndexed { i, m -> "${i + 1}. $m" }.joinToString("\n")
        )
    }
}
