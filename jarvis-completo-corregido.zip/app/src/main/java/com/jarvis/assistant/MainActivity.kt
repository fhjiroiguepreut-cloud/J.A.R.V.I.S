package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.ai.UnavailableAiClient
import com.jarvis.assistant.assistant.ConversationMemory
import com.jarvis.assistant.assistant.JarvisOrchestrator
import com.jarvis.assistant.assistant.ToolExecutor
import com.jarvis.assistant.demo.DemoDataGenerator
import com.jarvis.assistant.graph.GraphBuilder
import com.jarvis.assistant.graph.KnowledgeGraph
import com.jarvis.assistant.index.FileIndexer
import com.jarvis.assistant.index.IndexResult
import com.jarvis.assistant.memory.MemoryStore
import com.jarvis.assistant.profile.ProfileRepository
import com.jarvis.assistant.profile.UserProfile
import com.jarvis.assistant.security.SecureCredentialStore
import com.jarvis.assistant.ui.MainScreen
import com.jarvis.assistant.ui.OnboardingScreen
import com.jarvis.assistant.ui.SettingsScreen
import com.jarvis.assistant.voice.ElevenLabsClient
import com.jarvis.assistant.voice.JarvisVoiceController
import com.jarvis.assistant.voice.ReactorState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Screen { LOADING, ONBOARDING, MAIN, SETTINGS }

class MainActivity : ComponentActivity() {

    // --- Dependencias (sin framework de inyección: proyecto pequeño y explícito) ---
    private lateinit var profileRepository: ProfileRepository
    private lateinit var memoryStore: MemoryStore
    private lateinit var credentialStore: SecureCredentialStore
    private lateinit var elevenLabsClient: ElevenLabsClient
    private lateinit var conversationMemory: ConversationMemory
    private lateinit var toolExecutor: ToolExecutor
    private lateinit var orchestrator: JarvisOrchestrator
    private lateinit var voiceController: JarvisVoiceController
    private lateinit var fileIndexer: FileIndexer

    // --- Estado observable por Compose ---
    private var screen by mutableStateOf(Screen.LOADING)
    private var profile by mutableStateOf(UserProfile())
    private var reactorState by mutableStateOf(ReactorState.IDLE)
    private var micLevel by mutableStateOf(0f)
    private var speakingLevel by mutableStateOf(0f)
    private var indexResult by mutableStateOf<IndexResult?>(null)
    private var graph by mutableStateOf<KnowledgeGraph?>(null)
    private var errorMessage by mutableStateOf<String?>(null)

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            voiceController.startListening()
        } else {
            errorMessage = "Necesito permiso de micrófono para escucharte. Actívalo cuando el sistema lo pida de nuevo, o desde Ajustes del teléfono."
        }
    }

    private val pickFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) indexFolder(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        profileRepository = ProfileRepository(this)
        memoryStore = MemoryStore(this)
        credentialStore = SecureCredentialStore(this)
        elevenLabsClient = ElevenLabsClient(credentialStore)
        conversationMemory = ConversationMemory()
        toolExecutor = ToolExecutor(
            memoryStore = memoryStore,
            demoModeProvider = { profile.demoMode },
            currentIndexProvider = { indexResult }
        )
        orchestrator = JarvisOrchestrator(UnavailableAiClient(), toolExecutor, conversationMemory)
        voiceController = JarvisVoiceController(this, elevenLabsClient, orchestrator)
        fileIndexer = FileIndexer(this)

        wireVoiceCallbacks()

        lifecycleScope.launch {
            profileRepository.profileFlow.collect { loaded ->
                profile = loaded
                voiceController.updateProfile(loaded)
                if (screen == Screen.LOADING) {
                    screen = if (loaded.onboardingCompleted) Screen.MAIN else Screen.ONBOARDING
                }
                if (loaded.demoMode && indexResult == null) {
                    indexResult = DemoDataGenerator.demoIndexResult()
                    graph = GraphBuilder.build(indexResult!!)
                }
            }
        }

        setContent {
            MaterialTheme {
                when (screen) {
                    Screen.LOADING -> { /* breve, sin parpadeo de UI a medio construir */ }
                    Screen.ONBOARDING -> OnboardingScreen(onComplete = { newProfile ->
                        lifecycleScope.launch { profileRepository.save(newProfile) }
                        screen = Screen.MAIN
                    })
                    Screen.MAIN -> MainScreen(
                        reactorState = reactorState,
                        micLevel = micLevel,
                        speakingLevel = speakingLevel,
                        graph = graph,
                        conversation = conversationMemory.recentTurns(),
                        errorMessage = errorMessage,
                        demoModeEnabled = profile.demoMode,
                        onDismissError = { errorMessage = null },
                        onMicPressed = { requestMicAndListen() },
                        onStopPressed = { voiceController.stopEverything() },
                        onBriefPressed = { runTextCommand("resumen del día") },
                        onPlanPressed = { runTextCommand("plan del día") },
                        onMemoryPressed = { showMemorySummary() },
                        onSettingsPressed = { screen = Screen.SETTINGS },
                        onSendText = { text -> runTextCommand(text) }
                    )
                    Screen.SETTINGS -> SettingsScreen(
                        hasApiKey = credentialStore.hasElevenLabsKey(),
                        demoModeEnabled = profile.demoMode,
                        onSaveApiKey = { key -> credentialStore.saveElevenLabsKey(key) },
                        onClearApiKey = { credentialStore.clearElevenLabsKey() },
                        onDemoModeChanged = { enabled ->
                            lifecycleScope.launch { profileRepository.setDemoMode(enabled) }
                        },
                        onEditProfile = { screen = Screen.ONBOARDING },
                        onBack = { screen = Screen.MAIN }
                    )
                }
            }
        }
    }

    private fun wireVoiceCallbacks() {
        voiceController.onStateChanged = { state -> reactorState = state }
        voiceController.onMicLevel = { level -> micLevel = level }
        voiceController.onErrorMessage = { msg -> errorMessage = msg }
        voiceController.onJarvisText = { /* ya queda reflejado en conversationMemory */ }
    }

    private fun requestMicAndListen() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) {
            voiceController.startListening()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun runTextCommand(text: String) {
        lifecycleScope.launch {
            orchestrator.handleUserMessage(text, profile)
            // conversationMemory se actualiza dentro del orquestador; forzamos recomposición:
            reactorState = reactorState
        }
    }

    private fun showMemorySummary() {
        val facts = memoryStore.listAll()
        errorMessage = null
        runTextCommand(
            if (facts.isEmpty()) "no tengo nada guardado en memoria todavía"
            else "recuérdame qué tengo guardado"
        )
    }

    private fun indexFolder(treeUri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            errorMessage = "No se pudo obtener permiso de lectura persistente para la carpeta."
            return
        }
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { fileIndexer.indexFolder(treeUri) }
                indexResult = result
                graph = GraphBuilder.build(result)
            } catch (e: Exception) {
                errorMessage = "Fallo al indexar la carpeta: ${e.message ?: "error desconocido"}"
            }
        }
    }

    /** Punto de entrada público para elegir carpeta desde la UI si se desea exponer un botón. */
    fun launchFolderPicker() {
        pickFolderLauncher.launch(null)
    }
}
