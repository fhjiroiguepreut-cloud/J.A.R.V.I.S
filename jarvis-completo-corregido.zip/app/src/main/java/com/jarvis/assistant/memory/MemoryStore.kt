package com.jarvis.assistant.memory

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

data class MemoryFact(
    val id: String,
    val content: String,
    val savedAtIso: String
)

/**
 * JARVIS solo puede escribir dentro de su propio espacio de memoria privado
 * (sección 15). Nunca toca los documentos originales ni las carpetas indexadas
 * por el usuario (SAF), que son de solo lectura y viven fuera de este directorio.
 */
class MemoryStore(context: Context) {

    private val memoryDir: File = File(context.filesDir, "memory").apply { mkdirs() }
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)

    fun remember(fact: String): MemoryFact {
        val index = nextIndex()
        val id = "hecho_%03d".format(index)
        val file = File(memoryDir, "$id.md")
        val timestamp = dateFormat.format(System.currentTimeMillis())
        file.writeText("---\nfecha: $timestamp\n---\n$fact\n")
        return MemoryFact(id = id, content = fact, savedAtIso = timestamp)
    }

    fun listAll(): List<MemoryFact> {
        val files = memoryDir.listFiles { f -> f.extension == "md" } ?: emptyArray()
        return files.sortedBy { it.name }.mapNotNull { file ->
            val text = file.readText()
            val content = text.substringAfter("---\n").substringAfter("---\n").trim()
            val id = file.nameWithoutExtension
            if (content.isBlank()) null else MemoryFact(id, content, savedAtIso = "")
        }
    }

    fun forget(id: String): Boolean {
        val file = File(memoryDir, "$id.md")
        return file.exists() && file.delete()
    }

    private fun nextIndex(): Int {
        val existing = memoryDir.listFiles { f -> f.extension == "md" } ?: emptyArray()
        return existing.size + 1
    }
}
