package com.jarvis.assistant.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.graph.GraphNode

private val Surface = Color(0xFF10141A)
private val TextDim = Color(0xFF8A93A0)

/** Inspector del nodo/documento seleccionado (sección 13), deslizable en pantallas pequeñas. */
@Composable
fun InspectorPanel(
    node: GraphNode?,
    excerpt: String?,
    onDismiss: () -> Unit
) {
    AnimatedVisibility(visible = node != null) {
        if (node == null) return@AnimatedVisibility
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(node.label, color = Color.White, style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Cerrar", tint = TextDim)
                }
            }
            Text("Tipo: ${node.typeTag}   ·   Conexiones: ${node.connectionCount}", color = TextDim, style = MaterialTheme.typography.bodySmall)
            if (!excerpt.isNullOrBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(excerpt, color = TextDim, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/** Banner de error visible — JARVIS nunca falla en silencio (sección 20). */
@Composable
fun ErrorBanner(message: String?, onDismiss: () -> Unit) {
    AnimatedVisibility(visible = message != null) {
        if (message == null) return@AnimatedVisibility
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF2A1010))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Warning, contentDescription = null, tint = Color(0xFFFF8A8A))
            Spacer(Modifier.width(8.dp))
            Text(message, color = Color(0xFFFF8A8A), modifier = Modifier.weight(1f))
            IconButton(onClick = onDismiss) {
                Icon(Icons.Filled.Close, contentDescription = "Cerrar", tint = Color(0xFFFF8A8A))
            }
        }
    }
}
