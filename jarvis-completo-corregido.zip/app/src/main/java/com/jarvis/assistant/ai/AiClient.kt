package com.jarvis.assistant.ai

sealed class AiResult {
    data class Success(val text: String) : AiResult()
    object Unavailable : AiResult()
    data class Error(val message: String) : AiResult()
}

/**
 * Contrato para el modelo de lenguaje que da personalidad y razonamiento a JARVIS.
 * Se deja intercambiable a propósito: el encargo no fija qué proveedor de IA usar
 * fuera de ElevenLabs (que es solo voz), así que aquí solo se define el contrato
 * y un stub; conectar un proveedor real es una decisión que debe tomar el usuario
 * explícitamente (sección 18: nunca gastar sin autorización — muchos proveedores
 * de IA son de pago).
 */
interface AiClient {
    suspend fun complete(systemPrompt: String, conversationContext: String, userMessage: String): AiResult
}

/**
 * Implementación de respaldo cuando no hay proveedor de IA conectado.
 * Cumple la sección 19: JARVIS sigue funcionando (conversación básica por
 * patrones + herramientas), y siempre indica con claridad que el modelo de
 * IA no está disponible, en vez de fingir una respuesta generada por IA.
 */
class UnavailableAiClient : AiClient {
    override suspend fun complete(systemPrompt: String, conversationContext: String, userMessage: String): AiResult {
        return AiResult.Unavailable
    }
}
