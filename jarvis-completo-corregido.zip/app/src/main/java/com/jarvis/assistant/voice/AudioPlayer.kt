package com.jarvis.assistant.voice

import android.media.MediaPlayer
import java.io.File

enum class PlaybackState { IDLE, PLAYING, ERROR }

/**
 * Reproduce el audio de respuesta de JARVIS.
 * El propio [JarvisVoiceController] se encarga de suspender el AudioRecorder
 * mientras esto reproduce, para evitar el bucle descrito en la sección 7.
 */
class AudioPlayer {

    private var mediaPlayer: MediaPlayer? = null

    var onStateChanged: ((PlaybackState) -> Unit)? = null
    var onCompleted: (() -> Unit)? = null

    fun play(audioBytes: ByteArray, cacheDir: File) {
        stop()
        val tempFile = File.createTempFile("jarvis_tts_", ".mp3", cacheDir)
        tempFile.writeBytes(audioBytes)

        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(tempFile.absolutePath)
                setOnCompletionListener {
                    onStateChanged?.invoke(PlaybackState.IDLE)
                    onCompleted?.invoke()
                    tempFile.delete()
                }
                setOnErrorListener { _, _, _ ->
                    onStateChanged?.invoke(PlaybackState.ERROR)
                    tempFile.delete()
                    true
                }
                prepare()
                start()
            }
            onStateChanged?.invoke(PlaybackState.PLAYING)
        } catch (e: Exception) {
            onStateChanged?.invoke(PlaybackState.ERROR)
        }
    }

    /** Interrupción manual (sección 7): botón de detener. */
    fun stop() {
        mediaPlayer?.apply {
            try {
                if (isPlaying) stop()
            } catch (_: Exception) {
            }
            release()
        }
        mediaPlayer = null
    }

    /** Nivel aproximado de reproducción (0f..1f) para sincronizar el pulso del núcleo. */
    fun currentLevel(): Float {
        // MediaPlayer no expone amplitud real; se usa un pulso constante mientras reproduce,
        // y la UI lo anima como una onda regular en vez de un nivel real (documentado: no se
        // finge que sea el nivel real del micrófono, es únicamente una animación de "hablando").
        return if (mediaPlayer?.isPlaying == true) 0.6f else 0f
    }
}
