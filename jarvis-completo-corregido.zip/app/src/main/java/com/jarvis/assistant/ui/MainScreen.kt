package com.jarvis.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.assistant.Speaker
import com.jarvis.assistant.assistant.Turn
import com.jarvis.assistant.graph.GraphNode
import com.jarvis.assistant.graph.KnowledgeGraph
import com.jarvis.assistant.voice.ReactorState

enum class CenterView { CORE, GRAPH }

/**
 * Pantalla principal (sección 13): núcleo/grafo en el centro, panel lateral
 * como inspector, controles grandes abajo, chat de texto para pruebas
 * (sección de PASO 3 del encargo original) siempre disponible como respaldo
 * de la voz.
 */
@Composable
fun MainScreen(
    reactorState: ReactorState,
    micLevel: Float,
    speakingLevel: Float,
    graph: KnowledgeGraph?,
    conversation: List<Turn>,
    errorMessage: String?,
    demoModeEnabled: Boolean,
    onDismissError: () -> Unit,
    onMicPressed: () -> Unit,
    onStopPressed: () -> Unit,
    onBriefPressed: () -> Unit,
    onPlanPressed: () -> Unit,
    onMemoryPressed: () -> Unit,
    onSettingsPressed: () -> Unit,
    onSendText: (String) -> Unit
) {
    var centerView by remember { mutableStateOf(CenterView.CORE) }
    var selectedNode by remember { mutableStateOf<GraphNode?>(null) }
    var textInput by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF07090C))) {

        ErrorBanner(message = errorMessage, onDismiss = onDismissError)

        if (demoModeEnabled) {
            Text(
                "MODO DEMOSTRACIÓN — datos ficticios",
                color = Color(0xFF07090C),
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFFC24F))
                    .padding(4.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                style = MaterialTheme.typography.labelSmall
            )
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (centerView) {
                CenterView.CORE -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        HolographicCore(reactorState, micLevel, speakingLevel)
                        Spacer(Modifier.height(12.dp))
                        Text(reactorStateLabel(reactorState), color = Color(0xFF8A93A0))
                    }
                }
                CenterView.GRAPH -> {
                    if (graph != null) {
                        GraphView(graph = graph, onNodeSelected = { selectedNode = it })
                    } else {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Todavía no hay ningún índice para mostrar como grafo.", color = Color(0xFF8A93A0))
                        }
                    }
                }
            }

            // Alternar centro (núcleo <-> grafo)
            IconButton(
                onClick = { centerView = if (centerView == CenterView.CORE) CenterView.GRAPH else CenterView.CORE },
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
            ) {
                Icon(
                    imageVector = androidx.compose.material.icons.filled.SwapHoriz,
                    contentDescription = "Alternar vista",
                    tint = Color(0xFF4FD7E8)
                )
            }
        }

        InspectorPanel(
            node = selectedNode,
            excerpt = null,
            onDismiss = { selectedNode = null }
        )

        // Chat de texto: respaldo funcional de la voz, siempre disponible (PASO 3 original).
        ConversationLog(conversation)
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Escribe a JARVIS…") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (textInput.isNotBlank()) {
                        onSendText(textInput)
                        textInput = ""
                    }
                })
            )
            IconButton(onClick = {
                if (textInput.isNotBlank()) {
                    onSendText(textInput)
                    textInput = ""
                }
            }) {
                Icon(androidx.compose.material.icons.filled.Send, contentDescription = "Enviar", tint = Color(0xFF4FD7E8))
            }
        }

        BottomControls(
            reactorState = reactorState,
            onMicPressed = onMicPressed,
            onStopPressed = onStopPressed,
            onBriefPressed = onBriefPressed,
            onPlanPressed = onPlanPressed,
            onMemoryPressed = onMemoryPressed,
            onGraphPressed = { centerView = CenterView.GRAPH },
            onSettingsPressed = onSettingsPressed
        )
    }
}

@Composable
private fun ConversationLog(conversation: List<Turn>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 160.dp)
            .padding(horizontal = 12.dp)
    ) {
        items(conversation) { turn ->
            val label = if (turn.speaker == Speaker.USER) "Tú" else "JARVIS"
            Text(
                "$label: ${turn.text}",
                color = if (turn.speaker == Speaker.USER) Color.White else Color(0xFF4FD7E8),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(vertical = 2.dp)
            )
        }
    }
}

private fun reactorStateLabel(state: ReactorState): String = when (state) {
    ReactorState.IDLE -> "En espera"
    ReactorState.LISTENING -> "Escuchando…"
    ReactorState.THINKING -> "Pensando…"
    ReactorState.SPEAKING -> "Hablando…"
    ReactorState.ERROR -> "Error"
}
