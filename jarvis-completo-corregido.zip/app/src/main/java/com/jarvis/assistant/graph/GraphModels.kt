package com.jarvis.assistant.graph

data class GraphNode(
    val id: String,
    val label: String,
    val connectionCount: Int,
    val typeTag: String,
    var x: Float = 0f,
    var y: Float = 0f
)

data class GraphEdge(val fromId: String, val toId: String)

data class KnowledgeGraph(
    val nodes: List<GraphNode>,
    val edges: List<GraphEdge>
) {
    /** BFS de ruta más corta entre dos nodos seleccionados (sección 12). */
    fun shortestPath(fromId: String, toId: String): List<String>? {
        if (fromId == toId) return listOf(fromId)
        val adjacency = mutableMapOf<String, MutableList<String>>()
        edges.forEach {
            adjacency.getOrPut(it.fromId) { mutableListOf() }.add(it.toId)
            adjacency.getOrPut(it.toId) { mutableListOf() }.add(it.fromId) // no dirigido para navegación visual
        }
        val visited = mutableSetOf(fromId)
        val queue = ArrayDeque<List<String>>()
        queue.add(listOf(fromId))
        while (queue.isNotEmpty()) {
            val path = queue.removeFirst()
            val last = path.last()
            adjacency[last]?.forEach { next ->
                if (next == toId) return path + next
                if (visited.add(next)) queue.add(path + next)
            }
        }
        return null
    }
}
