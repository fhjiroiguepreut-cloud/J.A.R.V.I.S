package com.jarvis.assistant.index

/**
 * Tipos de archivo que JARVIS puede indexar en el PASO 1.
 * Cualquier otro tipo se ignora explícitamente (regla de la sección 11).
 */
enum class IndexedFileType {
    MARKDOWN,
    TXT,
    PDF
}

/** Tamaño máximo indexable en bytes (2 MB, según la regla de la sección 11). */
const val MAX_FILE_SIZE_BYTES: Long = 2L * 1024 * 1024

/** Un documento indexado con éxito. */
data class IndexedDocument(
    val uriString: String,
    val displayName: String,
    val type: IndexedFileType,
    val sizeBytes: Long,
    val excerpt: String,
    /** Nombres de destino extraídos de [[wikilinks]] dentro de este documento. */
    val outgoingLinks: List<String>
)

/** Un archivo que se encontró pero no se pudo indexar, con el motivo. */
data class SkippedFile(
    val displayName: String,
    val reason: SkipReason
)

enum class SkipReason {
    UNSUPPORTED_TYPE,
    TOO_LARGE,
    UNREADABLE
}

/** Un nodo del grafo de conocimiento: un documento y cuántas conexiones tiene. */
data class GraphHub(
    val displayName: String,
    val connectionCount: Int
)

/** Resultado completo de una pasada de indexación, usado por la pantalla de depuración del PASO 1. */
data class IndexResult(
    val documents: List<IndexedDocument>,
    val skipped: List<SkippedFile>,
    val folderDisplayName: String
) {
    val countsByType: Map<IndexedFileType, Int>
        get() = documents.groupingBy { it.type }.eachCount()

    /** Los documentos con más enlaces entrantes, para mostrar como "hubs" principales. */
    fun topHubs(limit: Int = 5): List<GraphHub> {
        val incoming = mutableMapOf<String, Int>()
        val byName = documents.associateBy { it.displayName }
        documents.forEach { doc ->
            doc.outgoingLinks.forEach { link ->
                if (byName.containsKey(link)) {
                    incoming[link] = (incoming[link] ?: 0) + 1
                }
            }
        }
        return incoming.entries
            .sortedByDescending { it.value }
            .take(limit)
            .map { GraphHub(it.key, it.value) }
    }
}
