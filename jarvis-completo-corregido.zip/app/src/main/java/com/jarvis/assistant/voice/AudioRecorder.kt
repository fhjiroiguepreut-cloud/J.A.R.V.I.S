package com.jarvis.assistant.voice

import android.content.Context
import android.media.MediaRecorder
import com.jarvis.assistant.security.Security
import kotlinx.coroutines.*
import java.io.File

enum class MicState { IDLE, RECORDING, ERROR_NO_PERMISSION, ERROR_HARDWARE }

/**
 * Graba audio real desde el micrófono (API nativa de Android, NO reconocimiento
 * de voz del navegador — sección 5), mide el nivel real, y detecta ~900 ms de
 * silencio para cerrar el turno (sección 6).
 *
 * Mientras JARVIS está hablando, [suspendForPlayback] debe llamarse para que
 * este grabador se pause y no se escuche a sí mismo (sección 7).
 */
class AudioRecorder(private val context: Context) {

    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var levelJob: Job? = null
    private var silenceAccumMs = 0L
    private var suspended = false

    /** Se invoca periódicamente con el nivel de mic normalizado 0f..1f. */
    var onLevelUpdate: ((Float) -> Unit)? = null

    /** Se invoca cuando se detectan [Security.SILENCE_THRESHOLD_MS] de silencio: fin del turno. */
    var onSilenceDetected: (() -> Unit)? = null

    var onError: ((MicState) -> Unit)? = null

    fun start(): Boolean {
        if (suspended) return false
        val file = File(context.cacheDir, "jarvis_turn_${System.currentTimeMillis()}.m4a")
        outputFile = file

        return try {
            recorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            silenceAccumMs = 0
            startLevelPolling()
            true
        } catch (e: SecurityException) {
            onError?.invoke(MicState.ERROR_NO_PERMISSION)
            false
        } catch (e: Exception) {
            onError?.invoke(MicState.ERROR_HARDWARE)
            false
        }
    }

    /** Detiene la grabación y devuelve el archivo de audio del turno, o null si falló. */
    fun stop(): File? {
        levelJob?.cancel()
        return try {
            recorder?.apply {
                stop()
                release()
            }
            recorder = null
            outputFile
        } catch (e: Exception) {
            recorder?.release()
            recorder = null
            null
        }
    }

    /** Interrupción manual (botón detener / botón de mic) — sección 7. */
    fun cancel() {
        levelJob?.cancel()
        try {
            recorder?.stop()
        } catch (_: Exception) {
        }
        recorder?.release()
        recorder = null
    }

    /** Mientras JARVIS reproduce su respuesta, el micrófono se suspende (sección 7). */
    fun suspendForPlayback() {
        suspended = true
        cancel()
    }

    fun resumeAfterPlayback() {
        suspended = false
    }

    private fun startLevelPolling() {
        levelJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive) {
                val amplitude = try {
                    recorder?.maxAmplitude ?: 0
                } catch (e: Exception) {
                    0
                }
                // Normalización aproximada del rango de amplitud de MediaRecorder (0..32767).
                val normalized = (amplitude / 32767f).coerceIn(0f, 1f)
                withContext(Dispatchers.Main) { onLevelUpdate?.invoke(normalized) }

                if (normalized < SILENCE_LEVEL_THRESHOLD) {
                    silenceAccumMs += POLL_INTERVAL_MS
                    if (silenceAccumMs >= Security.SILENCE_THRESHOLD_MS) {
                        withContext(Dispatchers.Main) { onSilenceDetected?.invoke() }
                        break
                    }
                } else {
                    silenceAccumMs = 0
                }
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    companion object {
        private const val POLL_INTERVAL_MS = 100L
        private const val SILENCE_LEVEL_THRESHOLD = 0.06f
    }
}
