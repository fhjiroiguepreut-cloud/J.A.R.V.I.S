package com.jarvis.assistant.voice

import android.content.Context
import com.jarvis.assistant.assistant.JarvisOrchestrator
import com.jarvis.assistant.profile.UserProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

enum class ReactorState { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

/**
 * Orquesta el ciclo completo de voz descrito en la sección 6, respetando
 * la prevención de bucle de audio de la sección 7: mientras [AudioPlayer]
 * reproduce, [AudioRecorder] queda suspendido y no puede transcribir la
 * propia voz de JARVIS.
 */
class JarvisVoiceController(
    context: Context,
    private val elevenLabsClient: ElevenLabsClient,
    private val orchestrator: JarvisOrchestrator,
    private val voiceId: String = "21m00Tcm4TlvDq8ikWAM" // voz por defecto de ElevenLabs; configurable
) {
    private val appContext = context.applicationContext
    private val recorder = AudioRecorder(appContext)
    private val player = AudioPlayer()
    private val scope = CoroutineScope(Dispatchers.Main)

    var onStateChanged: ((ReactorState) -> Unit)? = null
    var onMicLevel: ((Float) -> Unit)? = null
    var onTranscript: ((String) -> Unit)? = null
    var onJarvisText: ((String) -> Unit)? = null
    var onErrorMessage: ((String) -> Unit)? = null

    private var profile: UserProfile = UserProfile()

    fun updateProfile(p: UserProfile) {
        profile = p
    }

    init {
        recorder.onLevelUpdate = { level -> onMicLevel?.invoke(level) }
        recorder.onSilenceDetected = { finishTurn() }
        recorder.onError = { state ->
            onStateChanged?.invoke(ReactorState.ERROR)
            onErrorMessage?.invoke(
                when (state) {
                    MicState.ERROR_NO_PERMISSION -> "No tengo permiso de micrófono. Concédelo para poder escucharte."
                    MicState.ERROR_HARDWARE -> "El micrófono no respondió. Puede estar en uso por otra app."
                    else -> "Error de micrófono desconocido."
                }
            )
        }
        player.onStateChanged = { state ->
            when (state) {
                PlaybackState.PLAYING -> onStateChanged?.invoke(ReactorState.SPEAKING)
                PlaybackState.ERROR -> {
                    onStateChanged?.invoke(ReactorState.ERROR)
                    onErrorMessage?.invoke("No se pudo reproducir la respuesta de voz (TTS).")
                    recorder.resumeAfterPlayback()
                }
                PlaybackState.IDLE -> {}
            }
        }
        player.onCompleted = {
            // Solo al terminar de hablar se reactiva la captura (sección 7).
            recorder.resumeAfterPlayback()
            onStateChanged?.invoke(ReactorState.IDLE)
        }
    }

    /** El usuario pulsa el botón del micrófono. */
    fun startListening() {
        val started = recorder.start()
        if (started) onStateChanged?.invoke(ReactorState.LISTENING)
    }

    /** Botón de detener / interrupción manual (sección 7). */
    fun stopEverything() {
        recorder.cancel()
        player.stop()
        onStateChanged?.invoke(ReactorState.IDLE)
    }

    private fun finishTurn() {
        val audioFile = recorder.stop() ?: run {
            onStateChanged?.invoke(ReactorState.ERROR)
            onErrorMessage?.invoke("No se pudo cerrar la grabación del turno.")
            return
        }
        // Mientras se procesa (STT + IA + TTS) el mic queda suspendido para evitar bucle.
        recorder.suspendForPlayback()
        onStateChanged?.invoke(ReactorState.THINKING)

        scope.launch {
            when (val sttResult = elevenLabsClient.transcribe(audioFile)) {
                is VoiceResult.Success -> {
                    val transcript = sttResult.value
                    if (transcript.isBlank()) {
                        onErrorMessage?.invoke("No se entendió ningún audio en ese turno.")
                        recorder.resumeAfterPlayback()
                        onStateChanged?.invoke(ReactorState.IDLE)
                        return@launch
                    }
                    onTranscript?.invoke(transcript)

                    val response = orchestrator.handleUserMessage(transcript, profile)
                    onJarvisText?.invoke(response.text)

                    speak(response.text)
                }
                is VoiceResult.Failure -> {
                    onStateChanged?.invoke(ReactorState.ERROR)
                    onErrorMessage?.invoke(describeVoiceError(sttResult.error))
                    recorder.resumeAfterPlayback()
                }
            }
        }
    }

    private suspend fun speak(text: String) {
        when (val ttsResult = elevenLabsClient.synthesizeSpeech(text, voiceId)) {
            is VoiceResult.Success -> player.play(ttsResult.value, appContext.cacheDir)
            is VoiceResult.Failure -> {
                onStateChanged?.invoke(ReactorState.ERROR)
                onErrorMessage?.invoke(describeVoiceError(ttsResult.error))
                recorder.resumeAfterPlayback()
            }
        }
    }

    private fun describeVoiceError(error: VoiceError): String = error.message
}
