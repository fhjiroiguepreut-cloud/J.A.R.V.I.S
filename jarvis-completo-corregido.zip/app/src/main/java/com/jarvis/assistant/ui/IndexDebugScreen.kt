package com.jarvis.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import com.jarvis.assistant.index.IndexResult
import com.jarvis.assistant.index.SkipReason

private val BgNearBlack = Color(0xFF07090C)
private val Surface = Color(0xFF10141A)
private val AccentCyan = Color(0xFF4FD7E8)
private val TextDim = Color(0xFF8A93A0)

/**
 * PASO 1: pantalla puramente funcional/depuración.
 * Muestra lo que pide la sección 21: archivos encontrados, tipos, cantidad,
 * errores y principales hubs. Todavía sin núcleo holográfico ni voz.
 */
@Composable
fun IndexDebugScreen(
    isLoading: Boolean,
    result: IndexResult?,
    errorMessage: String?,
    onPickFolder: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgNearBlack)
            .padding(20.dp)
    ) {
        Text(
            "JARVIS — Indexación (Paso 1)",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Selecciona una carpeta. Se trata como solo lectura.",
            color = TextDim,
            fontSize = 13.sp
        )
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = onPickFolder,
            colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
        ) {
            Text("Elegir carpeta")
        }

        Spacer(Modifier.height(16.dp))

        when {
            isLoading -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(color = AccentCyan, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Indexando…", color = Color.White)
                }
            }
            errorMessage != null -> {
                ErrorCard(errorMessage)
            }
            result != null -> {
                SummaryCard(result)
                Spacer(Modifier.height(12.dp))
                HubsCard(result)
                Spacer(Modifier.height(12.dp))
                DocumentsAndErrorsList(result)
            }
            else -> {
                Text(
                    "Todavía no se ha indexado ninguna carpeta.",
                    color = TextDim,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF2A1010))) {
        Text(
            "Error: $message",
            color = Color(0xFFFF8A8A),
            modifier = Modifier.padding(14.dp),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun SummaryCard(result: IndexResult) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
        Column(Modifier.padding(14.dp)) {
            Text("Carpeta: ${result.folderDisplayName}", color = Color.White, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Documentos indexados: ${result.documents.size}   ·   Ignorados: ${result.skipped.size}",
                color = TextDim,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(6.dp))
            result.countsByType.forEach { (type, count) ->
                Text("• $type: $count", color = AccentCyan, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun HubsCard(result: IndexResult) {
    val hubs = result.topHubs()
    if (hubs.isEmpty()) return
    Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
        Column(Modifier.padding(14.dp)) {
            Text("Hubs principales (más enlazados)", color = Color.White, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            hubs.forEach { hub ->
                Text("• ${hub.displayName} — ${hub.connectionCount} conexiones", color = TextDim, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun DocumentsAndErrorsList(result: IndexResult) {
    LazyColumn(modifier = Modifier.fillMaxWidth()) {
        if (result.skipped.isNotEmpty()) {
            item {
                Text(
                    "Archivos ignorados",
                    color = Color(0xFFFFB74D),
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
                )
            }
            items(result.skipped) { skip ->
                Text(
                    "• ${skip.displayName} — ${reasonLabel(skip.reason)}",
                    color = TextDim,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
        item {
            Text(
                "Documentos",
                color = Color.White,
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
            )
        }
        items(result.documents) { doc ->
            Text(
                "• ${doc.displayName} (${doc.type}, ${doc.sizeBytes} B, ${doc.outgoingLinks.size} enlaces)",
                color = TextDim,
                fontSize = 12.sp,
                modifier = Modifier.padding(vertical = 2.dp)
            )
        }
    }
}

private fun reasonLabel(reason: SkipReason): String = when (reason) {
    SkipReason.UNSUPPORTED_TYPE -> "tipo no soportado"
    SkipReason.TOO_LARGE -> "supera 2 MB"
    SkipReason.UNREADABLE -> "no se pudo leer"
}
