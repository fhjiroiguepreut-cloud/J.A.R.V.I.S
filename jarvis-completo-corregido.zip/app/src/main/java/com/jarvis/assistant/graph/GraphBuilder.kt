package com.jarvis.assistant.graph

import com.jarvis.assistant.index.IndexResult
import kotlin.math.cos
import kotlin.math.sin

object GraphBuilder {

    fun build(index: IndexResult): KnowledgeGraph {
        val byName = index.documents.associateBy { it.displayName }
        val incomingCount = mutableMapOf<String, Int>()

        val edges = mutableListOf<GraphEdge>()
        index.documents.forEach { doc ->
            doc.outgoingLinks.forEach { link ->
                if (byName.containsKey(link)) {
                    edges.add(GraphEdge(doc.displayName, link))
                    incomingCount[link] = (incomingCount[link] ?: 0) + 1
                }
            }
        }

        val nodes = index.documents.mapIndexed { i, doc ->
            GraphNode(
                id = doc.displayName,
                label = doc.displayName,
                connectionCount = incomingCount[doc.displayName] ?: 0,
                typeTag = doc.type.name
            )
        }

        layoutCircular(nodes)
        return KnowledgeGraph(nodes, edges)
    }

    /** Distribución circular simple: suficientemente eficiente para móvil (sección 12). */
    private fun layoutCircular(nodes: List<GraphNode>) {
        val radius = 260f
        val centerX = 0f
        val centerY = 0f
        val count = nodes.size.coerceAtLeast(1)
        nodes.forEachIndexed { i, node ->
            val angle = 2 * Math.PI * i / count
            node.x = centerX + (radius * cos(angle)).toFloat()
            node.y = centerY + (radius * sin(angle)).toFloat()
        }
    }
}
