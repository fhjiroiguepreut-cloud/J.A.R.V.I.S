package com.jarvis.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

/**
 * Ajustes: aquí y solo aquí se introduce la clave de ElevenLabs (sección 5).
 * Una vez guardada, nunca se vuelve a mostrar en texto plano: el campo se
 * queda vacío tras guardar, y se muestra únicamente si hay una clave activa.
 */
@Composable
fun SettingsScreen(
    hasApiKey: Boolean,
    demoModeEnabled: Boolean,
    onSaveApiKey: (String) -> Unit,
    onClearApiKey: () -> Unit,
    onDemoModeChanged: (Boolean) -> Unit,
    onEditProfile: () -> Unit,
    onBack: () -> Unit
) {
    var keyInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF07090C))
            .padding(20.dp)
    ) {
        Text("Ajustes", color = Color.White, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(20.dp))

        Text("Modo demostración", color = Color.White, style = MaterialTheme.typography.titleMedium)
        Text(
            "Activado por defecto por seguridad. Con datos ficticios reproducibles, sin información real.",
            color = Color(0xFF8A93A0),
            style = MaterialTheme.typography.bodySmall
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = demoModeEnabled, onCheckedChange = onDemoModeChanged)
            Text(if (demoModeEnabled) "Demo activo" else "Datos reales", color = Color.White)
        }

        Spacer(Modifier.height(24.dp))
        Text("Clave de ElevenLabs", color = Color.White, style = MaterialTheme.typography.titleMedium)
        Text(
            if (hasApiKey) "Hay una clave guardada de forma cifrada. No se muestra por seguridad."
            else "Sin clave configurada todavía. La voz no funcionará hasta añadirla.",
            color = Color(0xFF8A93A0),
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = keyInput,
            onValueChange = { keyInput = it },
            label = { Text("Nueva clave de API") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row {
            Button(onClick = {
                if (keyInput.isNotBlank()) {
                    onSaveApiKey(keyInput)
                    keyInput = ""
                }
            }) { Text("Guardar clave") }
            Spacer(Modifier.width(8.dp))
            if (hasApiKey) {
                OutlinedButton(onClick = onClearApiKey) { Text("Eliminar clave") }
            }
        }

        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = onEditProfile) { Text("Editar mi contexto/perfil") }

        Spacer(Modifier.weight(1f))
        TextButton(onClick = onBack) { Text("Volver") }
    }
}
