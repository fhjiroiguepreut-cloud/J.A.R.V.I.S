package com.jarvis.assistant.index

/**
 * Extrae los nombres de destino de enlaces estilo [[wikilink]] de un texto.
 *
 * Soporta:
 *   [[Nombre]]              -> "Nombre"
 *   [[Nombre|Texto visible]] -> "Nombre"  (el texto tras "|" se ignora)
 *
 * Esto se usa para construir las conexiones del grafo de conocimiento
 * (sección 12): cada wikilink se convierte en una arista hacia el
 * documento cuyo nombre coincide.
 */
object WikiLinkParser {

    private val WIKILINK_REGEX = Regex("""\[\[([^\[\]|]+)(?:\|[^\[\]]*)?]]""")

    fun extractLinks(text: String): List<String> {
        return WIKILINK_REGEX.findAll(text)
            .map { it.groupValues[1].trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .toList()
    }
}
