package com.jarvis.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.profile.UserProfile

private data class Question(val key: String, val prompt: String)

private val QUESTIONS = listOf(
    Question("preferredAddressName", "¿Cómo quieres que te llame?"),
    Question("occupation", "¿A qué te dedicas?"),
    Question("businessOrProject", "¿Cuál es tu negocio o proyecto?"),
    Question("whatTheySell", "¿Qué vendes?"),
    Question("pricing", "¿Cuáles son tus precios?"),
    Question("clients", "¿Quiénes son tus clientes?"),
    Question("toolsUsed", "¿Qué herramientas utilizas?"),
    Question("professionalContext", "¿Qué información profesional quieres que conozca?"),
    Question("personalContext", "¿Qué contexto personal quieres compartir?"),
    Question("speakingStyle", "¿Cómo quieres que te hable?")
)

/**
 * Configuración inicial (sección 16): pregunta todo, no inventa nada.
 * El usuario puede dejar cualquier respuesta en blanco y completarla luego
 * (existe la opción de modificar estos datos después, ver ProfileRepository).
 */
@Composable
fun OnboardingScreen(onComplete: (UserProfile) -> Unit) {
    val answers = remember { mutableStateMapOf<String, String>() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF07090C))
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text("Antes de empezar", color = Color.White, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(4.dp))
        Text(
            "Nada de esto se inventa: solo guardo lo que me digas. Puedes dejar preguntas en blanco y responderlas después desde Configuración.",
            color = Color(0xFF8A93A0),
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(16.dp))

        QUESTIONS.forEach { q ->
            OutlinedTextField(
                value = answers[q.key] ?: "",
                onValueChange = { answers[q.key] = it },
                label = { Text(q.prompt) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            )
        }

        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            onComplete(
                UserProfile(
                    preferredAddressName = answers["preferredAddressName"]?.ifBlank { null },
                    occupation = answers["occupation"]?.ifBlank { null },
                    businessOrProject = answers["businessOrProject"]?.ifBlank { null },
                    whatTheySell = answers["whatTheySell"]?.ifBlank { null },
                    pricing = answers["pricing"]?.ifBlank { null },
                    clients = answers["clients"]?.ifBlank { null },
                    toolsUsed = answers["toolsUsed"]?.ifBlank { null },
                    professionalContext = answers["professionalContext"]?.ifBlank { null },
                    personalContext = answers["personalContext"]?.ifBlank { null },
                    speakingStyle = answers["speakingStyle"]?.ifBlank { null },
                    onboardingCompleted = true,
                    demoMode = true
                )
            )
        }) {
            Text("Continuar")
        }
    }
}
