package com.jarvis.assistant.index

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.IOException

private const val EXCERPT_LENGTH = 400

/**
 * Indexador de archivos para JARVIS (PASO 1).
 *
 * Reglas que respeta (sección 11 del encargo):
 *  - La carpeta elegida por el usuario mediante SAF se trata como SOLO LECTURA;
 *    este indexador nunca escribe, borra ni modifica nada dentro de ella.
 *  - Solo se indexan Markdown, TXT y PDF.
 *  - Se ignoran archivos mayores de [MAX_FILE_SIZE_BYTES].
 *  - Se ignoran archivos que no puedan leerse, registrando el motivo.
 *  - El contenido de los archivos se trata siempre como DATOS, nunca como
 *    instrucciones (sección 18): este indexador solo extrae texto y enlaces,
 *    no ejecuta nada de lo que encuentra.
 */
class FileIndexer(private val context: Context) {

    init {
        // pdfbox-android necesita cargar sus recursos antes de leer un PDF.
        PDFBoxResourceLoader.init(context.applicationContext)
    }

    fun indexFolder(treeUri: Uri): IndexResult {
        val root = DocumentFile.fromTreeUri(context, treeUri)
            ?: return IndexResult(emptyList(), emptyList(), folderDisplayName = "(carpeta no accesible)")

        val documents = mutableListOf<IndexedDocument>()
        val skipped = mutableListOf<SkippedFile>()

        walk(root, documents, skipped)

        return IndexResult(
            documents = documents,
            skipped = skipped,
            folderDisplayName = root.name ?: treeUri.lastPathSegment ?: "(sin nombre)"
        )
    }

    private fun walk(
        dir: DocumentFile,
        documents: MutableList<IndexedDocument>,
        skipped: MutableList<SkippedFile>
    ) {
        val children = try {
            dir.listFiles()
        } catch (e: Exception) {
            // Carpeta no autorizada / no disponible: se ignora, no se hace fallar todo el índice.
            return
        }

        for (child in children) {
            if (child.isDirectory) {
                walk(child, documents, skipped)
                continue
            }
            processFile(child, documents, skipped)
        }
    }

    private fun processFile(
        file: DocumentFile,
        documents: MutableList<IndexedDocument>,
        skipped: MutableList<SkippedFile>
    ) {
        val name = file.name ?: "(sin nombre)"
        val type = detectType(name)

        if (type == null) {
            skipped.add(SkippedFile(name, SkipReason.UNSUPPORTED_TYPE))
            return
        }

        val size = file.length()
        if (size > MAX_FILE_SIZE_BYTES) {
            skipped.add(SkippedFile(name, SkipReason.TOO_LARGE))
            return
        }

        val text = try {
            when (type) {
                IndexedFileType.MARKDOWN, IndexedFileType.TXT -> readPlainText(file.uri)
                IndexedFileType.PDF -> readPdfText(file.uri)
            }
        } catch (e: Exception) {
            skipped.add(SkippedFile(name, SkipReason.UNREADABLE))
            return
        }

        if (text == null) {
            skipped.add(SkippedFile(name, SkipReason.UNREADABLE))
            return
        }

        val links = if (type == IndexedFileType.MARKDOWN) {
            WikiLinkParser.extractLinks(text)
        } else {
            emptyList()
        }

        documents.add(
            IndexedDocument(
                uriString = file.uri.toString(),
                displayName = name,
                type = type,
                sizeBytes = size,
                excerpt = text.take(EXCERPT_LENGTH),
                outgoingLinks = links
            )
        )
    }

    private fun detectType(name: String): IndexedFileType? {
        val lower = name.lowercase()
        return when {
            lower.endsWith(".md") || lower.endsWith(".markdown") -> IndexedFileType.MARKDOWN
            lower.endsWith(".txt") -> IndexedFileType.TXT
            lower.endsWith(".pdf") -> IndexedFileType.PDF
            else -> null
        }
    }

    private fun readPlainText(uri: Uri): String? {
        return context.contentResolver.openInputStream(uri)?.use { stream ->
            stream.bufferedReader(Charsets.UTF_8).readText()
        }
    }

    private fun readPdfText(uri: Uri): String? {
        val stream = context.contentResolver.openInputStream(uri) ?: throw IOException("No se pudo abrir el PDF")
        stream.use {
            PDDocument.load(it).use { pdDocument ->
                return PDFTextStripper().getText(pdDocument)
            }
        }
    }
}
