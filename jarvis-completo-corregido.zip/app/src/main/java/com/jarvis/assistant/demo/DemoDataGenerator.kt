package com.jarvis.assistant.demo

import com.jarvis.assistant.index.IndexResult
import com.jarvis.assistant.index.IndexedDocument
import com.jarvis.assistant.index.IndexedFileType
import com.jarvis.assistant.security.Security
import kotlin.random.Random

/**
 * Genera datos completamente ficticios para el modo demostración (sección 14).
 * Usa una semilla fija ([Security.DEMO_SEED]) para que el resultado sea
 * siempre el mismo y nunca contenga información personal real.
 */
object DemoDataGenerator {

    private val rng = Random(Security.DEMO_SEED)

    private val demoTitles = listOf(
        "Notas de proyecto Aurora", "Ideas para el lanzamiento", "Reunión con proveedor ficticio",
        "Plan de contenidos", "Investigación de mercado (demo)", "Borrador de propuesta",
        "Seguimiento de tareas", "Glosario del proyecto", "Retrospectiva del trimestre"
    )

    fun demoIndexResult(): IndexResult {
        val docs = demoTitles.mapIndexed { i, title ->
            val linkTargets = if (i > 0) listOf(demoTitles[rng.nextInt(i)]) else emptyList()
            IndexedDocument(
                uriString = "demo://doc/$i",
                displayName = "$title.md",
                type = IndexedFileType.MARKDOWN,
                sizeBytes = (1500..40000).random(rng),
                excerpt = "Este es contenido de demostración generado localmente, no proviene de tus archivos reales.",
                outgoingLinks = linkTargets
            )
        }
        return IndexResult(
            documents = docs,
            skipped = emptyList(),
            folderDisplayName = "Carpeta de demostración"
        )
    }

    fun demoBrief(): List<String> = listOf(
        "09:30 — Sincronización de equipo (demo)",
        "12:00 — Llamada con cliente ficticio (demo)",
        "16:00 — Revisión de propuesta (demo)"
    )

    fun demoInboxSummary(): List<String> = listOf(
        "Remitente ficticio A — asunto: 'Seguimiento propuesta' (demo)",
        "Remitente ficticio B — asunto: 'Confirmación de reunión' (demo)"
    )

    private fun IntRange.random(rng: Random): Long =
        (rng.nextInt(last - first + 1) + first).toLong()
}
