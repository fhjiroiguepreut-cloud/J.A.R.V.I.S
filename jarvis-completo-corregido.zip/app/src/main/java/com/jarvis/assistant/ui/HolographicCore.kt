package com.jarvis.assistant.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.voice.ReactorState
import kotlin.math.cos
import kotlin.math.sin

private val CyanAccent = Color(0xFF4FD7E8)
private val ErrorRed = Color(0xFFFF5C5C)
private val DimRing = Color(0xFF1B2530)

/**
 * Núcleo holográfico central (sección 4).
 * - INACTIVO: rotación lenta y discreta.
 * - ESCUCHANDO: reacciona al [micLevel] real (nunca una animación falsa e independiente del audio).
 * - PENSANDO: anillos con más actividad.
 * - HABLANDO: pulso sincronizado con [speakingLevel] real de reproducción.
 * - ERROR: color de aviso, nunca oculta un fallo real detrás de una animación "normal".
 */
@Composable
fun HolographicCore(
    state: ReactorState,
    micLevel: Float,
    speakingLevel: Float,
    modifier: Modifier = Modifier
) {
    val infinite = rememberInfiniteTransition(label = "core")

    val baseRotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    ReactorState.THINKING -> 1400
                    ReactorState.IDLE -> 9000
                    else -> 4000
                },
                easing = LinearEasing
            )
        ),
        label = "rotation"
    )

    val pulse by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val accent = if (state == ReactorState.ERROR) ErrorRed else CyanAccent
    val energy = when (state) {
        ReactorState.LISTENING -> micLevel
        ReactorState.SPEAKING -> speakingLevel
        ReactorState.THINKING -> 0.5f + pulse * 0.3f
        ReactorState.ERROR -> 0.4f
        ReactorState.IDLE -> 0.15f + pulse * 0.05f
    }

    Canvas(modifier = modifier.size(220.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val maxRadius = size.minDimension / 2f

        // Anillos base (profundidad)
        for (i in 1..3) {
            val ringRadius = maxRadius * (0.5f + i * 0.15f)
            drawCircle(
                color = DimRing,
                radius = ringRadius,
                center = center,
                style = Stroke(width = 2f)
            )
        }

        // Anillo de energía reactivo (nivel real de mic/voz)
        val energyRadius = maxRadius * (0.55f + energy * 0.35f)
        drawCircle(
            color = accent.copy(alpha = 0.25f + energy * 0.5f),
            radius = energyRadius,
            center = center,
            style = Stroke(width = 6f + energy * 10f)
        )

        // Núcleo interno
        drawCircle(
            color = accent.copy(alpha = 0.85f),
            radius = maxRadius * (0.22f + energy * 0.08f),
            center = center
        )

        // Partículas orbitando (dan profundidad visual, sección 4)
        val particleCount = 10
        for (p in 0 until particleCount) {
            val angleDeg = baseRotation + (360f / particleCount) * p
            val angleRad = Math.toRadians(angleDeg.toDouble())
            val orbitRadius = maxRadius * (0.75f + 0.1f * ((p % 3)))
            val px = center.x + (orbitRadius * cos(angleRad)).toFloat()
            val py = center.y + (orbitRadius * sin(angleRad)).toFloat()
            drawCircle(
                color = accent.copy(alpha = 0.5f),
                radius = 3f + energy * 3f,
                center = Offset(px, py)
            )
        }
    }
}
