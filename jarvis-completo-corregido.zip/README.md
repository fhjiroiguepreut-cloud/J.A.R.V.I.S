# JARVIS — Asistente personal de IA para Android

Proyecto Android nativo (Kotlin + Jetpack Compose). No es una web, PWA ni
aplicación de escritorio: se compila como APK e instala directamente en un
teléfono Android.

> **Estado**: implementación completa de los 5 pasos del encargo original,
> construida sin pausas intermedias a petición del usuario. No ha sido
> compilada ni ejecutada en un dispositivo real todavía — se escribió en un
> entorno sin SDK de Android ni acceso a red. Antes de confiar en ella,
> ábrela en Android Studio, sincroniza Gradle y corrige lo que el compilador
> señale (ver "Cosas a verificar" abajo).

## Requisitos

- Android Studio (Koala o más reciente recomendado).
- JDK 17 (Android Studio lo trae integrado).
- Un teléfono o emulador con Android 8.0 (API 26) o superior.
- Una clave de API de [ElevenLabs](https://elevenlabs.io) si quieres usar voz
  (STT con Scribe y TTS). **Esto es un servicio de pago según tu plan y uso.**

## Cómo abrir el proyecto

1. Descomprime este proyecto.
2. Abre Android Studio → "Open" → selecciona la carpeta raíz (la que
   contiene `settings.gradle.kts`).
3. Deja que Android Studio sincronice Gradle (puede tardar la primera vez,
   descarga dependencias).

## Cómo compilar el APK

- Desde Android Studio: `Build → Build Bundle(s) / APK(s) → Build APK(s)`.
- Desde línea de comandos (con el wrapper de Gradle que Android Studio genera
  al abrir el proyecto): `./gradlew assembleDebug`.
- El APK resultante queda en `app/build/outputs/apk/debug/`.

## Cómo instalarlo en tu teléfono

1. Activa "Opciones de desarrollador" y "Depuración USB" en tu Android.
2. Conecta el teléfono y ejecuta desde Android Studio (▶), o copia el APK al
   teléfono e instálalo manualmente (tendrás que permitir "instalar apps de
   fuentes desconocidas" para ese archivo).

## Configuración de ElevenLabs

- Ve a **Ajustes** dentro de la app y pega tu clave de API.
- La clave se guarda cifrada (`EncryptedSharedPreferences`) y **nunca se
  vuelve a mostrar en la interfaz** una vez guardada, ni aparece en logs.
- Sin clave configurada, la voz no funcionará, pero el resto de JARVIS
  (chat de texto, herramientas, índice, memoria, grafo) sigue operando con
  normalidad.

## Permisos

- `RECORD_AUDIO`: para escucharte. Se solicita la primera vez que pulsas el
  micrófono, no antes.
- `INTERNET` / `ACCESS_NETWORK_STATE`: para hablar con ElevenLabs y, en el
  futuro, con un proveedor de búsqueda web para `research_web`.
- **No se solicita** acceso completo al almacenamiento. Los archivos se leen
  exclusivamente mediante el selector de carpetas de Android (Storage Access
  Framework), y esas carpetas se tratan siempre como solo lectura.

## Modo demostración vs modo real

- `JARVIS_DEMO` está **activado por defecto** (sección de seguridad del
  encargo). En este modo, todos los datos (bandeja, resumen del día, índice
  de ejemplo) son ficticios y reproducibles (semilla fija), nunca datos
  reales del usuario.
- Puedes desactivarlo desde Ajustes. Al desactivarlo, herramientas como
  `read_inbox` o `brief_me` indican explícitamente que todavía no están
  conectadas a una cuenta real, en vez de inventar información.

## Almacenamiento y memoria

- El índice de archivos vive solo en memoria de la sesión (se reconstruye al
  volver a elegir la carpeta).
- La memoria de JARVIS (`remember`) se guarda como archivos Markdown
  independientes dentro del almacenamiento privado de la app
  (`filesDir/memory/hecho_XXX.md`), fuera del alcance de las carpetas
  indexadas por el usuario. JARVIS nunca escribe en las carpetas indexadas.

## Herramientas disponibles

`search_brain`, `research_web` (pendiente de proveedor real de búsqueda),
`read_inbox` (solo lectura; pendiente de proveedor real de correo),
`brief_me` (pendiente de proveedor real de calendario), `remember`,
`plan_day`. En modo demostración, las que dependen de una cuenta externa
devuelven datos ficticios etiquetados como tal.

## Seguridad

- JARVIS nunca envía correos, mensajes, invitaciones ni publicaciones de
  forma automática: solo puede redactarlos y queda pendiente de tu
  autorización explícita.
- Las carpetas indexadas son siempre de solo lectura.
- El contenido de cualquier documento se trata como dato, nunca como
  instrucción, incluso si el texto dice literalmente "ignora las
  instrucciones anteriores".
- Ningún error se oculta: micrófono bloqueado, permiso denegado, fallo de
  transcripción/TTS, falta de conexión, modelo de IA no disponible, archivo
  ilegible o carpeta no disponible se muestran siempre de forma visible.

## Posibles costes

- **ElevenLabs** cobra según tu plan y el uso de STT/TTS. No se afirma que
  la voz sea gratuita.
- No hay ningún proveedor de modelo de IA conectado por defecto (ver
  `ai/AiClient.kt`): sin uno configurado, JARVIS sigue funcionando en modo
  reducido (herramientas + reglas, sin razonamiento generativo) y lo indica
  con claridad, en vez de fingir una respuesta generada por IA.

## Cosas a verificar al compilar (honestidad sobre el entorno de escritura)

Este proyecto se escribió sin poder ejecutar Gradle ni el compilador de
Kotlin/Android. Es razonablemente probable que, al compilar por primera vez,
Android Studio señale pequeños ajustes de versión (por ejemplo, la versión
exacta del plugin de Compose Compiler frente a tu versión de Kotlin, o algún
import sobrante). Son ajustes menores de compilación, no cambios de diseño.
