package com.jarvis.assistant.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.graph.GraphNode
import com.jarvis.assistant.graph.KnowledgeGraph
import kotlin.math.hypot

private val EdgeColor = Color(0xFF2A3542)
private val NodeColor = Color(0xFF4FD7E8)
private val SelectedColor = Color(0xFFFFC24F)
private val PathColor = Color(0xFF6CFF8E)

/**
 * Grafo de conocimiento táctil (sección 12): zoom con dos dedos, desplazamiento
 * táctil, mantener pulsado/tocar para seleccionar, tamaño de nodo según
 * conexiones, y ruta más corta entre dos nodos seleccionados.
 */
@Composable
fun GraphView(
    graph: KnowledgeGraph,
    onNodeSelected: (GraphNode) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var firstSelected by remember { mutableStateOf<String?>(null) }
    var secondSelected by remember { mutableStateOf<String?>(null) }

    val path = remember(firstSelected, secondSelected) {
        val a = firstSelected
        val b = secondSelected
        if (a != null && b != null) graph.shortestPath(a, b) else null
    }

    val density = LocalDensity.current

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.4f, 3f)
                    offset += pan
                }
            }
            .pointerInput(graph) {
                detectTapGestures { tapOffset ->
                    val centerX = size.width / 2f + offset.x
                    val centerY = size.height / 2f + offset.y
                    val hit = graph.nodes.minByOrNull { node ->
                        val nx = centerX + node.x * scale
                        val ny = centerY + node.y * scale
                        hypot((nx - tapOffset.x).toDouble(), (ny - tapOffset.y).toDouble())
                    }
                    hit?.let { node ->
                        val nx = centerX + node.x * scale
                        val ny = centerY + node.y * scale
                        val dist = hypot((nx - tapOffset.x).toDouble(), (ny - tapOffset.y).toDouble())
                        if (dist < 60) {
                            onNodeSelected(node)
                            if (firstSelected == null || (firstSelected != null && secondSelected != null)) {
                                firstSelected = node.id
                                secondSelected = null
                            } else if (firstSelected != node.id) {
                                secondSelected = node.id
                            }
                        }
                    }
                }
            }
    ) {
        val centerX = size.width / 2f + offset.x
        val centerY = size.height / 2f + offset.y

        fun screenPos(node: GraphNode) = Offset(centerX + node.x * scale, centerY + node.y * scale)

        val byId = graph.nodes.associateBy { it.id }

        // Aristas
        graph.edges.forEach { edge ->
            val from = byId[edge.fromId] ?: return@forEach
            val to = byId[edge.toId] ?: return@forEach
            val isOnPath = path != null && path.contains(edge.fromId) && path.contains(edge.toId)
            drawLine(
                color = if (isOnPath) PathColor else EdgeColor,
                start = screenPos(from),
                end = screenPos(to),
                strokeWidth = if (isOnPath) 4f else 1.5f
            )
        }

        // Nodos — tamaño según conexiones (hubs más grandes), evitando etiquetas superpuestas
        // priorizando solo los nodos más conectados para no saturar la pantalla.
        val labelThreshold = graph.nodes.map { it.connectionCount }.maxOrNull()?.let { it / 2 } ?: 0

        graph.nodes.forEach { node ->
            val pos = screenPos(node)
            val radius = (8f + node.connectionCount * 3f) * scale.coerceAtMost(1.5f)
            val color = when (node.id) {
                firstSelected, secondSelected -> SelectedColor
                else -> NodeColor
            }
            drawCircle(color = color, radius = radius, center = pos)
            drawCircle(color = color.copy(alpha = 0.3f), radius = radius * 1.8f, center = pos, style = Stroke(width = 1.5f))

            if (node.connectionCount >= labelThreshold) {
                drawContext.canvas.nativeCanvas.drawText(
                    node.label,
                    pos.x + radius + 6f,
                    pos.y,
                    android.graphics.Paint().apply {
                        this.color = android.graphics.Color.WHITE
                        textSize = with(density) { 12.sp.toPx() }
                        isAntiAlias = true
                    }
                )
            }
        }
    }
}
